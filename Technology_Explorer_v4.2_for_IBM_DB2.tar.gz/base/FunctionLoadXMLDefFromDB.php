<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/

function RetrieveXMLDefinitionfromDB($table, $schema) {
	
	$xquery1 = <<<END
VALUES(
XMLSERIALIZE(
XMLQUERY('
     let \$cols := db2-fn:sqlquery(''
                    SELECT
				      XMLELEMENT
				      (
				          NAME "info",
					  	  XMLELEMENT
					  	  (
					  		NAME "schema",
							t.TABSCHEMA
					  	  ),
					  	  XMLELEMENT
					      (
					  		NAME "table",
							t.TABNAME
					  	  ),
					  	  XMLELEMENT
					  	  (
							NAME "column",
							t.COLNAME
					  ),
					  XMLELEMENT
					  (
						NAME "type",
						t.TYPENAME
					  )
				       )
				FROM SYSCAT.COLUMNS AS t
				WHERE TABSCHEMA = ''''$schema''''
				AND TABNAME = ''''$table''''
				AND TYPENAME != ''''BLOB''''
        ORDER BY t.COLNO asc
     '')
     let \$n := string-join(("""", normalize-space(\$cols[1]/schema/text()), """.""", normalize-space(\$cols[1]/table/text()), """"), "")
     let \$a := string-join((normalize-space(\$cols[1]/schema/text()), normalize-space(\$cols[1]/table/text())), ".")
     return if(\$n = ".") then ""
     		else if(\$a = ".") then ""
            else
	     <table name="{\$a}">
	      <sql_name>{\$n}</sql_name>
              <singular_name>{\$a}</singular_name>
              <plural_name>{\$a}</plural_name>
              <description></description>
              <disable_edit/>
              <rows_per_page>50</rows_per_page>
              <order_by_index></order_by_index>
              <display_columns>
               {
		  for \$c in \$cols
		  return <col type="column" name="{lower-case(\$c/column/text())}"/>
              }
              </display_columns>

              {
		  for \$c in \$cols
		  return <column name="{lower-case(\$c/column/text())}">
			   <c_sql_name>"{
				let \$type := \$c/type/text()
				return if(\$type = "LONG VARGRAPHIC" or \$type = "GRAPHIC" or \$type = "VARGRAPHIC") then fn:concat(''cast('', \$c/column/text(), '' as clob)'')
			               else \$c/column/text()
			   }"</c_sql_name>
			   <c_title>{
			   	for \$w in tokenize(lower-case(translate(\$c/column/text(),''_'','' '')), ''\\s+'')
			   	return concat( upper-case(substring(\$w,1,1)) , substring(\$w,2) ) 
			   }</c_title>
			   <c_presentation>

			   {
				let \$type := \$c/type/text()
				return if(\$type = "LONG VARCHAR" or \$type = "CLOB") then ''l''
			      	       else if(\$type = "CHARACTER" or \$type = "VARCHAR") then ''s''
			               else if(\$type = "BLOB" or \$type = "XML") then ''l''
			               else ''n''
			   }
				</c_presentation>
				<c_drill>
			   {
				let \$type := \$c/type/text()
				return if(\$type = "CHARACTER" or \$type = "VARCHAR") then ''y''
			               else ''n''
			   }
			 </c_drill>
			 </column>
              }
	    </table>'
	    RETURNING SEQUENCE) AS CLOB(2M)))
END;

	$result = connectionManager::getNewStatement($xquery1, FALSE, FALSE);

	$xml_string = "";

	if($row = $result->fetch())
	{
		$xml_string .= $row[0];
	}//Obtain XML String
	$temp = explode('\n', $xml_string);
	if($temp === false) 
		$xml_string = null;
	else if('<table name=".">' == $temp[0]) 
		$xml_string = null;

	//Close the Connection
	return $xml_string == null? RetrieveXMLDefinitionUsingSelectfromDB($table, $schema) : $xml_string;
}


function RetrieveXMLDefinitionUsingSelectfromDB($table, $schema) {

	$xml_string = "";
	if($schema != "")
		$schema .= '.';
		
	$query = "SELECT * FROM {$schema}{$table}";
	$statment = connectionManager::getNewStatement($query);

	if($statment->errorMsg() == "")
	{
		$columns = "";
		$displayColumns = "";
		
		$columnInfo = $statment->getColumnInfo();
		$i = 0;
		for($i = 0; $i < $columnInfo['num']; $i++)
	    {
			$columns .= '<col type="column" name="' . $columnInfo['name'][$i] . "\"/>\n";
			
			$displayColumns .= '<column name="' . $columnInfo['name'][$i] . "\">\n";
			$displayColumns .= '		<c_sql_name>"' . $columnInfo['name'][$i] . '"</c_sql_name>\n';
			$displayColumns .= '		<c_title>' . $columnInfo['name'][$i] . "</c_title>\n";
			$displayColumns .= '		<c_presentation>';
			
			if(preg_match('/long varchar|clob|blob|xml/', $columnInfo['type'][$i]))
				$displayColumns .= 'y';
			else if(preg_match('/char|string|/', $columnInfo['type'][$i]))
				$displayColumns .= '';
			else
				$displayColumns .= 'n';
			$displayColumns .= '</c_presentation>\n';
			$displayColumns .= '		<c_drill>';
			if(preg_match('/char|string|date/', $columnInfo['type'][$i] != null))
				$displayColumns .= 'y';
			else
				$displayColumns .= 'n';
			$displayColumns .= "</c_drill>\n";
			$displayColumns .= "	</column>\n";	
	    }
	  	
	  	
		$xml_string .= "<table name='{$schema}{$table}'>\n";
		$xml_string .= "	<sql_name>{$schema}{$table}</sql_name>\n";
	    $xml_string .= "	<singular_name>{$schema}{$table}</singular_name>\n";
	    $xml_string .= "	<plural_name>{$schema}{$table}</plural_name>\n";
	    $xml_string .= "	<description></description>\n";
	    $xml_string .= "	<rows_per_page>50</rows_per_page>\n";
	    $xml_string .= "	<order_by_index></order_by_index>\n";
	    $xml_string .= "	<display_columns>\n";
	    $xml_string .= $columns;
	    $xml_string .= "	</display_columns>\n";
	    $xml_string .= $displayColumns;
		$xml_string .= "</table>";
	}
	
	return $xml_string;
}

function RetrieveProcXMLDefinitionfromDB($proc, $schema) {

	$xquery1 = <<<END
VALUES(
XMLSERIALIZE(
XMLQUERY('
     let \$cols := db2-fn:sqlquery(''
		SELECT
			XMLELEMENT
			(
				NAME "info",
				XMLELEMENT
				(
					NAME "schema",
					t.PROCSCHEMA
				),
				XMLELEMENT
				(
					NAME "table",
					t.PROCNAME
				),
				XMLELEMENT
				(
					NAME "column",
					t.PARMNAME
				),
				XMLELEMENT
				(
					NAME "type",
					t.TYPENAME
				),
				XMLELEMENT
				(
					NAME "ordinal",
					t.ORDINAL
				),
				XMLELEMENT
				(
					NAME "mode",
					t.PARM_MODE
				)
			)
				FROM SYSCAT.PROCPARMS AS t
				WHERE PROCSCHEMA = ''''$schema''''
				AND PROCNAME = ''''$proc''''
        ORDER BY t.ORDINAL asc
     '')
     let \$n := string-join("""", (normalize-space(\$cols[1]/schema/text()), """.""", normalize-space(\$cols[1]/table/text())), """","")
     return if(\$n = ".") then ""
            else
		<table name="{\$n}">
			<sql_name>{\$n}</sql_name>
			<singular_name>{\$n}</singular_name>
			<plural_name>{\$n}</plural_name>
			<function>{\$n}</function>
			<description></description>
			<parameters>

              {
		  for \$c in \$cols
		  return <parm name="{\$c/column/text()}" ordinal="{\$c/ordinal/text()}" mode="{\$c/mode/text()}">
			   <title>{\$c/column/text()}</title>
			   <type>{\$c/type/text()}</type>
			</parm>
              }
			</parameters>
		</table>'
	    RETURNING SEQUENCE) AS CLOB(2M)))
END;


	$result = connectionManager::getNewStatement($xquery1, FALSE, FALSE);

	$xml_string = "";

	if($row = $result->fetch())
	{
		$xml_string .= $row[0];
	}//Obtain XML String

	//Close the Connection
	return $xml_string;

}
