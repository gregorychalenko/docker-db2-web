<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/

require_once(PHP_INCLUDE_BASE_DIRECTORY . "JSONEncodeAction.php");
require_once(PHP_INCLUDE_BASE_DIRECTORY . "JSONEncodeMenuGraph.php");
include_once(PHP_INCLUDE_BASE_DIRECTORY . "ObjectXMLNode_" . XML_PARSING_ENGINE . ".php");

class JSONEncodeMenu {
	
	static $defaultTarget = "_self";
	static $defaultWindow = "_self";
	static $defaultStage = null;
	
	static $panelNameSet = null;
	
	static function loadFile($filename, $menulocation, $rootNode, $filterList)
	{ 
		global $GLOBALS;
		$GLOBALS['CURRENT_MENU_LOCATION'] = $rootNode . "/" . $menulocation;
		if(file_exists($rootNode . "/" . $menulocation . "/" . $filename))
			return JSONEncodeMenu::loadString(file_get_contents($rootNode . "/" . $menulocation . "/" . $filename), $menulocation, $rootNode, $filterList, $filename);
		return null;
	}
	
	static function loadString($xml, $menulocation, $rootNode, $filterList, $currentFile)
	{
		if($xml != "")
		{
			try 
			{
				$doc = new XMLNode();
				if($doc->loadXML($xml) !== false)
				{
					return JSONEncodeMenu::loadDom($doc, $menulocation, $rootNode, $filterList, $currentFile);
				}
				else 
				{
					return null;
				}
			}
			catch (Exception $e)
			{
				return null;
			}
		}
		return null;		
	}
	static function encodePageWindowFromFile($filename)
	{ 
		if(is_readable($filename))
			return JSONEncodeMenu::encodePageWindowFromString(file_get_contents($filename));
		return null;
	}
	static function encodePageWindowFromString($xml)
	{
		if($xml != "")
		{
			try 
			{
				$domNode = new XMLNode();
				if($domNode->loadXML($xml) !== false)
				{
					if(strcasecmp($domNode->nodeName, "pageWindow") == 0)
					{
						return JSONEncodeMenu::encodePageWindow($domNode);
					}
				}
				else 
				{
					return null;
				}
			}
			catch (Exception $e)
			{
				return null;
			}
		}
		return null;		
	}
	
	static function loadDom($domNode, $menulocation, $rootNode, $filterList, $currentFile)
	{
		if(strcasecmp($domNode->nodeName, "menu") == 0)
		{
			return JSONEncodeMenu::encodeMenuNode($domNode, $menulocation, $rootNode, $filterList, $currentFile);
		}
		return null;
	}
	static function loadEmbededMenu($domNode, $menulocation, $rootNode, $filterList, $currentFile)
	{
		$returnObject = array();
		foreach($domNode->childNodes as $node)
		{
			if(strcasecmp($node->nodeName, "menu") == 0)
			{
				$returnObject[] = JSONEncodeMenu::encodeMenuNode($node, $menulocation, $rootNode, $filterList, $currentFile);
			}
		}
		return $returnObject;
	}
/*** added: Peter Prib - Copyright Frygma Pty Ltd (ABN 90 791 388 622 2009)  2010 All rights reserved.*/
	static function menuError($message, $rootNode, $onErrorMenu, $menulocation) {
		$returnObject = array();
		if ($onErrorMenu==null) { 
	 		$returnObject[] = JSONEncodeMenu::loadString('<menu type="leaf"><description>'.$message.'</description></menu>', $menulocation, $rootNode, null, null);
		} else {
			$filename=$rootNode . $menulocation . "/" . $onErrorMenu . ".xml";
			if(file_exists($filename))
				$returnObject[] = JSONEncodeMenu::loadString(file_get_contents($filename), $menulocation, $rootNode, null, $filename);
			else 
 				$returnObject[] = JSONEncodeMenu::loadString('<menu type="leaf"><description>error menu not found : '.$filename . '</description></menu>',$menulocation, $rootNode, null, null);
		}
		return $returnObject;
	}	
	static function encodeMenuSQLXML($branchSQLXML, $rootNode, $filterList,$branchXSL,$branchSQLPredicate,$dropParent,$onErrorMenu, $menulocation)
	{
		$returnObject = array();
		if(	strtolower(substr($branchSQLXML,0,7))=='select '
		or	strtolower(substr($branchSQLXML,0,7))=='xquery '
		or	strtolower(substr($branchSQLXML,0,7))=='values('
		or	strtolower(substr($branchSQLXML,0,7))=='values '
		or	strtolower(substr($branchSQLXML,0,5))=='with '
		or	substr($branchSQLXML,0,1)=='('
		) {
			$sql=$branchXMLSQL;
		}
		else if(file_exists($branchSQLXML.".sql")) 
		{
			$sql=file_get_contents($branchSQLXML.".sql");
		} 
		else if(file_exists($branchSQLXML)) 
		{
			$sql=file_get_contents($branchSQLXML);
		} 
		else {
			logError(LOG_ERR,'branchSQLXML "'.$branchSQLXML.'" not found');
			return JSONEncodeMenu::menuError('branchSQLXML "'.$branchSQLXML.'" not found', $rootNode, $onErrorMenu, $menulocation);
		}
		if(!connectionManager::isConnected()) {
			return JSONEncodeMenu::menuError("No database connection found", $rootNode, $onErrorMenu, $menulocation);
	 	}
		connectionManager::getConnection()->setAutoCommit(true);
	 	if ($branchSQLPredicate==null or $branchSQLPredicate=="")
	 	{
			$stmt = connectionManager::getNewStatement($sql." for read only");
	 	}
	 	else
	 	{
	 		$stmt = connectionManager::getNewStatement($sql." where ".$branchSQLPredicate." for read only");
	 	}
		if(!$stmt->statementSucceed) { 
			logError(LOG_ERR, "branchXMLSQL SQL error  dump statement: ".var_export($stmt,true));
			return JSONEncodeMenu::menuError("SQL Error, SQLSTATE: ".$stmt->sqlstate." - see log", $rootNode, $onErrorMenu, $menulocation);
		}
		$xml = $stmt->fetch();
		if($xml == false) {
			logError(LOG_ERR, "branchXMLSQL null response ");
			return null;
		}
		return self::encodeMenuXML($xml[0], $rootNode, $filterList,$branchXSL,$dropParent,$onErrorMenu, $menulocation);
	}
	static function encodeMenuXML($xml, $rootNode, $filterList,$branchXSL,$dropParent,$onErrorMenu, $menulocation)
	{
		if($xml == "") {
			logError(LOG_ERR,'encodeMenuXML no input XML');
			return JSONEncodeMenu::menuError('nil', $rootNode, $onErrorMenu, $menulocation);
		}
		if($branchXSL == "") {
			$returnObject[] = JSONEncodeMenu::loadString($xml, $menulocation, $rootNode, $filterList, null);
			if ($dropParent=="true") $returnObject=$returnObject[0];
			return $returnObject;
		}

		$xmlDOM = new DOMDocument;
		if(substr($xml,0,1) == '<') {
			if($xmlDOM->loadXML($xml) == false) 
				return JSONEncodeMenu::menuError('branchSQLXML XML invalid', $rootNode, $onErrorMenu, $menulocation);
		} else 	{
			if($xmlDOM->load( $xml.".xml") == false)
				if($xmlDOM->load( $xml, LIBXML_NOCDATA) == false) 
					return JSONEncodeMenu::menuError('XML file '.$xml.'" not found or XML invalid', $rootNode, $onErrorMenu, $menulocation);
		}

		$xslt = new XSLTProcessor();
		$xslDOM = new DOMDocument();
		if(substr($branchXSL,0,1) == '<') {
			if($xslDOM->loadXML( $branchXSL) == false)
				return JSONEncodeMenu::menuError('branchXSL invalid: '.$branchXSL, $rootNode, $onErrorMenu, $menulocation);
		} else { 
			if($xslDOM->load( $branchXSL.".xsl") == false)
				if($xslDOM->load( $branchXSL, LIBXML_NOCDATA) == false) 
					return JSONEncodeMenu::menuError('branchXSL file '.$branchXSL.'" not found or XSL invalid', $rootNode, $onErrorMenu, $menulocation);
		}
		if($xslt->importStylesheet($xslDOM) == false) 
			return JSONEncodeMenu::menuError('branchXSL parse error '.$branchXSL, $rootNode, $onErrorMenu, $menulocation);
		$returnObject[] =  JSONEncodeMenu::loadString($xslt->transformToXML($xmlDOM), $menulocation, $rootNode, $filterList, null);
		if ($dropParent=="true") {
			$returnObject=$returnObject[0]['elementSubNodes'];
			}
		return $returnObject;
	}
/*** end added ***/
	static function encodeMenuFolder($menulocation, $rootNode, $filterList)
	{
		$returnObject = array();
		// if the current expected directory is not a directory return
		if(is_dir($rootNode . "/" . $menulocation) === false) return "";
	
		// Acquire a list of files in the directory sorted ascending
		$fileInDir = scandir($rootNode . "/" . $menulocation, 0);
		
		sort($fileInDir);
	
		foreach($fileInDir as $currentFile)
		{
			// Look for XML files that start with 'menu_' and end with '.xml' while ignoring case
			if(preg_match('/^menu_.*\.xml$/i', $currentFile ))
			{
		     	$returnObject[] = JSONEncodeMenu::loadFile($currentFile, $menulocation, $rootNode, $filterList);
			}
		}
		return $returnObject;
	}
	
	static function encodeMenuNode($node, $menulocation, $rootNode, $filterList, $currentFile)
	{
		if($node == null) return null;
		
		$returnObject = array();
		
		$nodeType = strtoupper($node->getAttribute("type", "leaf"));
		
		$delayLoad = $node->getAttribute("delayLoad");
		$delayLoad = $delayLoad == "" ? "false" : strtolower($delayLoad);
		$reloadOnConnectionChange = strtolower($node->getAttribute("reloadOnConnectionChange", 'false')) == 'true' ? true : false;
		
		$rootDirectory = trim($node->getAttribute("rootDirectory"));
		$branchDirectory = trim($node->getAttribute("branchDirectory"));
		$branchSQLXML = trim($node->getAttribute("branchSQLXML"));
		$branchSQLPredicate = trim($node->getAttribute("branchSQLPredicate"));
		$branchXML = trim($node->getAttribute("branchXML"));
		$branchXSL = trim($node->getAttribute("branchXSL"));
		$onErrorMenu = trim($node->getAttribute("onErrorMenu"));
		$dropParent = trim($node->getAttribute("dropParent"));
		
		$minVersion = floatval(trim($node->getAttribute("minVersion", 0)));
		$minFixPack = intval(trim($node->getAttribute("minFixPack", 0)));
		$maxVersion = floatval(trim($node->getAttribute("maxVersion", 0)));
		
		$tag = $node->getAttribute("tag");

		if(!($tag == "" && $nodeType == "BRANCH") && $filterList != null)
		{
			foreach($filterList as $filter)
	    	{
		    	if(ereg($filter, $tag) == false)
		    	{
		    		return null;
		    	}
	    	}
		}
		
		$description = $node->getChildTextContent("description", "none");
		
		$filter = $node->getChildTextContent("filter", null);
		
		if($filter != null && $filterList != null)
		{
			$filterList[] = $filter;
		}
		else if($filter != null)
		{
			$filterList = array($filter);
		}
		
		$elementID = $node->getChildTextContent("menuGUID", null);
		$elementAction = null;
		$elementSubNodeElements = null;
		$elementSubNodeDirection = null;
		$rootCallBack = null;
		$localFilterList = null;
		$actionJSON = null;
		$linkList = null;
		$pageWindow = null;
		$floatingPanelData = null;
		
		switch($nodeType)
		{
			case "BRANCH":
				if($delayLoad == "true" && $currentFile != null)
				{
					$nodeType = "DELAYLOADBRANCH";
					$rootCallBack = $rootNode . "/" . $menulocation . "/" . $currentFile;
					$rootCallBack = preg_replace("/[\\/]+/", "/", $rootCallBack);
					$localFilterList = $filterList;
					$localFilterList = $localFilterList == null ? null : $localFilterList;
					
				}
				else if(($delayLoad != "false") && ($branchSQLXML != "" || $branchXML!=""))
				{
					$nodeType = "DELAYLOADBRANCH";
					$menuCallBack = array();
					$menuCallBack["reloadOnConnectionChange"]=$reloadOnConnectionChange;
					$menuCallBack["delayLoad"]=$delayLoad;
					$menuCallBack["rootDirectory"]=$rootDirectory;
					$menuCallBack["branchDirectory"]=$branchDirectory;
					$menuCallBack["branchSQLXML"]=$branchSQLXML;
					$menuCallBack["branchSQLPredicate"]=$branchSQLPredicate;
					$menuCallBack["branchXML"]=$branchXML;
					$menuCallBack["branchXSL"]=$branchXSL;
					$menuCallBack["onErrorMenu"]=$onErrorMenu;
					$menuCallBack["dropParent"]=$dropParent;
					$menuCallBack["filter"]=$filter;
					$menuCallBack["menulocation"]=$menulocation;
					$rootCallBack=json_encode($menuCallBack);
					$localFilterList = $filterList;
					$localFilterList = $localFilterList == null ? null : $localFilterList;
					
				}
				else 
				{
					if($rootDirectory != "")
					{
						$elementSubNodeElements = JSONEncodeMenu::encodeMenuFolder($menulocation, $rootDirectory, $filterList);
					}
					else if($branchDirectory != "")
					{
						$elementSubNodeElements = JSONEncodeMenu::encodeMenuFolder($menulocation . "/" . $branchDirectory, $rootNode, $filterList);
					}
/*** added: Peter Prib - Copyright Frygma Pty Ltd (ABN 90 791 388 622 2009)  2010 All rights reserved.*/
					else if($branchSQLXML != "") 
					{
						$nodeType = "SQL_BRANCH";
						$elementSubNodeElements = JSONEncodeMenu::encodeMenuSQLXML($branchSQLXML, $rootNode, $filterList,$branchXSL,$branchSQLPredicate,$dropParent,$onErrorMenu, $menulocation);
					}
					else if($branchXML != "") 
					{
						$nodeType = "XML_BRANCH";
						$elementSubNodeElements = JSONEncodeMenu::encodeMenuXML($branchXML, $rootNode, $filterList,$branchXSL,$dropParent,$onErrorMenu, $menulocation);
					}
/*** end added ***/
					if($elementSubNodeElements == null || $elementSubNodeElements == null)
						return null;
				}
				break;
			case "LEAF":
				
				$actionNode = $node->findChildNode("actionScript");
				$elementAction = $node->getChildTextContent("JSAction", null);
				if($actionNode != null)
				{
					$actionJSON = JSONEncodeAction::fromDOM($actionNode);
				}
				
				$FloatingLink = $node->findChildNode("floatingPanel");
				if($FloatingLink != null)
				{
					$floatingPanelData = JSONEncodeMenu::getPanelContent($FloatingLink->childNodes);
					$floatingPanelData['hideMenuBar'] = strtolower($FloatingLink->getAttribute("hideMenuBar", 'false')) == 'true' ? true : false;
					$floatingPanelData['reloadOnConnectionChange'] = strtolower($FloatingLink->getAttribute("reloadOnConnectionChange", 'false')) == 'true' ? true : false;
					$floatingPanelData['panelHeaders'] = JSONEncodeMenu::encodePanelHeaders($FloatingLink->findChildNode("panelHeaders"));
					$floatingPanelData['baseWidth'] = $FloatingLink->getAttribute("baseWidth", null);
					$floatingPanelData['baseHeight'] = $FloatingLink->getAttribute("baseHeight", null);
					$floatingPanelData['loadContentOnShow'] = strtolower($FloatingLink->getAttribute("loadContentOnShow", 'false')) == 'true' ? true : false;
					$floatingPanelData['reloadContentOnShow'] = strtolower($FloatingLink->getAttribute("reloadContentOnShow", 'false')) == 'true' ? true : false;
				}
				
				$linkList = JSONEncodeMenu::retrieveLinksFromDOM($node);
	    		$pageWindow = JSONEncodeMenu::encodePageWindowsFromDOM($node);
				break;
			case "EMBEDDEDBRANCH":
				$nodeType = "BRANCH";
				$elementSubNodeElements = JSONEncodeMenu::loadEmbededMenu($node, $menulocation, $rootNode, $filterList, null);
				break;
		}
		
		$returnObject["nodeType"] = $nodeType;
		$returnObject["delayLoad"] = $delayLoad;
		$returnObject["reloadOnConnectionChange"] = $reloadOnConnectionChange;
		$returnObject["minVersion"] = $minVersion;
		$returnObject["minFixPack"] = $minFixPack;
		$returnObject["maxVersion"] = $maxVersion;
		$returnObject["tag"] = $tag;
		$returnObject["elementID"] = $elementID;
		$returnObject["elementValue"] = $description;
		$returnObject["elementActionScript"] = $actionJSON;
		$returnObject['elementFloatingLink'] = $floatingPanelData;
		$returnObject["elementLinkList"] = $linkList;
		$returnObject["elementPageWindows"] = $pageWindow;
		$returnObject["elementAction"] = $elementAction;
		$returnObject["elementSubNodes"] = $elementSubNodeElements;
		$returnObject["rootCallBack"] = $rootCallBack;
		$returnObject["filterList"] = $localFilterList;
		$returnObject["elementSubNodeDirection"] = $elementSubNodeDirection;
		return $returnObject;
	}
	
	static function loadFileNodes($filename, $nodeNameToEncode, $depth = -1)
	{
		if(file_exists($filename))
			return JSONEncodeMenu::loadStringNodes(file_get_contents($filename), $nodeNameToEncode, $depth);
		return null;
	}
	
	static function loadStringNodes($xml, $nodeNameToEncode, $depth = -1)
	{
		if($xml != "")
		{
			try 
			{
				$doc = new XMLNode();
				if($doc->loadXML($xml) !== false)
				{
					$returnObject = array();
					foreach($doc->childNodes as $node)
     				{
	     				if( trim($node->nodeName) == $nodeNameToEncode)
	     				{
								$returnObject[] = JSONEncodeMenu::convertNode($node);
	     				}
	     				else 
	     				{
	     					if($depth != 0)
	     						$returnObject[] = JSONEncodeMenu::findAndEncodeNodes($node, $nodeNameToEncode, $depth);
	     				}
					}
     			
     				return $returnObject;
				}
				else 
				{
					return null;
				}
			}
			catch (Exception $e)
			{
				return null;
			}
		}
		return null;		
	}
	
	static function findAndEncodeNodes($node, $nodeNameToEncode, $depth = -1)
	{
		$depth--;
		$returnObject = array();
		foreach($node->childNodes as $childNode)
		{
			if( trim($childNode->nodeName) == $nodeNameToEncode)
			{
				$returnObject[] = JSONEncodeMenu::convertNode($childNode);
			}
			else 
			{
				if($depth != 0)
					$returnObject[] = JSONEncodeMenu::findAndEncodeNodes($childNode, $nodeNameToEncode);
			}
		}
		return $returnObject;
	}
	
	static function convertNode($node)
	{
		
		$hasChildNodes = false;

		$returnObject = array();

		$returnObject["name"] = trim($node->nodeName);
		
		if($node->hasAttributes())
		{
			$LocalJsonAttributs = array();
			
			foreach ($node->attributes as $index=>$attr) 
			{
		        $LocalJsonAttributs[$attr->name] = $attr->value;
			}
			$returnObject["attributes"] = $LocalJsonAttributs;
		}
		if($node->hasChildNodes())
		{
			$LocalJsonChildNodes = array();
			
			foreach ($node->childNodes as $childNode) 
			{
				$hasChildNodes = true;
				$LocalJsonChildNodes[] = JSONEncodeMenu::convertNode($childNode);	
			}
			if($LocalJsonChildNodes != "")
				$returnObject["childNodes"] = $LocalJsonChildNodes;
		}
		$nodeValue = trim($node->textContent);
		if($nodeValue != "" && !$hasChildNodes)
		{
			$returnObject["value"] = $nodeValue;
		}
		return $returnObject;
	}
	
	static function retrieveLinksFromString($XMLString)
	{
			if($DomObject != "")
			{
				try 
				{
					$DomObject = new XMLNode();
					if($DomObject->loadXML($DomObject))
					{
						return JSONEncodeMenu::retrieveLinksFromDOM($DomObject);
					}
					else 
					{
						return null;
					}
					
				}
				catch (Exception $e)
				{
					return null;
				}
			}
			return null;		
	}
	
	
	static function retrieveLinksFromDOM($DomObject)
	{
		$returnObject = array();
		
		$linkLists = $DomObject->getElementsByTagName('linkList');
		foreach ($linkLists as $aLinkList)
		{
			if($aLinkList->hasChildNodes())
			{
				foreach ($aLinkList->childNodes as $Link)
				{
					$returnObject[] = JSONEncodeMenu::encodeTopLinkNodeToURL($Link);
				}
			}
		}
		return $returnObject;
	}
	
	static function encodeTopLinkNodeToURL($Link, $rowData = null, $fieldLookUp = null)
	{
		if(strcasecmp($Link->nodeName, "link") == 0)
		{
			$returnObject = array();
			$dataType = strtoupper($Link->getAttribute("type"));
			$dataType = $dataType != "" ? $dataType : "LINK";
			
			$target = $Link->getAttribute("target");
			$window = $Link->getAttribute("window");
			$windowStage = $Link->getAttribute("windowStage");

			$returnObject["target"] = ($target == "" ? JSONEncodeMenu::$defaultTarget : $target);
			$returnObject["window"] = ($window == "" ? JSONEncodeMenu::$defaultWindow : $window);
			$returnObject["windowStage"] =  ($windowStage == "" ? JSONEncodeMenu::$defaultStage : $windowStage);
			$returnObject["formList"] = JSONEncodeMenu::encodeFormListToJSON($Link);
			$returnObject["type"] = $dataType;
			switch(strtoupper($dataType))
			{
				case "RAW" :
					$returnObject["data"] = $Link->getChildTextContent("RAW", "");
					break;
				case "URL" :	
					$returnObject["data"] = $Link->getChildTextContent("URL", "");
					break;
				default :
					$returnObject["data"] = JSONEncodeMenu::encodeLinkNode($Link);
			}

			return $returnObject;
		}
		
		return null;
	}
	
	static function encodeFormListToJSON($linkNode)
	{
		$returnObject = array();

		$AllFormNodeLists = $linkNode->getElementsByTagName('formList');

		foreach ($AllFormNodeLists as $formNodeList) 
		{
			if($formNodeList->hasChildNodes())
			{
				foreach ($formNodeList->childNodes as $formNode)
				{
					$returnObject[] = $formNode->getAttribute("name");
				}
			}
		}
		return $returnObject;
	}
	static function encodeLinkNode($linkNode, $rowData = null, $fieldLookUp = null)
	{
		$returnObject = array();
		
		$returnObject['baseDirectory'] = null;
		$returnObject['address'] = null;
		$returnObject['parameters'] = array();
		
		if($linkNode == null)
			return "";
		if(strcasecmp($linkNode->nodeName, "link") != 0)
			return "";
	
		if($linkNode->getAttribute("type") == "html")
		{
			$returnObject['baseDirectory'] = HTML_BASE_DIRECTORY;	
		}	  
		
		if($linkNode->hasChildNodes())
		{
			foreach ($linkNode->childNodes as $childNode) 
			{
				switch (strtolower($childNode->nodeName))
				{
					case "address":
							$returnObject['address'] = trim($childNode->textContent);
						break;
					case "parameterlist":
						if($childNode->hasChildNodes())
						{
							foreach ($childNode->childNodes as $parameterNodes) 
							{
								
								$name = $parameterNodes->getAttribute("name");
								$value = $parameterNodes->getAttribute("value");
								$valueWasSet = false;
								if($value != "" || $value != NULL)
								{
									if(array_key_exists($value, $GLOBALS))
									{
										$valueWasSet = true;
										$value = $GLOBALS[$value];
									}
									else if(constant($value) !== NULL)
									{
										$valueWasSet = true;
										$value = constant($value);
									}
								}
								if($parameterNodes->hasChildNodes())
								{
									$subLinkNode = $parameterNodes->childNodes[0];
									switch(strtolower($subLinkNode->nodeName))
									{
										case "link":
											$valueWasSet = true;
											$value = JSONEncodeMenu::encodeTopLinkNodeToURL($subLinkNode, $rowData, $fieldLookUp);
											break;
										case "graph":
											$valueWasSet = true;
											//BRIAN: Add your function here to parse the graph.
											//$value = encodeTopLinkNodeToURL($subLinkNode, $rowData, $fieldLookUp);
											$value = JSONEncodeMenuGraph::encodeGraph($subLinkNode);
											break;
										case "pagewindow":
											$valueWasSet = true;
											$value = JSONEncodeMenu::encodePageWindow($subLinkNode);
											break;
										case "keycolumn":
											if($rowData != null && $fieldLookUp != null)
											{
												$valueWasSet = true;
												$keyColumnValue = trim($subLinkNode->textContent);
												$default = $subLinkNode->getAttribute("defaultValue");
												$value = isset($fieldLookUp[$keyColumnValue]) ? $rowData[$fieldLookUp[$keyColumnValue]] : $default;
											}
											else 
											{
												$name = "";
											}
											break;
										//PAUL: added case to extract text from a value tag in a link if the value tag has no children, else process as normal
										case "value":
											$valueWasSet = true;
											if($subLinkNode->hasChildNodes())
											{
												$value = $parameterNodes->arrayEncodeXML();
											} else 
											{
												$value = trim($parameterNodes->textContent);
											}
											break;
										default:
											$valueWasSet = true;
											$value = $parameterNodes->arrayEncodeXML();
											break;
									}
								}
								if(!$valueWasSet)
									$value = trim($parameterNodes->textContent);
								if($name != "")
									$returnObject['parameters'][$name] = $value;
							}
						}
						break;
				}
			}
		}
		else 
		{
			return trim($linkNode->textContent);
		}
		
		return $returnObject;
		
	}
	
	static function encodePageWindowsFromDOM($DomObject)
	{
		$JSONPageWindows = array();
		
		$PageWindows = $DomObject->getElementsByTagName('pageWindow');
		foreach ($PageWindows as $aPageWindow)
		{
			if(strcasecmp($aPageWindow->nodeName, "pageWindow") == 0)
			{
				if($aPageWindow->hasChildNodes())
				{
					$JSONPageWindows[] =  JSONEncodeMenu::encodePageWindow($aPageWindow);
				}
			}
		}
		return $JSONPageWindows;
	}
	
	static function encodePageWindow($aPageWindow)
	{
		if($aPageWindow == null) return null;
		if(!is_a($aPageWindow, "XMLNode") ) return null;
		if(!$aPageWindow->hasChildNodes()) return null;
		$returnObject = array();
		$windowStage = $aPageWindow->getAttribute("windowStage");
		$windowStage = $windowStage == "" ? JSONEncodeMenu::$defaultStage : $windowStage;
		
		$raiseToTop = $aPageWindow->getAttribute("raiseToTop");
		$raiseToTop = $raiseToTop == "false" ? false : true;
		$returnObject["reloadOnConnectionChange"] = strtolower($aPageWindow->getAttribute("reloadOnConnectionChange", 'false')) == 'true' ? true : false;;
		$returnObject["target"] = $aPageWindow->getAttribute("target");
		$returnObject["title"] = $aPageWindow->getChildTextContent("title");
		$returnObject["info"] = $aPageWindow->getChildTextContent("info");
		$returnObject["leftMenu"] = JSONEncodeMenu::encodeMenuNode($aPageWindow->findChildNode("leftMenu"), null, null, null, null);
		$returnObject["raiseToTop"] = $raiseToTop;
		$returnObject["windowStage"] = $windowStage;
		$returnObject["windowType"] = $aPageWindow->getAttribute("windowType", "NORMAL");

		$returnObject["panelHeaders"] = JSONEncodeMenu::encodePanelHeaders($aPageWindow->findChildNode("panelHeaders"));
		
		//Panel Name Set is used to check for duplicate names with in a window layout, Duplicate names will cause bad things to happen
		JSONEncodeMenu::$panelNameSet = array();
		
		$returnObject["content"] = JSONEncodeMenu::encodeContainerNode($aPageWindow, $returnObject["panelHeaders"]);
		//Clear Name set
		JSONEncodeMenu::$panelNameSet = null;
		return $returnObject;
	}

	static function encodePanelHeaders($node)
	{
		if($node != null)
		{
			$returnObject = array();
			$scope = $node->getAttribute("scope");
			$refreshEnabled = $node->getAttribute("refreshEnabled");
			$refreshEnabled = $refreshEnabled != "false" ? true : false;
			
			$refreshControl = $node->getAttribute("showRefreshControl");
			$refreshControl = $refreshControl != "false" ? true : false;
			
			$returnObject["scope"] = $scope;
			$returnObject["refreshEnabled"] = $refreshEnabled;
			$returnObject["refreshOptions"] = $node->getAttribute("refreshOptions");
			$returnObject["autoRefreshControls"] = JSONEncodeMenu::retrieveAutoRefresh($node->findChildNode("autoRefreshControls"));
			$returnObject["showRefreshControl"] = $refreshControl;
			return $returnObject;
		}
		return null;
	}

	static function retrieveAutoRefresh($node)
	{
		if($node != null)
		{
			$countdownVisible = $node->getChildTextContent("countdownVisible");
			$countdownVisible = $countdownVisible != "true" ? false : true;
			
			$timeVisible = $node->getChildTextContent("timeVisible");
			$timeVisible = $timeVisible != "false" ? true : false;
			
			$timeOptions = $node->getChildTextContent("timeOptions", "true");
			
			$returnObject["time"] = $node->getChildTextContent("time", -1); // -1
			$returnObject["timeVisible"] = $timeVisible; // true
			$returnObject["timeOptions"] = json_decode($timeOptions); // off always present [5, 15, 30, 60, 120, 300, 600]
			$returnObject["countdownVisible"] = $countdownVisible; //false
			return $returnObject;
		}
		return null;
	}
	
	static function getPanelContent($Node)
	{
		$returnObject = array();
		$returnObject['ContentType'] = "RAW";
		$returnObject['data'] = "";
		foreach ($Node as $PanelNode) 
		{
				/*
				 * The Panel can display a forth type of data called a layout, 
				 * a layout can render the same layout object  as a window with 
				 * in the Panel. This is not exposed because it is meant for 
				 * advanced layouts which need to be controlled and manipulated 
				 * by a javascript object such as the ad hoc and Tutorial panels. 
				 * Most all layouts can be achieved with out this option.
				 */
				if(strcasecmp($PanelNode->nodeName, "link") == 0)
				{
					$returnObject['ContentType'] = "LINK";
					$returnObject['data'] = JSONEncodeMenu::encodeTopLinkNodeToURL($PanelNode);
					break;
				}
				elseif (strcasecmp($PanelNode->nodeName, "raw") == 0)
				{
					$returnObject['ContentType'] = "RAW";
					$returnObject['data'] = trim($PanelNode->textContent);
					break;
				}
				elseif (strcasecmp($PanelNode->nodeName, "url") == 0)
				{
					$returnObject['ContentType'] = "URL";
					$returnObject['data'] = trim($PanelNode->textContent);
					break;
				}
		}
		return $returnObject;
	}

	static function encodeContainerNode($ContainerNode, $parentPanelHeaders)
	{
		if($ContainerNode->hasChildNodes())
		{
			foreach ($ContainerNode->childNodes as $childNode) 
			{
				$returnObject = array();
				switch (strtolower($childNode->nodeName))
				{
					case "panel":
						$returnObject['type'] = "panel";
						$returnObject['name'] = $childNode->getAttribute("name");
						$returnObject['name'] = $returnObject['name'] == "" ? uniqid() : $returnObject['name'];
						$returnObject['ContentType'] = null;
						$returnObject['data'] = null;
						$returnObject["reloadOnConnectionChange"] = strtolower($childNode->getAttribute("reloadOnConnectionChange", 'false')) == 'true' ? true : false;;
						
						$returnObject['panelHeaders'] = JSONEncodeMenu::encodePanelHeaders($childNode->findChildNode("panelHeaders"));
						if($returnObject['panelHeaders'] == "" || $returnObject['panelHeaders'] == null)
						{
							$returnObject['panelHeaders'] = $parentPanelHeaders;
						}
						
						$BadPanelName = false;
						
						if(is_array(JSONEncodeMenu::$panelNameSet))
						{
							if(key_exists( $returnObject['name'] ,JSONEncodeMenu::$panelNameSet))
							{
								$returnObject['ContentType'] = "RAW";
								$returnObject['data'] = <<<HERE
<div id="title">Error: Bad panel name!</div>
<table style='width:100%;height:100%'>
	<tr>
		<td align='center'>
			<h2>A panel with the name '{$returnObject['name']}' already exists within this page layout. A unique name must be assigned to this panel before the content can be displayed.</h2>
		</td>
	</tr>
</table>								
HERE;
								$returnObject['name'] = uniqid();
								$BadPanelName = true;
							}
						}
						
						
						if($childNode->hasChildNodes() && !$BadPanelName)
						{
							$panelData = JSONEncodeMenu::getPanelContent($childNode->childNodes);
							$returnObject['ContentType'] = $panelData['ContentType'];
							$returnObject['data'] = $panelData['data'];
						}
						$returnObject['overflow'] = $childNode->getAttribute("overflow");
						$returnObject['overflow'] = $returnObject['overflow'] == "" ? "auto" : $returnObject['overflow'];
						
						$returnObject['delayLoad'] = $childNode->getAttribute("delayLoad");
						$returnObject['delayLoad'] = $returnObject['delayLoad'] == "true" ? true : false;
						
						$returnObject['panelTitle'] = $childNode->getAttribute("panelTitle");
						$returnObject['panelTitle'] = $returnObject['panelTitle'] == "" ? null : $returnObject['panelTitle'];

						$returnObject['PrimaryContainer'] = $childNode->getAttribute("PrimaryContainer");
						$returnObject['PrimaryContainer'] = $returnObject['PrimaryContainer'] == "true" ? true : false;

						return $returnObject;
						break;
					case "splitpane":
						$returnObject['type'] = "splitPane";
						$returnObject['panelA'] = null;
						$returnObject['panelB'] = null;
						
						$returnObject['direction'] = strtolower($childNode->getAttribute("direction"));
						$returnObject['direction'] = $returnObject['direction'][0] == 'v' ? 'v' : 'h' ;
						
						$returnObject['splitPercent'] = $childNode->getAttribute("splitPercent");
						$returnObject['splitPercent'] = $returnObject['splitPercent'] == "" ? null : $returnObject['splitPercent'];
						
						$returnObject['allowResize'] = $childNode->getAttribute("allowResize");
						$returnObject['allowResize'] = $returnObject['allowResize'] == "false" ? false : true;
						
						$returnObject['maxSize'] = $childNode->getAttribute("maxSize");
						$returnObject['maxSize'] = $returnObject['maxSize'] == "" ? null : intval($returnObject['maxSize']);
						
						//showSplitSpacer
						$showSplitSpacer = $childNode->getAttribute("showSplitSpacer");
						if($showSplitSpacer != null)
						{
							$returnObject['showSplitSpacer'] = strtolower($showSplitSpacer) == 'true' ? true : false;
							//splitSpacerWidth
							$returnObject['splitSpacerWidth'] = $childNode->getAttribute("splitSpacerWidth", 3);
							if($returnObject['splitSpacerWidth'] != null)
							{
								$returnObject['splitSpacerWidth'] = intval($returnObject['splitSpacerWidth']);
							}
						}
						
						//styleOverride
						$returnObject['styleOverride'] = $childNode->getAttribute("styleOverride", "");
						
						$returnObject['panelA'] = array(
														'type'=>'panel',
														'name'=>uniqid(),
														'ContentType'=>'RAW',
														'data'=>"<div id='title'>No content given!</div><table style='width:100%;height:100%'><tr><td align='center'><h2>No content was specified for the panel</h2></td></tr></table>'"
													);
						
						
						$returnObject['panelB'] = array(
														'type'=>'panel',
														'name'=>uniqid(),
														'ContentType'=>'RAW',
														'data'=>"<div id='title'>No content given!</div><table style='width:100%;height:100%'><tr><td align='center'><h2>No content was specified for the panel</h2></td></tr></table>'"
													);

						if($childNode->hasChildNodes())
						{
							foreach ($childNode->childNodes as $PanelNode) 
							{
								if(strcasecmp($PanelNode->nodeName, "topPane") == 0 && $direction = 'h')
								{
									$returnObject['panelA'] = JSONEncodeMenu::encodeContainerNode($PanelNode, $parentPanelHeaders);
								}
								elseif(strcasecmp($PanelNode->nodeName, "bottomPane") == 0 && $direction = 'h')
								{
									$returnObject['panelB'] = JSONEncodeMenu::encodeContainerNode($PanelNode, $parentPanelHeaders);
								}
								elseif(strcasecmp($PanelNode->nodeName, "leftPane") == 0 && $direction = 'v')
								{
									$returnObject['panelA'] = JSONEncodeMenu::encodeContainerNode($PanelNode, $parentPanelHeaders);
								}
								elseif(strcasecmp($PanelNode->nodeName, "rightPane") == 0 && $direction = 'v')
								{
									$returnObject['panelB'] = JSONEncodeMenu::encodeContainerNode($PanelNode, $parentPanelHeaders);
								}
								elseif(strcasecmp($PanelNode->nodeName, "panelA") == 0)
								{
									$returnObject['panelA'] = JSONEncodeMenu::encodeContainerNode($PanelNode, $parentPanelHeaders);
								}
								elseif(strcasecmp($PanelNode->nodeName, "panelB") == 0)
								{
									$returnObject['panelB'] = JSONEncodeMenu::encodeContainerNode($PanelNode, $parentPanelHeaders);
								}
							}
						}
						return $returnObject;
						break;
					case "stage":
						$returnObject['type'] = "stage";

						$returnObject["name"] = $childNode->getAttribute("name");
						$returnObject["HasMenuBarContainer"] = $childNode->getAttribute("HasMenuBarContainer");
						$returnObject["top"] = intval($childNode->getAttribute("top"));
						$returnObject["botton"] = intval($childNode->getAttribute("botton"));
						$returnObject["left"] = intval($childNode->getAttribute("left"));
						$returnObject["right"] = intval($childNode->getAttribute("right"));
						$returnObject["titleBarType"] = $childNode->getAttribute("titleBarType");
						$returnObject["windowOptionType"] = $childNode->getAttribute("windowOptionType");
						$returnObject["windowControlTypes"] = $childNode->getAttribute("windowControlTypes");
						$returnObject["sizable"] = $childNode->getAttribute("sizable");
						return $returnObject;
						break;
				}
			}
		}
	}
}
?>