<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/

function TableDefinitionObject_COLUMN_CORE_PARSER(&$subNode, &$aColumn,&$componentAvalibility,&$returnObject) {
	
	if($aColumn == null)
		$aColumn = array();

	switch (strtolower($subNode->nodeName))
	{
		case "enable_column_edit":
			$aColumn["editable"] = true;
			break;
		case "disable_column_edit":
			$aColumn["editable"] = false;
			break;
		case "auto_generated":
			$aColumn["auto_generated"] = true;
			$aColumn["editable"] = false;
			break;
		case 'info':
			$aColumn['info'] = trim($subNode->textContent);
			break;
		case 'c_sql_name':
		case 'sql_name':
			$aColumn['sql_name'] = trim($subNode->textContent);
			break;
		case 'c_title':
		case 'title':
			$aColumn['wrap'] = trim($subNode->getAttribute("wrap")) == "true" ? true : false;
			$aColumn['title'] = trim($subNode->textContent);
			break;
		case 'c_pkey':
			$aColumn['primaryKey'] = strtoupper(trim($subNode->textContent));
			$aColumn['primaryKey'] = $aColumn['primaryKey'] == "Y" || $aColumn['primaryKey'] == "T" || $aColumn['primaryKey'] == "P"? true : false;
			if($aColumn['primaryKey'])
				$returnObject["primaryKeys"][] = $aColumn['name'];
			break;
		case 'primary_key':
			$aColumn['primaryKey'] = true;
			$returnObject["primaryKeys"][] = $aColumn['name'];
			break;
		case "c_presentation":
		case "type":
			$aColumn['fieldType'] = trim($subNode->textContent) != "" ? strtolower(trim($subNode->textContent)) :"s";
			
			if(($aColumn['fieldType'] == 'bg' || $aColumn['fieldType'] == "bg_wo") && !isset($aColumn['inline_histogram']))
			{
				$aColumn['inline_histogram'] = array();
				$aColumn['inline_histogram']['style'] = "";
				$aColumn['inline_histogram']['flipColor'] = false;
				$aColumn['inline_histogram']['columnName'] = trim($aColumn["name"], ".");
				$componentAvalibility['inlineGraph'] = true;
			}
			break;
		case 'formatnumber':
		case 'formatenumber':
			$formatnumber = array();
			$formatnumber['round'] = strtolower($subNode->getAttribute('round', 'false')) == 'true' ? true : false;
			$formatnumber['parseInt'] = strtolower($subNode->getAttribute('parseInt', 'false')) == 'true' ? true : false;
			$formatnumber['parseFloat'] = strtolower($subNode->getAttribute('parseFloat', 'false')) == 'true' ? true : false;
			
			$formatnumber['toExponentialVal'] = intval($subNode->getAttribute('toExponentialVal', -1));
			$formatnumber['toFixedVal'] = intval($subNode->getAttribute('toFixedVal', -1));
			$formatnumber['toPrecisionVal'] = intval($subNode->getAttribute('toPrecisionVal', -1));
			$formatnumber['toBaseVal'] = intval($subNode->getAttribute('toBaseVal', 10));
			$formatnumber['pre'] = ($subNode->getAttribute('pre', ""));
			$formatnumber['post'] = ($subNode->getAttribute('post', ""));
			$aColumn['formatnumber'] = $formatnumber;
		case "c_sort":
			$value = strtoupper(trim($subNode->textContent));
			$aColumn['sort_enable'] = @$value[0] == "N" || @$value[0] == "F" ? false : true;
			break;
		case "sort_enable":
			$aColumn['sort_enable'] = true;
			break;
		case "sort_disable":
			$aColumn['sort_enable'] = false;
			break;
		case "c_prefill":
			if($subNode->hasChildNodes())
			{
				$aColumn['isPrefiled'] = array();
				foreach($subNode->childNodes as $prefillInfo)
				{
					switch(strtolower($prefillInfo->nodeName))
					{
						case "table":
							$aColumn['isPrefiled']['table'] = trim($prefillInfo->textContent);
							break;
						case "column":
							$aColumn['isPrefiled']['column'] = trim($prefillInfo->textContent);
							break;
					}
				}
			}
			else 
			{
				$value = strtoupper(trim($subNode->textContent));
				$aColumn['isPrefiled'] = $value[0] == "Y" || $value[0] == "T" ? true : null;
			}
			break;
		case "prefill_enable":
			if($subNode->hasChildNodes())
			{
				$aColumn['isPrefiled'] = array();
				foreach($subNode->childNodes as $prefillInfo)
				{
					switch(strtolower($prefillInfo->nodeName))
					{
						case "table":
							$aColumn['isPrefiled']['table'] = trim($prefillInfo->textContent);
							break;
						case "column":
							$aColumn['isPrefiled']['column'] = trim($prefillInfo->textContent);
							break;
					}
				}
			}
			else 
			{
				$aColumn['isPrefiled'] = true;
			}
			break;
		case "c_drill":
			$value = strtoupper(trim($subNode->textContent));
			$aColumn['canDrill'] = $value[0] != "N" && $value[0] != "F" ? true : false;
			break;
		case "drill_enable":
			$aColumn['canDrill'] = true;
		case "drill_disable":
			$aColumn['canDrill'] = false;
			break;
		case "c_lookup":
		case "lookup":
			$value = array();
			$value['table'] = $subNode->getAttribute('table');
			$value['column'] = $subNode->getAttribute('column');
			break;
		case "c_search":
			$value = strtoupper(trim($subNode->textContent));
			$aColumn['isSearchable'] = $value[0] == "N" || $value[0] == "F" ? false : true;
			break;
		case "search_enable":
			$aColumn['isSearchable'] = true;
		case "search_disable":
			$aColumn['isSearchable'] = false;
			break;
		case "graphattributes":
		case "inline_histogram":
			$colValue = 100;
			$isInline = false;
			$queryFound = false;
			
			$dataColumn = array();
			$dataColumn['sql_name']	= key_exists('sql_name', $aColumn) ? $aColumn['sql_name'] : null;
			$columnName = trim($aColumn["name"], ".");
			foreach($subNode->childNodes as $graphValueSource)
			{
				switch(strtolower($graphValueSource->nodeName))
				{
					case "value":
						$colValue = trim($graphValueSource->textContent);
						$isInline = false;
						$queryFound = true;
						break;
					case "inrowcompare":
						$colValue = trim($graphValueSource->textContent);
						$isInline = false;
						$queryFound = true;
						break;
					case "maxfromcolumn":
						$colValue = "MAX(" . trim($graphValueSource->textContent) . ")";
						$isInline = false;
						$queryFound = true;
						break;
					case "inlinequery":
						$colValue = trim($graphValueSource->textContent);
						$isInline = true;
						$queryFound = true;
						break;
					case "filequery":
						$colValue = file_get_contents(TABLE_DEFINITION_DIRECTORY . trim($graphValueSource->textContent));
						$isInline = true;
						$queryFound = true;
						break;
				}
				if($queryFound) break;
			}
			if($isInline)
			{
				$returnObject["commonTableExpressions"][] = trim($aColumn["name"], ".") . "_inline_histogram_Table (Value_to_use_for_inline_histogram) as (" .
															"select * from table(" . $colValue . ") FETCH FIRST ROW ONLY)";
				$returnObject["otherTablesToInclude"][] = trim($aColumn["name"], ".") . "_inline_histogram_Table";
				$dataColumn['sql_name'] = "((" . $aColumn['sql_name'] . "/REAL(" . trim($aColumn["name"], ".") . "_inline_histogram_Table.Value_to_use_for_inline_histogram" . "))*100)";
				$columnName = trim($aColumn["name"], ".") . "_inline_histogram";
			}
			$aColumn['inline_histogram'] = array();
			$aColumn['inline_histogram']['style'] = $subNode->getAttribute('style');
			$aColumn['inline_histogram']['flipColor'] = str_split(strtolower($subNode->getAttribute('flipColor')));
			$aColumn['inline_histogram']['flipColor'] = ($aColumn['inline_histogram']['flipColor'][0] == "n" || $aColumn['inline_histogram']['flipColor'][0] == 'f') ? false : true;
			$aColumn['inline_histogram']['columnName'] = $columnName;
			$componentAvalibility['inlineGraph'] = true;
			
			$dataColumn['name']	= $columnName;
			
			$returnObject["components"]["column"][$dataColumn['name']] = $dataColumn;
			
			
			break;
		case "c_column_mask_file":
		case "column_mask_file":
			if(!isset($aColumn["mask"])) $aColumn["mask"] = array();
			if(file_exists(TABLE_DEFINITION_DIRECTORY . trim($subNode->textContent)))
			{
				TableDefinitionObject_COLUMN_MASK( new XMLNode(null, file_get_contents(TABLE_DEFINITION_DIRECTORY . trim($subNode->textContent))), $aColumn["mask"], $componentAvalibility);
			}
			$aColumn["nullMask"] = isset($aColumn["mask"][null]) ? $aColumn["mask"][null] : null;
			break;
		case "c_column_mask":
		case "column_mask":
			if(!isset($aColumn["mask"])) $aColumn["mask"] = array();
			TableDefinitionObject_COLUMN_MASK( $subNode, $aColumn["mask"], $componentAvalibility);
			$aColumn["nullMask"] = isset($aColumn["mask"][null]) ? $aColumn["mask"][null] : null;
			break;
		case "c_link":
		case "link":
			$aColumn["components"]['link'] = trim($subNode->textContent);
			$componentAvalibility['link'] = true;
			break;
		case "c_image":
		case "image":
			$aColumn["components"]['image'] = trim($subNode->textContent);
			$componentAvalibility['image'] = true;
			break;
		case "c_hide_value_if_not_masked":
			$value = strtoupper(trim($subNode->textContent));
			$aColumn['hide_Non_Maked_Value'] = $value[0] == "N" || $value[0] == "F" ? false : true;
			break;
		case "hide_non_maked_values_enable":
			$aColumn['hide_Non_Maked_Value'] = true;
		case "hide_non_maked_values_disable":
			$aColumn['hide_Non_Maked_Value'] = false;
			break;
		case "c_mask_display_order":
			$tempValue = trim($subNode->textContent);
			$aColumn['display'] = array();
			$tempValue = str_split($tempValue);
			foreach($tempValue as $value)
			{
				switch(strtolower($value)) {
					case "v":
						$aColumn['display'][] = array('type'=>'component', 'value'=>'value');
						break;
					case "m":
						$aColumn['display'][] = array('type'=>'component', 'value'=>'mask');
						break;
					case "r":
						$aColumn['display'][] = array('type'=>'component', 'value'=>'reference');
						break;
					case "l":
						$aColumn['display'][] = array('type'=>'component', 'value'=>'link');
						break;
					case "i":
						$aColumn['display'][] = array('type'=>'component', 'value'=>'image');
						break;
					case "g":
						$aColumn['display'][] = array('type'=>'component', 'value'=>'inlineGraph');
						break;
				}
			}
			break;
		case "display":
			$aColumn['display'] = array();
			foreach($subNode->childNodes as $node)
			{
				switch(strtolower($node->nodeName)) {
					case "component":
						$aColumn['display'][] = array('type'=>'component', 'value'=>$node->getAttribute("type"));
						break;
					case "text":
						$aColumn['display'][] = array('type'=>'text', 'value'=>htmlspecialchars($node->textContent));
						break;
				}
			}
			break;
		default:
			$nodeName = strtolower($subNode->nodeName);
			if(preg_match("/^default_[a-zA-Z0-9]+_icon$/", $nodeName) || preg_match("/^c_default_[a-zA-Z0-9]+_icon$/", $nodeName))
			{
				$temp = substr($nodeName, 8);
				$aColumn["components"][$temp[1]] = trim($subNode->textContent);
			} 
			else 	if(isset(ArrayEncodeTableDefinition::$GENERIC_XML_OBJECTS[$nodeName]))
			{
				$tempFunction = ArrayEncodeTableDefinition::$GENERIC_XML_OBJECTS[$nodeName];
				$nullVaule = null;
				$tempFunction($subNode, $aColumn["components"], $componentAvalibility, $nullVaule, false);
				
			}
			break;
	}
}

function TableDefinitionObject_COLUMN_MASK(&$childNode, &$returnObject, &$componentAvalibility) {
	foreach($childNode->childNodes as $baseMaskNode)
	{
		if(strtolower($baseMaskNode->nodeName) == 'value_mask')
		{
			$maskNode = array();
			$maskNode['value'] = $baseMaskNode->getAttribute("value");
			foreach($baseMaskNode->childNodes as $maskNodes)
			{
				$nodeName = strtolower($maskNodes->nodeName);
				switch($nodeName)
				{
					case "mask":
						$maskNode['mask'] = trim($maskNodes->textContent);
						$componentAvalibility['mask'] = true;
						break;
					case "link":
						$maskNode['link'] = trim($maskNodes->textContent);
						$componentAvalibility['link'] = true;
						break;
					case "image":
						$maskNode['image'] = trim($maskNodes->textContent);
						$componentAvalibility['image'] = true;
						break;
					default:
						if(isset(ArrayEncodeTableDefinition::$GENERIC_XML_OBJECTS[$nodeName]))
						{
							$tempFunction = ArrayEncodeTableDefinition::$GENERIC_XML_OBJECTS[$nodeName];
							$nullVaule = null;
							$tempFunction($maskNodes, $maskNode, $componentAvalibility, $nullVaule, false);
						}
						break;
				}
			}
			$returnObject[$maskNode['value']] = $maskNode;
		}
	}
	
}