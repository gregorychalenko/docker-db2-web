<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/

ArrayEncodeTableDefinition::$GENERIC_XML_OBJECTS['reference'] = 'TableDefinitionObject_REFERENCE';
ArrayEncodeTableDefinition::$GENERIC_XML_OBJECTS['c_reference'] = 'TableDefinitionObject_REFERENCE';

function TableDefinitionObject_REFERENCE(&$childNode, &$returnObject, &$displayElements, &$displayColumns, $isMainTableObject=true) {
	
	if($isMainTableObject && !isset($returnObject["components"]['reference'])) $returnObject["components"]['reference'] = array();
	
	$references = array();
	$references['name'] = strtoupper($childNode->getAttribute("name"));
	$references['ref'] = array();
	foreach ($childNode->childNodes as $actionNode) 								
	{
		switch (strtolower($actionNode->nodeName))
		{
			case 'c_title':
			case 'title':
				$references['title'] = trim($actionNode->textContent);
				break;
			case 'reftype':
				$references['reftype'] = trim($actionNode->textContent);
				break;
			case 'refvalue':
				$references['refvalue'] = trim($actionNode->textContent);
				break;
			case 'icon':
				$references['icon'] = trim($actionNode->textContent);
				break;
			case 'displaycolumnsset':
				$references['displayColumnsSet'] = trim($actionNode->textContent);
				break;
			case 'frame':
				$references['frame'] = trim($actionNode->textContent);
				break;
			case 'window':
				$references['window'] = trim($actionNode->textContent);
				break;
			case 'stage':
				$references['stage'] = trim($actionNode->textContent);
				break;
			case 'refaction':
				$references['refaction'] = trim($actionNode->textContent);
				break;
			
			case 'ref':
				$ref = array();
				$ref['foreign_column_name'] = $actionNode->getAttribute("foreign_column_name");
				foreach ($actionNode->childNodes as $aNode) 								
				{
					switch (strtolower($aNode->nodeName))
					{
						case 'local_column_name':
							$ref['local_column_name'] = trim($aNode->textContent);
							break;
						case 'value':
							$ref['value'] = trim($aNode->textContent);
							break;
						case 'comparetype':
							$ref['comparetype'] = trim($aNode->textContent);
							break;
					}
				}
				$references['ref'][] = $ref;
				break;
		}
	}
	if($displayElements !== null && $displayColumns !== null)
	{
		if(isset($displayElements['reference']))
		{
			if(!isset($displayElements['reference'][$references['name']]))
			{
				$displayElements['reference'][$references['name']] = true;
				$aDisplayCol = array();
				$aDisplayCol['name'] = $references['name'];
				$aDisplayCol['type'] = 'reference'; 
				$aDisplayCol['isVisible'] = false; 
				$displayColumns[] = $aDisplayCol;
			}
		}
		else 
		{
			$displayElements['reference'] = array();
			$displayElements['reference'][$references['name']] = true;
			$aDisplayCol = array();
			$aDisplayCol['name'] = $references['name'];
			$aDisplayCol['type'] = 'reference'; 
			$aDisplayCol['isVisible'] = false; 
			$displayColumns[] = $aDisplayCol;
		}
	} else if($displayElements !== null && $displayColumns === null)
	{
		$displayElements['reference'] = true;
	}
	if($isMainTableObject)
		$returnObject["components"]['reference'][$references['name']] = $references;
	else 
		$returnObject['reference'] = $references;
}