<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/


/**
 * The Connection Class is used to create a connection to either a DB2, Apache Derby or Cloudscape
 * database. It supports either a direct connection to a hostname and port number
 * or a connection through a DB2 Client.
*/

/** Include your corresponding Statement Class */
include_once(PHP_INCLUDE_BASE_DIRECTORY . 'DBStatement.php');

abstract class Connection {

	/** Boolean indicating whether you are using a cataloged or direct connection
	* @var boolean */
	public $cataloged = false;
	/** Database name
	* @var boolean */
	public $database = "";
	/** Connection Description name
	* @var boolean */
	public $description = "";
	/** Schema name
	* @var string */
	public $schema = "";
    /** User Name
    * @var string */
	public $username = "";
    /** Password
    * @var string */
	public $password = "";
    /** Hostname
    * @var string */
	public $hostname = "";
    /** Database port number
    * @var string */
	public $portnumber = "";
    /** Database connection resource
    * @var resource */
	public $dbconn = false;
    /** Set TRUE is a valid connection exists
    * @var boolean */
	public $connected = false;
    /** State of the connection
    * @var string */
	public $SQLState = 0;
    /** An Error message if one exsists
    * @var string */
	public $SQLErrorMSG = "";
	  /** Indicates weather to save the connection
    * @var string */
	public $saveConnection = NULL;
	  /** Indicates weather to use a presistent connection
    * @var string */
	public $usePersistentConnection = USE_PERSISTENT_CONNECTION;
	/** Set TRUE trustedContext is enabled
    * @var boolean */
	public $trustedContextEnabled = false;
	/** Indicated the PHP extension used
	 * set to null if non is needed
	 * @var string */
	public static $requiredDBExtension = false;
	/** Indicated the PHP extension minimum version needed
	 * set to null if non is needed
	 * @var float */
	public static $requiredDBExtensionMinVersion = null;
	/** Database Managment System
	 * @var float */
	public static $DBMS = "";
	
	public $statementClass = "";

	abstract public function driverCheck();
	abstract public function newStatement($stmt_text, $prepare_statment = FALSE, $verbose = FALSE, $ForwardOnlyScroll = TRUE, $getRowCount = FALSE);
	/**
	  * Requires a database name, schema, userid and password.
	  * If the hostname and portnumber are also included it will try to connect directly to the database.
	  * With only a database name, it will try to connect through a local DB2 Client.
	*/
	abstract public function __construct($database, $schema, $username, $password, $hostname, $portnumber, $usePersistentConnection = USE_PERSISTENT_CONNECTION, $enableTrustedContext = false);
	abstract public static function testConnection($database, $username, $password, $hostname, $portnumber, $usePersistentConnection = USE_PERSISTENT_CONNECTION);
	abstract public function setTrustedContextUsers($userName, $password);
	abstract public function testTrustedContextUser($userName, $password);
	/**
	 * Sets the autocommit
	 * @return resource
	 */
	abstract public function setAutoCommit($SQLAdHoc_AutoCommit);
	/**
	 * executs a commit
	 * @return resource
	 */
	abstract public function commit();
	/**
	 * Executs a rollback
	 * @return resource
	 */
	abstract public function rollback();
	/**
	 * Returns TRUE is a valid connection was established.
	 * @return boolean
	 */
	public function connected() {
		return $this->connected;
	}

	/**
	 * Returns TRUE is a valid connection was established.
	 * @return boolean
	 */
	public function dbconn() {
		return $this->dbconn;
	}
	/**
	 * Sets the database schema for all subsequent database requests.
	 *
	 * If the schema variable is blank the schema is set by default
	 * to the schema corresponding to the username.
	 */
	abstract public function setSchema($schema = null);
	abstract public function setDescription($description);

	/**
	 * Close the database connection.
	 */
	abstract public function close();
}