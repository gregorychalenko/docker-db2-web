<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/

include_once(PHP_INCLUDE_BASE_DIRECTORY . "JSONEncodeMenu.php");
include_once(PHP_INCLUDE_BASE_DIRECTORY . "ObjectXMLNode_" . XML_PARSING_ENGINE . ".php");

class JSONEncodeAction {
	
	static function fromFile($directory, $filename)
	{
		if(file_exists($directory.$filename))
			return JSONEncodeAction::fromString(file_get_contents($directory . $filename));
		return null;
	}
	
	static function fromString($actionXML)
	{
		if($actionXML != "")
		{
			try 
			{
				$doc = new XMLNode();
				if($doc->loadXML($actionXML) !== false)
				{
					return JSONEncodeAction::fromDOM($doc);
				}
				else 
				{
					return null;
				}
			}
			catch (Exception $e)
			{
				return null;
			}
		}
		return null;		
	}
	
	static function fromDOM($actionXMLnode)
	{
		if(is_object($actionXMLnode))
		{
			if($actionXMLnode->hasChildNodes())
			{
				$returnObject = array();
				$returnObject["suppressAutomaticErrors"] = $actionXMLnode->getAttribute("suppressAutomaticErrors");
				$returnObject["suppressAutomaticErrors"] = $returnObject["suppressAutomaticErrors"] == "true" ?  true : false;
				
				$returnObject["lockScreen"] = $actionXMLnode->getAttribute("lockScreen");
				$returnObject["lockScreen"] = strtolower($returnObject["lockScreen"]) == "true" ? true : false;
				
				$returnObject["type"] = "action";
				$returnObject["name"] = $actionXMLnode->getAttribute("name");
				$returnObject["actionType"] = $actionXMLnode->getAttribute("type");
				$returnObject["message"] = $actionXMLnode->getChildTextContent("message");
				$returnObject["parameterList"] = JSONEncodeAction::encodeParameterList($actionXMLnode);
				$returnObject["tasks"] = JSONEncodeAction::encodeFollowOnAction($actionXMLnode);
				return $returnObject;
			}
		}
		return null;
	}
	
	
	static function encodeParameterList($node)
	{
		$returnObject = array();
		if($node->hasChildNodes())
		{
			foreach ($node->childNodes as $childNode)
			{
				if(strcasecmp($childNode->nodeName, "parameterList") == 0)
				{
					if($childNode->hasChildNodes())
					{
						foreach ($childNode->childNodes as $parameterNode)
						{
							if(strcasecmp($parameterNode->nodeName, "parameter") == 0)
							{
								$returnObject[] = JSONEncodeAction::encodeParameterNode($parameterNode);
							}
						}
					}
				}
			}
		}
		return $returnObject;
	}

	static function encodeFollowOnAction($node)
	{
		
		$returnObject = array();
		if($node->hasChildNodes())
		{
			foreach ($node->childNodes as $childNode)
			{
				if(strcasecmp($childNode->nodeName, "followOnAction") == 0 || strcasecmp($childNode->nodeName, "if") == 0 || strcasecmp($childNode->nodeName, "ifNot") == 0)
				{
					$returnObject[] = JSONEncodeAction::encodeFollowOnActionNode($childNode);
				}
				if(strcasecmp($childNode->nodeName, "task") == 0)
				{
					$returnObject[] = array("type" => "task", "taskList" => JSONEncodeAction::encodeTask($childNode));
				}
				if(strcasecmp($childNode->nodeName, "declareActions") == 0)
				{
					$taskList = JSONEncodeAction::encodeTask($childNode);
					array_unshift($taskList["tasks"], array("type"=>"break"));
					$returnObject[] = array("type" => "task", "taskList" => $taskList);
				}
			}
		}
		return $returnObject;
	}
	
	static function encodeFollowOnActionNode($childNode)
	{
		$returnObject = array();
		$negCon = strtolower($childNode->getAttribute("negCondition"));
		$negCon = strtolower($negCon) == "true" ? true : (strcasecmp($childNode->nodeName, "ifNot") == 0 ? true : false);
		
		$conditionCompareType = $childNode->getAttribute("conditionCompairType");
		$conditionCompareType = $conditionCompareType == "" ? $childNode->getAttribute("conditionCompareType") : $conditionCompareType;
		$conditionCompareType = $conditionCompareType == "" ? $childNode->getAttribute("op") : $conditionCompareType;
		
		$returnObject["type"] = "IF";
		$returnObject["name"] = $childNode->getAttribute("name");
		$returnObject["negCondition"] = $negCon;
		$returnObject["compareOn"] = $childNode->getAttribute("compareOn");
		$returnObject["compareOnType"] = $childNode->getAttribute("compareOnType");
		$returnObject["condition"] = $childNode->getAttribute("condition");
		$returnObject["conditionType"] = $childNode->getAttribute("conditionType");
		$returnObject["conditionCompareType"] = $conditionCompareType;
		
		$value = $childNode->getAttribute("valueA");
		if($value != "")
		{
			$returnObject["compareOn"] = $value;
			$returnObject["compareOnType"] = "RAW";
		}
		
		$value = $childNode->getAttribute("valueB");
		if($value != "")
		{
			$returnObject["condition"] = $value;
			$returnObject["conditionType"] = "RAW";
		}
		
		$value = $childNode->getAttribute("blockA");
		if($value != "")
		{
			$returnObject["compareOn"] = $value;
			$returnObject["compareOnType"] = "BLOCKVALUE";
		}
		
		$value = $childNode->getAttribute("blockB");
		if($value != "")
		{
			$returnObject["condition"] = $value;
			$returnObject["conditionType"] = "BLOCKVALUE";
		}
		
		$value = $childNode->getAttribute("paramA");
		if($value != "")
		{
			$returnObject["compareOn"] = $value;
			$returnObject["compareOnType"] = "CONSTANT";
		}
		
		$value = $childNode->getAttribute("paramB");
		if($value != "")
		{
			$returnObject["condition"] = $value;
			$returnObject["conditionType"] = "CONSTANT";
		}
		
		$value = $childNode->getAttribute("returnValueA");
		if($value != "")
		{
			$returnObject["compareOn"] = $value;
			$returnObject["compareOnType"] = "RETURNOBJECT";
		}
		
		$value = $childNode->getAttribute("returnValueB");
		if($value != "")
		{
			$returnObject["condition"] = $value;
			$returnObject["conditionType"] = "RETURNOBJECT";
		}
		
		$value = $childNode->getAttribute("fixedA");
		if($value != "")
		{
			$returnObject["compareOn"] = $value;
			$returnObject["compareOnType"] = "FIXED";
		}
		
		$value = $childNode->getAttribute("fixedB");
		if($value != "")
		{
			$returnObject["condition"] = $value;
			$returnObject["conditionType"] = "FIXED";
		}
		
		$returnObject["taskList"] = JSONEncodeAction::encodeTaskList($childNode);
		return $returnObject;
		
	}
	
	static function encodeParameterNode($node)
	{
		if($node == null)
			return null;
		$returnObject = array();
		$returnObject["type"] = $node->nodeName;
		$returnObject["name"] = $node->getAttribute("name");
		$returnObject["parameterType"] = $node->getAttribute("type");
		$returnObject["value"] = $node->getChildTextContent("value");
		$returnObject["defaultValue"] = $node->getChildTextContent("defaultValue");
		$returnObject["check"] = JSONEncodeAction::encodeCheckNode($node->findChildNode("check"));
		return $returnObject;
	}
	
	static function encodeCheckNode($node)
	{
		if($node == null)
			return null;
		
		$returnObject = array();
		
		if($node->hasChildNodes())
		{
			foreach ($node->childNodes as $childNode)
			{
				$negCondition = null;
				switch ($childNode->nodeName)
				{	
					case "if":
					case "onMatch":
						$negCondition = false;
						break;
					case "ifNot":
					case "onNonMatch":
						$negCondition = true;
						break;	
				}
				if($negCondition !== null)
				{
					$MatchNode = array();
					$conditionCompareType = $childNode->getAttribute("conditionCompairType");
					$conditionCompareType = $conditionCompareType == "" ? $childNode->getAttribute("conditionCompareType") : $conditionCompareType;
					$MatchNode["type"] = "IF";
					$MatchNode["negCondition"] = $negCondition;
					$MatchNode["condition"] = $childNode->getAttribute("condition");
					$MatchNode["conditionType"] = $childNode->getAttribute("conditionType");
					$MatchNode["conditionCompareType"] = $conditionCompareType;
					$MatchNode["taskList"] = JSONEncodeAction::encodeTaskList($childNode);
					$returnObject[] = $MatchNode;
				}
			}
		}
			
		
		return $returnObject;
	}
	
	static function encodeTaskList($node)
	{
		$returnObject = array();
		if($node->hasChildNodes())
		{
			foreach ($node->childNodes as $childNode)
			{
				if(strcasecmp($childNode->nodeName, "task") == 0)
				{
					$returnObject[] = JSONEncodeAction::encodeTask($childNode);
				}
			}
		}
		return $returnObject;
	}
	
	static function encodeTask($childNode)
	{
		$returnObject = array();
		$returnObject["type"] = "taskList";
		$returnObject["tasks"] = array();
		
		foreach ($childNode->childNodes as $taskNode)
		{
			switch ($taskNode->nodeName)
			{	
				case "if":
				case "ifNot":
				case "followOnAction":
					$returnObject["tasks"][] = JSONEncodeAction::encodeFollowOnActionNode($taskNode);
					break;
				case "alert":
					$returnObject["tasks"][] = array("type"=>"alert", "message" => trim($taskNode->textContent));
					break;
				case "echo":
					$returnObject["tasks"][] = array("type"=>"echo", "message"=> trim($taskNode->textContent));
					break;
				case "setGlobal":
				case "assignSharedConstant":
					$returnObject["tasks"][] = JSONEncodeAction::encodeParameterNode($taskNode);
					break;	
				case "setLocal":
				case "assignLocalParameter":
					$returnObject["tasks"][] = JSONEncodeAction::encodeParameterNode($taskNode);
					break;					
				case "action":
					$returnObject["tasks"][] = JSONEncodeAction::fromDOM($taskNode);
					break;
				case "loadPage":
					$returnObject["tasks"][] = array("type" => "loadPage",
										"links" => JSONEncodeMenu::retrieveLinksFromDOM($taskNode),
										"pageLayouts"=> JSONEncodeMenu::encodePageWindowsFromDOM($taskNode));
					break;
				case "callAction":
				case "gotoAction":
					$returnObject["tasks"][] = array("type"=>"callAction", "name"=> $taskNode->getAttribute("name"));
					break;
				case "callGlobalAction":
					$returnObject["tasks"][] = array("type"=>"callGlobalAction", "name"=> $taskNode->getAttribute("name"));
					break;
				case 'windowReload' :
					$returnObject["tasks"][] = array("type"=>"windowReload");
					break;
				case "panelReload":
					$returnObject["tasks"][] = array("type"=>"panelReload", "name"=> $taskNode->getAttribute("name"));
					break;
				case "blockUpdate":
					$returnObject["tasks"][] = array("type"=>"blockUpdate");
					break;
				case "setActionReturn":
					$returnObject["tasks"][] = array("type"=>"setActionReturn", "value"=> $taskNode->getAttribute("value"), "parameterType"=> $taskNode->getAttribute("type", "fixed"));
					break;
				case "break":
					$returnObject["tasks"][] = array("type"=>"break");
					break;
				case "breakIf":
				case "breakControlGroup":
					$returnObject["tasks"][] = array("type"=>"breakControlGroup");
					break;
				case "breakCheck":
					$returnObject["tasks"][] = array("type"=>"breakCheck");
					break;
				case "return":
					$returnObject["tasks"][] = array("type"=>"return");
					break;
				case "exit":
					$returnObject["tasks"][] = array("type"=>"exit");
					break;
				case "lockScreen":
					$returnObject["tasks"][] = array("type"=>"lockScreen");
					break;
				case "unlockScreen":
					$returnObject["tasks"][] = array("type"=>"unlockScreen");
					break;
				case "openContextMenu":
					$returnObject["tasks"][] = array("type"=>"openContextMenu", "baseDir"=>$taskNode->getAttribute("baseDir"));
					break;
				case "getConnection":
					$returnObject["tasks"][] = JSONEncodeAction::encodeParameterNode($taskNode);
					break;
					
					
			}
		}
		
		return $returnObject;
	}
}
	
?>
