<?php

define('TE_NOT_CONNECTED',"TE Not Connected");

define('TE_NO_CONNECTION_FOUND', "No connection found.");

define('ACTION_NOT_FOUND_W_NAME', 'Action "?ACTION?" not found');

define('ACTION_NOT_FOUND', 'Action not found');

define('XML_LOAD_ERROR', "\"XML load error\"");

define('UNKNOWEN_ERROR', "\"Unkowen error\"");

define('EMPTY_FILE',"\"Empty file\"");

define('FILE_NOT_FOUND', "\"File not found\"");

define('NOT_CONNECTED_MESSAGE', "No connection found please login to a database");
