<?php

define('DG_PARAMETER_NOT_FOUND',"Error: Required parameters not found...");

define('DG_UNABLE_TO_ACCESS_FILE',"Error: Unable to access file '?FILE_NAME?'.");

define('DG_INVALID_FILE_NAME',"Error: Invalid file name '?FILE_NAME?'.");

define('DG_SERVER_NOT_FOUND',"Error: DG server not found...");

define('DG_COUND_NOT_RETERVE_DATA',"Error: Could not reterve data from DG server...");

define('',"");