<?php

define('WMD_PARAMETER_NOT_FOUNT',"Error: Required parameters not found...");

define('WMD_UNABLE_TO_ACCESS_FILE',"Error: Unable to access file '?FILE_NAME?'.");

define('WMD_INVALID_FILE_NAME',"Error: Invalid file name '?FILE_NAME?'.");

define('WMD_SERVER_NOT_FOUND',"Error: WMD server not found...");

define('WMD_COUND_NOT_RETERVE_DATA',"Error: Could not retrieve data from WMD server...");

define('',"");