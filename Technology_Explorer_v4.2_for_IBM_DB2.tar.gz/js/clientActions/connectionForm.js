/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
function checkPasswordForDB2Connect(object)
{
	if(object.value == "")
	{
		object.setStyle({background:"#FF7777"});
	}
	else
	{
		object.setStyle({background:"#77FF77"});
	}
	
}

CORE_CLIENT_ACTIONS.set("DBConnectionNewConnectionForm",Class.create(basePageElement, {
	initialize: function($super, callParameters) {
		$super(callParameters.uniqueID + "_ConnectionForm", "DBConnectionNewConnectionForm");
			
		this.parentStageID = callParameters.stageID;
		this.parentWindowID = callParameters.windowID;
		this.parentPanelID = callParameters.panelID;

		this.callParameters = callParameters;
		
		var parentPanel = getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID);
		
		if(parentPanel != null)
		{
			parentPanel.registerNestedObject(this.elementUniqueID, this);
		}

		this.draw();
	},
	
	insertConnectionInfo : function(connectionLocation) {

		var database = "";
		var host = "";
		var port = "";
		var user = "";
		var password = "";
		var comment = "";
		
		var connection = CONNECTION_MANAGER_CONNECTION_LIST[connectionLocation];
		if(connection != null)
		{
			database = connection['database'];
			host = connection['hostname'];
			user = connection['username'];
			port = connection['portnumber'];
			password = connection['password']; 
			comment = connection['comment'];
		}

		$(this.elementUniqueID + "_TE_DATABASE_LOGIN_DATABASE").value = database;
		$(this.elementUniqueID + "_TE_DATABASE_LOGIN_HOSTNAME").value = host;
		$(this.elementUniqueID + "_TE_DATABASE_LOGIN_PORTNUMBER").value = port;
		$(this.elementUniqueID + "_TE_DATABASE_LOGIN_USERNAME").value = user;
		$(this.elementUniqueID + "_TE_DATABASE_LOGIN_PASSWORD").value = password;
		$(this.elementUniqueID + "_TE_DATABASE_LOGIN_COMMENT").value = comment;

	},

	draw: function() {
		var menu = [];
		var thisObject = this;
		var output = "";
		
		
		output += '<div class="groupTableTitle">Connect to a database </div>';
		
		output += '<span class="groupTableContent"><table width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td style="vertical-align: bottom;">';
		
		output += "<table width=100% cellpadding='3px' style='position:static;padding-top:5px;'>";
		output += "<tbody>";
		output += "<tr><td align='left'><b>Previous connections</b></td><td >";
		output += "<select type='text' style='width:30em;' onchange=\"getPanel('" + this.parentStageID + "', '" + this.parentWindowID + "', '" + this.parentPanelID + "').nestedObject.get('" + this.elementUniqueID + "').insertConnectionInfo(this.value);\">";
		output += "<OPTION selected value=\"{'TE_DATABASE_LOGIN_COMMENT':'','TE_DATABASE_LOGIN_DATABASE':'','TE_DATABASE_LOGIN_USERNAME':'','TE_DATABASE_LOGIN_HOSTNAME':'','TE_DATABASE_LOGIN_PORTNUMBER':'','TE_DATABASE_LOGIN_PASSWORD':''}\" ></OPTION>";
		var CONNECTION_MANAGER_CONNECTION_LIST_Length = CONNECTION_MANAGER_CONNECTION_LIST.length;
		if(CONNECTION_MANAGER_CONNECTION_LIST_Length > 0)
		{
			var tdAttributs = "";
			var connectionStatus = "";
			var activeConnection = "";
			for(var i = 0; i < CONNECTION_MANAGER_CONNECTION_LIST_Length; i++)
			{
				output += "<OPTION value=\"" + i + "\" >" + CONNECTION_MANAGER_CONNECTION_LIST[i]['description'].escapeHTML() + "</OPTION>";
			}
		}
		output += "</select></td></tr>";
		output += '<tr><td align="left"><b>Persistent</b></td><tdstyle="text-align:left;" ><input type="checkbox" name="TE_DATABASE_USE_PERSISTENT_CONNECTION" style="text-align:left;" /></td></tr>';
		output += '<tr><td align="left"><b>Database</b></td><td ><input type="text" id="' + this.elementUniqueID + '_TE_DATABASE_LOGIN_DATABASE" name="TE_DATABASE_LOGIN_DATABASE" style="width:25em;" value="" /></td></tr>';
		output += '<tr><td align="left"><b>Hostname</b></td><td ><input type="text" id="' + this.elementUniqueID + '_TE_DATABASE_LOGIN_HOSTNAME" name="TE_DATABASE_LOGIN_HOSTNAME" style="width:25em;" /></td></tr>';
		output += '<tr><td align="left"><b>Port&nbsp;number</b></td><td ><input type="text" id="' + this.elementUniqueID + '_TE_DATABASE_LOGIN_PORTNUMBER" name="TE_DATABASE_LOGIN_PORTNUMBER" style="width:25em;" /></td></tr>';
		output += '<tr><td align="left"></td><td style="text-align:left;" ><hr align="left" style="text-align:left;width:80%"/></td></tr>';
		output += '<tr><td align="left"><b>User&nbsp;name</b></td><td ><input type="text" id="' + this.elementUniqueID + '_TE_DATABASE_LOGIN_USERNAME" name="TE_DATABASE_LOGIN_USERNAME" style="width:25em;" value="" /></td></tr>';
		output += '<tr><td align="left"><b>Password</b></td><td ><input type="password" style="width:25em;background:#FF7777;" onkeyup="checkPasswordForDB2Connect(this);" id="' + this.elementUniqueID + '_TE_DATABASE_LOGIN_PASSWORD" name="TE_DATABASE_LOGIN_PASSWORD"value=""/></td></tr>';
		output += '<tr><td align="left"></td><td style="text-align:left;" ><hr align="left" style="text-align:left;width:80%"/></td></tr>';
		output += '<tr><td align="left"><b>Comment</b></td><td ><input type="text" style="width:25em;" id="' + this.elementUniqueID + '_TE_DATABASE_LOGIN_COMMENT" name="TE_DATABASE_LOGIN_COMMENT" value="" /></td></tr>';
		output += "</tbody>";
		output += "</table>";
		
		output += '</td></tr></tbody></table></span>';
		
		
		
		var parentPanel = getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID);
		if(parentPanel != null)
		{	
			parentPanel.setContent(output, 'Connection Form', "");
		}
		
		if(this.callParameters.TE_DATABASE_LOGIN_DATABASE != null)
		{
			$(this.elementUniqueID + "_TE_DATABASE_LOGIN_DATABASE").value = this.callParameters.TE_DATABASE_LOGIN_DATABASE;
		}
		if(this.callParameters.TE_DATABASE_LOGIN_HOSTNAME != null)
		{
			$(this.elementUniqueID + "_TE_DATABASE_LOGIN_HOSTNAME").value = this.callParameters.TE_DATABASE_LOGIN_HOSTNAME;
		}
		if(this.callParameters.TE_DATABASE_LOGIN_PORTNUMBER != null)
		{
			$(this.elementUniqueID + "_TE_DATABASE_LOGIN_PORTNUMBER").value = this.callParameters.TE_DATABASE_LOGIN_PORTNUMBER;
		}
		if(this.callParameters.TE_DATABASE_LOGIN_USERNAME != null)
		{
			$(this.elementUniqueID + "_TE_DATABASE_LOGIN_USERNAME").value = this.callParameters.TE_DATABASE_LOGIN_USERNAME;
		}
		if(this.callParameters.TE_DATABASE_LOGIN_PASSWORD != null)
		{
			$(this.elementUniqueID + "_TE_DATABASE_LOGIN_PASSWORD").value = this.callParameters.TE_DATABASE_LOGIN_PASSWORD;
		}
		if(this.callParameters.TE_DATABASE_LOGIN_COMMENT != null)
		{
			$(this.elementUniqueID + "_TE_DATABASE_LOGIN_COMMENT").value = this.callParameters.TE_DATABASE_LOGIN_COMMENT;
		}
	}
}));