/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/

var ACTIVE_DATABASE_CONNECTION = window.name;
var CONNECTION_MANAGER_FIRST_LOAD = true;
var ACTIVE_DATABASE_CONNECTION_OBJECT = null;
var ACTIVE_DATABASE_CONNECTION_AUTHENTICATED = false;
if(ACTIVE_DATABASE_CONNECTION == true || ACTIVE_DATABASE_CONNECTION == 'true')
{
	ACTIVE_DATABASE_CONNECTION = null;
}

var CONNECTION_MANAGER_CONNECTION_LIST = [];

var CONNECTION_MANAGER_TIMER = null;
var CONNECTION_MANAGER_CURRENTLY_UPDATEING = false;

function initiateConnectionRefresh()
{
	GET_GLOBAL_OBJECT_CLASS("connectionManager").each(function(manager){manager.value.connectionWatcher();});
}

function getActiveDatabaseConnection() 
{
	var connectionList = CONNECTION_MANAGER_CONNECTION_LIST;
	var connectionListLength = connectionList.length;
	for(i=0; i<connectionListLength; i++)
	{
		if(ACTIVE_DATABASE_CONNECTION == connectionList[i]['description'])
		{
			if(connectionList[i]['connectionStatus'] == true)
				return ACTIVE_DATABASE_CONNECTION;
			else
				return null;
		}
	}
	return  ACTIVE_DATABASE_CONNECTION;
}
function getActiveDatabaseConnectionObject() 
{
	return  ACTIVE_DATABASE_CONNECTION_OBJECT;
}

function getConnectionWithTag(searchTag)
{
	var localCONNECTION_MANAGER_CONNECTION_LIST = CONNECTION_MANAGER_CONNECTION_LIST;
	var searchPatteren = new RegExp(searchTag, 'i');
	var i = 0;
	for(; i<localCONNECTION_MANAGER_CONNECTION_LIST.length; i++)
	{
		if(localCONNECTION_MANAGER_CONNECTION_LIST[i]['comment'].toLowerCase().match(searchTag) != null)
			return localCONNECTION_MANAGER_CONNECTION_LIST[i]['description'];
	}
	return null;
}
function getConnectionObjectWithTag(searchTag)
{
	var localCONNECTION_MANAGER_CONNECTION_LIST = CONNECTION_MANAGER_CONNECTION_LIST;
	var searchPatteren = new RegExp(searchTag, 'i');
	var i = 0;
	for(; i<localCONNECTION_MANAGER_CONNECTION_LIST.length; i++)
	{
		if(localCONNECTION_MANAGER_CONNECTION_LIST[i]['comment'].toLowerCase().match(searchTag) != null)
			return localCONNECTION_MANAGER_CONNECTION_LIST[i];
	}
	return null;
}
function getConnectionDBMS(description)
{
	var localCONNECTION_MANAGER_CONNECTION_LIST = CONNECTION_MANAGER_CONNECTION_LIST;
	var i = 0;
	for(; i<localCONNECTION_MANAGER_CONNECTION_LIST.length; i++)
	{
		if(localCONNECTION_MANAGER_CONNECTION_LIST[i]['description'] == description)
			return localCONNECTION_MANAGER_CONNECTION_LIST[i]['databaseDriver'];
	}
	return null;
}
function getConnectionHostname(description)
{
	var localCONNECTION_MANAGER_CONNECTION_LIST = CONNECTION_MANAGER_CONNECTION_LIST;
	var i = 0;
	for(; i<localCONNECTION_MANAGER_CONNECTION_LIST.length; i++)
	{
		if(localCONNECTION_MANAGER_CONNECTION_LIST[i]['description'] == description)
			return localCONNECTION_MANAGER_CONNECTION_LIST[i]['hostname'];
	}
	return null;
}
function getConnectionPortNumber(description)
{
	var localCONNECTION_MANAGER_CONNECTION_LIST = CONNECTION_MANAGER_CONNECTION_LIST;
	var i = 0;
	for(; i<localCONNECTION_MANAGER_CONNECTION_LIST.length; i++)
	{
		if(localCONNECTION_MANAGER_CONNECTION_LIST[i]['description'] == description)
			return localCONNECTION_MANAGER_CONNECTION_LIST[i]['portnumber'];
	}
	return null;
}

function isCatalogConnection(description)
{
	var localCONNECTION_MANAGER_CONNECTION_LIST = CONNECTION_MANAGER_CONNECTION_LIST;
	var i = 0;
	for(; i<localCONNECTION_MANAGER_CONNECTION_LIST.length; i++)
	{
		if(localCONNECTION_MANAGER_CONNECTION_LIST[i]['description'] == description)
		{
			if ( localCONNECTION_MANAGER_CONNECTION_LIST[i]['hostname'] == "" || localCONNECTION_MANAGER_CONNECTION_LIST[i]['portnumber'] == "" ||
				localCONNECTION_MANAGER_CONNECTION_LIST[i]['hostname'] == null || localCONNECTION_MANAGER_CONNECTION_LIST[i]['portnumber'] == null )
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	return false;
}

CORE_CLIENT_ACTIONS.set("connectionManager",Class.create(basePageElement, {
	initialize: function($super, callParameters) {
		
		GLOBAL_CONSTANTS.set('ACTIVE_DATABASE_CONNECTION', ACTIVE_DATABASE_CONNECTION);
		
		$super(callParameters.uniqueID + "_" + getGUID(), "connectionManager");
		
		this.parentStageID = callParameters.stageID;
		this.parentWindowID = callParameters.windowID;
		this.parentPanelID = callParameters.panelID;
		
		getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID ).registerNestedObject(this.elementUniqueID, this);
		
		this.connectionTableName = this.elementName + '_connectionTable';
		this.connectionDataTable = null;
		this.currentSelectedConnectionRow = null;
		this.currentSelectedConnectionRowTC = null;
		this.connectionWatcherParameters = new Object();
		this.connectionWatcherParameters.touchConnection = 'false';
		this.connectionWatcherParameters.returntype = "JSON";
		this.currentlyUpdatingConnection = false;
		this.listOnlyConnected=false;
		this.draw();
		this.actionCallbackCloseFloat=false;
		setTimeout(this.callBackText + ".connectionWatcher();", 1000);
	},
	showOnlyConnected: function() {this.listOnlyConnected=true;this.updateData();},
	showAll: function() {this.listOnlyConnected=false;this.updateData();},
	selectRow: function(RowID, TC)
	{
		var i = 0;
		if(this.currentSelectedConnectionRow != RowID || this.currentSelectedConnectionRowTC != TC)
		{
			var oldRowID = this.currentSelectedConnectionRow;
			if(this.currentSelectedConnectionRowTC != null)
				oldRowID = this.currentSelectedConnectionRow + "_" + this.currentSelectedConnectionRowTC;
			var row = $(this.elementName + "_ActiveCONNECTION_MANAGER_CONNECTION_LIST_" + oldRowID);
			if(row != null)
			{
				var rowChildren = row.childElements();
				var numRowChildren = rowChildren.length;
				for(i = 0; i < numRowChildren; i++)
				{
					rowChildren[i].setStyle({'backgroundColor':'white'});
				}
			}
		}
		this.currentSelectedConnectionRow = RowID;
		this.currentSelectedConnectionRowTC = TC;
		if(TC != null)
				RowID = RowID + "_" + TC;
		var row = $(this.elementName + "_ActiveCONNECTION_MANAGER_CONNECTION_LIST_" + RowID);
		if(row != null)
		{
			var rowChildren = row.childElements();
			var numRowChildren = rowChildren.length;
			for(i = 0; i < numRowChildren; i++)
			{
				rowChildren[i].setStyle({'backgroundColor':'#CCCCFF'});
			}
		}
	},
	addTrustedContextUser:function(row)
	{
		var tempParamObject = $H();
		tempParamObject.set('TE_DATABASE_LOGIN_DESCRIPTION', this.connectionDataTable[row]['description']);
		tempParamObject.set('TRUSTED_CONTEXT_USERNAME', "");
		tempParamObject.set('TRUSTED_CONTEXT_PASSWORD', "");
		runTEScript(this.elementName + "_ConnectionScript", GLOBAL_TE_SCRIPT_STORE.get('DB_CONNECTION_SET_TRUSTED_CONTEXT_SCRIPT'), null, null, this.callBackText + ".actionCallback", tempParamObject, this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
	},
	makeDefaultConnection:function()
	{
		if(this.currentSelectedConnectionRow != null && this.connectionDataTable != null && this.currentSelectedConnectionRowTC == null)
		{
			var tempParamObject = $H();
			tempParamObject.set('TE_DATABASE_LOGIN_DESCRIPTION', this.connectionDataTable[this.currentSelectedConnectionRow]['description']);
			tempParamObject.set('TE_DATABASE_LOGIN_COMMENT', this.connectionDataTable[this.currentSelectedConnectionRow]['comment']);
			tempParamObject.set('TE_DATABASE_LOGIN_DATABASE', this.connectionDataTable[this.currentSelectedConnectionRow]['database']);
			tempParamObject.set('TE_DATABASE_LOGIN_HOSTNAME', this.connectionDataTable[this.currentSelectedConnectionRow]['hostname']);
			tempParamObject.set('TE_DATABASE_LOGIN_PORTNUMBER', this.connectionDataTable[this.currentSelectedConnectionRow]['portnumber']);
			tempParamObject.set('TE_DATABASE_LOGIN_USERNAME', this.connectionDataTable[this.currentSelectedConnectionRow]['username']);
			tempParamObject.set('TE_DATABASE_LOGIN_PASSWORD', this.connectionDataTable[this.currentSelectedConnectionRow]['password']);
			tempParamObject.set('TE_DATABASE_CONNECTION_STATUS', (this.connectionDataTable[this.currentSelectedConnectionRow]['connectionStatus'] == true ? "true" : this.connectionDataTable[this.currentSelectedConnectionRow]['connectionStatus']));
			tempParamObject.set('TE_DATABASE_AUTHENTICATED', (this.connectionDataTable[this.currentSelectedConnectionRow]['authenticated'] == true ? "true" : "false"));
			this.actionCallbackCloseFloat=true;
			runTEScript(this.elementName + "_ConnectionScript", GLOBAL_TE_SCRIPT_STORE.get('DB_CONNECTION_SET_CONNECTION_SCRIPT'), null, null, this.callBackText + ".actionCallback", tempParamObject, this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
		}
		else if(this.currentSelectedConnectionRow != null && this.connectionDataTable != null && this.currentSelectedConnectionRowTC != null)
		{
			var tempParamObject = $H();
			tempParamObject.set('TE_DATABASE_LOGIN_DESCRIPTION', this.connectionDataTable[this.currentSelectedConnectionRow]['description']);
			tempParamObject.set('TRUSTED_CONTEXT_USERNAME', this.currentSelectedConnectionRowTC);
			tempParamObject.set('TRUSTED_CONTEXT_PASSWORD', this.connectionDataTable[this.currentSelectedConnectionRow]['trustedContext'][this.currentSelectedConnectionRowTC]);
			this.actionCallbackCloseFloat=true;
			runTEScript(this.elementName + "_ConnectionScript", GLOBAL_TE_SCRIPT_STORE.get('DB_CONNECTION_SET_TRUSTED_CONTEXT_SCRIPT'), null, null, this.callBackText + ".actionCallback", tempParamObject, this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
		}
	},
	disconnectConnection:function()
	{
		if(this.currentSelectedConnectionRow != null && this.connectionDataTable != null)
		{
			var tempParamObject = $H();
			tempParamObject.set('TE_DATABASE_LOGIN_DESCRIPTION', this.connectionDataTable[this.currentSelectedConnectionRow]['description']);
			runTEScript(this.elementName + "_DisconnectScript", GLOBAL_TE_SCRIPT_STORE.get('DB_CONNECTION_DISCONNECT_SCRIPT'), null, null, this.callBackText + ".actionCallback",tempParamObject,this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
		}
	},
	removeConnections: function()
	{
		if(this.currentSelectedConnectionRow != null && this.connectionDataTable != null)
		{
			var tempParamObject = $H();
			tempParamObject.set('TE_DATABASE_LOGIN_DESCRIPTION', this.connectionDataTable[this.currentSelectedConnectionRow]['description']);
			runTEScript(this.elementName + "_RemoveConnectionScript", GLOBAL_TE_SCRIPT_STORE.get('DB_CONNECTION_REMOVE_CONNECTIONS_SCRIPT'), null, null, this.callBackText + ".actionCallback", tempParamObject, this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
		}
	},
	createNewConnection: function()
	{
		this.actionCallbackCloseFloat=true;
		var tempParamObject = $H();
		runTEScript(this.elementName + "_NewConnectionScript", GLOBAL_TE_SCRIPT_STORE.get('DB_CONNECTION_NEW_CONNECTION_DIALOG_SCRIPT'), null, null, this.callBackText + ".actionCallback", null, this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
		return true;
	},
	actionCallback: function(returnStack)
	{
		var returnValue = returnStack.actionReturnValue;
		var returnObject = null;
		if(typeof(returnValue) == "object" && returnValue != null)
		{
			returnObject = returnValue;
			returnValue = returnObject['description'];
		}
		
		if("false" != String(returnValue).toLowerCase())
		{			
			
			if(ACTIVE_DATABASE_CONNECTION != returnValue && ACTIVE_DATABASE_CONNECTION != null)
			{
				CORE_ReloadOnConnectionChange.each(function(panelItem) {
					if(callingPanelID != panelItem.value.elementUniqueID)
						panelItem.value.reloadPage();
				});
			}

			ACTIVE_DATABASE_CONNECTION = returnValue != "-1" ? returnValue : null;
			ACTIVE_DATABASE_CONNECTION_OBJECT = returnObject;
			window.name = ACTIVE_DATABASE_CONNECTION;
			
			GLOBAL_CONSTANTS.set('ACTIVE_DATABASE_CONNECTION', ACTIVE_DATABASE_CONNECTION);
			
			if (CONNECTION_MANAGER_TIMER != null)
				clearTimeout(CONNECTION_MANAGER_TIMER);
			this.updateActiveDatabaseConnection(true);

			this.connectionWatcher();
			ALL_GLOBAL_OBJECT('reloadIfRequired',null,'panel');
			allContextWindows.each(function(contextBase) {contextBase.value.reloadOnConnectIfRequired();});
			if(this.actionCallbackCloseFloat) {
				var floatingPanel=FLOATINGPANEL_activeFloatingPanels.get(this.parentPanelID);
				if (floatingPanel!=null) floatingPanel.show_and_size()
			}
		}
		this.actionCallbackCloseFloat=false;
	},
	
	updateActiveDatabaseConnection: function(connectionObjectIsNew) {
			
			connectionObjectIsNew = connectionObjectIsNew == null ? false : connectionObjectIsNew;
			
			this.selectRow(null);

			if(ACTIVE_DATABASE_CONNECTION != null)
			{
				var i = 0;
				var connectionListLength = CONNECTION_MANAGER_CONNECTION_LIST.length;
				for(i=0; i<connectionListLength; i++)
				{
					if(ACTIVE_DATABASE_CONNECTION == CONNECTION_MANAGER_CONNECTION_LIST[i]['description'])
					{

						if(ACTIVE_DATABASE_CONNECTION_OBJECT != null && connectionObjectIsNew)
							CONNECTION_MANAGER_CONNECTION_LIST[i] = ACTIVE_DATABASE_CONNECTION_OBJECT;
						else if(!connectionObjectIsNew || ACTIVE_DATABASE_CONNECTION_OBJECT == null)
							ACTIVE_DATABASE_CONNECTION_OBJECT = CONNECTION_MANAGER_CONNECTION_LIST[i];
							
						if(CONNECTION_MANAGER_CONNECTION_LIST[i]['authenticated'] == true)
						{
							document.title = ACTIVE_DATABASE_CONNECTION;
							ACTIVE_DATABASE_CONNECTION_AUTHENTICATED = true;
						}
						else
						{
							document.title = DATABASE_NOT_CONNECTED_TEXT;
							ACTIVE_DATABASE_CONNECTION_AUTHENTICATED = false;
						}
						break;
					}
				}
				if(i>=connectionListLength)
				{
					if(ACTIVE_DATABASE_CONNECTION_OBJECT != null)
					{
						if(ACTIVE_DATABASE_CONNECTION_OBJECT['authenticated'] = true)
						{
							ACTIVE_DATABASE_CONNECTION_AUTHENTICATED = true;
							document.title = ACTIVE_DATABASE_CONNECTION;
						}
						else
						{
							ACTIVE_DATABASE_CONNECTION_AUTHENTICATED = false;
							document.title = DATABASE_NOT_CONNECTED_TEXT;
						}
						CONNECTION_MANAGER_CONNECTION_LIST.push(ACTIVE_DATABASE_CONNECTION_OBJECT);
					}
					else
					{
						ACTIVE_DATABASE_CONNECTION_AUTHENTICATED = false;
						document.title = DATABASE_NOT_CONNECTED_TEXT;
					}
				}
			}
			
			GET_GLOBAL_OBJECT_CLASS("connectionManager").each(function(connectionObject) { connectionObject.value.updateData(); });
	},
	
	connectionWatcher: function() {
		if(CONNECTION_MANAGER_CURRENTLY_UPDATEING)
			return;
		 if (CONNECTION_MANAGER_TIMER != null)
			clearTimeout(CONNECTION_MANAGER_TIMER);
		CONNECTION_MANAGER_CURRENTLY_UPDATEING = true;
		var connectionWatcherParameters = this.connectionWatcherParameters;
		var thisObject = this;
		new Ajax.Request(CONNECTION_VERIFIER, {
			'parameters': connectionWatcherParameters,
			onSuccess: function(transport) {
				var result = transport.responseJSON;
				if(result != null)
				{
					CONNECTION_MANAGER_CONNECTION_LIST = result.activeConnection;
					if(CONNECTION_MANAGER_FIRST_LOAD)
					{
						CONNECTION_MANAGER_FIRST_LOAD = false;
						for(var i = 0; i < CONNECTION_MANAGER_CONNECTION_LIST.length; i++)
						{
							if(CONNECTION_MANAGER_CONNECTION_LIST[i]['activeOnFirstLoad'])
							{
								ACTIVE_DATABASE_CONNECTION = CONNECTION_MANAGER_CONNECTION_LIST[i]['description'];
								ACTIVE_DATABASE_CONNECTION_OBJECT = CONNECTION_MANAGER_CONNECTION_LIST[i];
								window.name = ACTIVE_DATABASE_CONNECTION;
								
								CORE_ReloadOnConnectionChange.each(function(panelItem) {
										if(callingPanelID != panelItem.value.elementUniqueID)
											panelItem.value.reloadPage();
									});
									
								GLOBAL_CONSTANTS.set('ACTIVE_DATABASE_CONNECTION', ACTIVE_DATABASE_CONNECTION);
								
								thisObject.updateActiveDatabaseConnection();
					
								ALL_GLOBAL_OBJECT('reloadIfRequired',null,'panel');
								return;
							}
						}	
					}
					thisObject.updateActiveDatabaseConnection();
				}
			},
			onComplete: function(transport) {
				CONNECTION_MANAGER_CURRENTLY_UPDATEING = false;
				CONNECTION_MANAGER_TIMER = setTimeout("GET_GLOBAL_OBJECT_CLASS('connectionManager').values()[0].connectionWatcher();", 60000);
			}
		});
	},
	updateData: function ()
	{
		var connObject = null;
		var dataArray = CONNECTION_MANAGER_CONNECTION_LIST;
		var connectiondescription = null;
		var connectionSelectIndex = null;
		if(this.currentSelectedConnectionRow != null && this.connectionDataTable != null && this.currentSelectedConnectionRowTC == null)
		{
			connObject = this.connectionDataTable[this.currentSelectedConnectionRow];
			if(connObject != null)
				connectiondescription = connObject['description'];
		}
		else if(this.currentSelectedConnectionRow != null && this.connectionDataTable != null && this.currentSelectedConnectionRowTC != null)
		{
			connObject = this.connectionDataTable[this.currentSelectedConnectionRow];
			if(connObject != null)
				connectiondescription = this.currentSelectedConnectionRowTC + "|" + connObject['description'];
		}
		this.currentSelectedConnectionRow = null;
		this.currentSelectedConnectionRowTC = null;
		var dataTable = $(this.elementName + "_ActiveCONNECTION_MANAGER_CONNECTION_LIST");
		this.connectionDataTable = dataArray;
		if(dataTable != null && dataArray != null)
		{
			this.clearCONNECTION_MANAGER_CONNECTION_LIST();
			var dataArray_Length = dataArray.length;
			if(dataArray_Length > 0)
			{
				var tdAttributs = "";
				var connectionStatus = "";
				var activeConnection = "";
				for(var i = 0; i < dataArray_Length; i++)
				{
					if(this.listOnlyConnected)
						if(dataArray[i]['connectionStatus'] != true)
							continue;
					tdAttributs = " ontouchend='" + this.callBackText + ".makeDefaultConnection(" + i + ");' ondblclick='" + this.callBackText + ".selectRow(" + i + ");" + this.callBackText + ".makeDefaultConnection();'";
					if(IS_TOUCH_SYSTEM)
						tdAttributs += " ontouchstart";
					else
						tdAttributs += " onclick";
					tdAttributs += "='" + this.callBackText + ".selectRow(" + i + ")' style='background-color:white;cursor: pointer;padding-left:5px;'";
					if(dataArray[i]['authenticated'] == true)
					{
						connectionStatus = dataArray[i]['connectionStatus'] == true ? "<img alt='Y' title='Authenticated' src='images/typevalue_ok.gif'/>" 	: "<img alt='?' title='Connection error' src='images/alert.gif' id='" + this.elementName + "_" + i + "_PageInformationButton' onMouseUp=\"stopPropagation(event);\" onMouseDown='show_GENERAL_BLANK_POPUP(null, decodeURIComponent(\"<div style=\\\"padding:10px;width:350px\\\">" + escape(dataArray[i]['connectionStatus']) + "</div>\"));'/>";
					}
					else
					{
						connectionStatus = "<img alt='N' title='Not authenticated' src='images/close_s.gif'/>";
					}
					activeConnection = ACTIVE_DATABASE_CONNECTION == dataArray[i]['description'] ? "<img alt='&#187;' title='Connected' src='images/fw_bold.gif'/>" : "";
					dataTable.insert({bottom:	"<tr id='" + this.elementName + "_ActiveCONNECTION_MANAGER_CONNECTION_LIST_" + i + "'" + (IS_TOUCH_SYSTEM ? " style='font-size:15px;padding:5px;border-bottom:1px;border-color:#888;' " : "") + ">" +
												"<td" + tdAttributs + ">" +
												activeConnection +
 
												"<td valign='center' " + tdAttributs + ">" +
												(IS_TOUCH_SYSTEM ? ( dataArray[i]['authenticated'] ?
"<div style='-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.5);background:-webkit-gradient(linear, left top, left bottom, from(#ff7200), to(#ff8c26));width:100px;height:20px;font-size:10px;margin:3px;padding:px;border-width:1px;-webkit-border-radius:5px;border-color:#888;text-align:right;'><button style='border-color:#ddd;-webkit-border-radius:5px;height:100%;width:40px;background:-webkit-gradient(linear, left top, left bottom, from(#eee), to(#aaa));-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);'></button></div>"
:
"<div style='-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.5);background:-webkit-gradient(linear, left top, left bottom, from(#aaa), to(#eee));width:100px;height:20px;font-size:10px;margin:3px;padding:px;border-width:1px;-webkit-border-radius:5px;border-color:#888;'><button style='border-color:#ddd;-webkit-border-radius:5px;height:100%;width:40px;background:-webkit-gradient(linear, left top, left bottom, from(#eee), to(#aaa));-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);'></button></div>" ): 
												connectionStatus ) +
												"</td><td" + tdAttributs + ">" + dataArray[i]['database'] +
												"</td><td" + tdAttributs + ">" + dataArray[i]['hostname'] +
												"</td><td" + tdAttributs + ">" + dataArray[i]['username'] +
												"</td><td" + tdAttributs + ">" + dataArray[i]['portnumber'] +
												"</td><td" + tdAttributs + ">" + (dataArray[i]['authenticated'] == true && dataArray[i]['hostname'].toLowerCase() != "localhost" && dataArray[i]['hostname'] != "127.0.0.1" ? "<img style='width:15px;height:15px;' onclick='" + this.callBackText + ".addTrustedContextUser(" + i + ");' title='Add trusted context user...' src='images/useradd.gif'/>" : "") +
												"</td><td" + tdAttributs + ">" + (dataArray[i]['comment'] == null ? "" : dataArray[i]['comment']) +
												"</td></tr>"});
					if(dataArray[i]['trustedContext'] != null && dataArray[i]['authenticated'])
					{
						var trustedConnection = $H(dataArray[i]['trustedContext']);
						var elementName = this.elementName;
						var thisObject=this;
						trustedConnection.each(function(user)
						{
							tdAttributs = " ondblclick='" + thisObject.callBackText + ".selectRow(" + i + ",\"" + user.key + "\");" + thisObject.callBackText + ".makeDefaultConnection();' onclick='" + thisObject.callBackText + ".selectRow(" + i + ",\"" + user.key + "\")' style='background-color:white;cursor: pointer;padding-left:5px;'";
							activeConnection = ACTIVE_DATABASE_CONNECTION == user.key + "|" + dataArray[i]['description'] ? "<img src='images/fw_bold.gif'/>" : "";
							dataTable.insert({bottom:	"<tr id='" + elementName + "_ActiveCONNECTION_MANAGER_CONNECTION_LIST_" + i + "_" + user.key + "'><td" + tdAttributs + ">" + activeConnection +
												"</td><td" + tdAttributs + ">" + connectionStatus +
												"</td><td" + tdAttributs + ">" + dataArray[i]['database'] +
												"</td><td" + tdAttributs + ">" + dataArray[i]['hostname'] +
												"</td><td" + tdAttributs + ">" + dataArray[i]['username'] +
												"</td><td" + tdAttributs + ">" + dataArray[i]['portnumber'] +
												"</td><td" + tdAttributs + " colspan='2'>" + user.key +
												"</td></tr>"});
						});
						
					}
					if(connectiondescription != null && connectiondescription == dataArray[i]['description'])
						connectionSelectIndex = i;
					if(ACTIVE_DATABASE_CONNECTION == dataArray[i]['description'] && connectionSelectIndex == null)
						connectionSelectIndex = i;
				}
				if(!FORCE_CONNECTION_WITH_DEFAULT && !IS_TOUCH_SYSTEM)
				{
					$(this.elementName+ "_disconnect").show();
					$(this.elementName+ "_setDefault").show();
					$(this.elementName+ "_Remove").show();
					if(this.listOnlyConnected) {
						$(this.elementName+ "_showAll").show();
						$(this.elementName+ "_showOnlyConnected").hide();
					} else {
						$(this.elementName+ "_showAll").hide();
						$(this.elementName+ "_showOnlyConnected").show();
					}
				}
			}
			else
			{
				dataTable.update("<tr><td align='center'>No connections</td></tr>");
				if(!FORCE_CONNECTION_WITH_DEFAULT && !IS_TOUCH_SYSTEM)
				{
					$(this.elementName+ "_disconnect").hide();
					$(this.elementName+ "_setDefault").hide();
					$(this.elementName+ "_Remove").hide();
					$(this.elementName+ "_showAll").hide();
					$(this.elementName+ "_showOnlyConnected").hide();
				}
			}	
        	        if(IS_TOUCH_SYSTEM)
	                        dataTable.insert({bottom:"<tr><td align='center' colspan='8'><button onclick='" + this.callBackText + ".createNewConnection();' style='margin:10px;padding:10px;-webkit-border-radius:5px;width:95%;-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);background-color:white;'>New&nbsp;connection</button></td></tr>"});
		}

		if(connectionSelectIndex == null)
			connectionSelectIndex = 0;
		this.selectRow(connectionSelectIndex);
		
		var parentPanel = getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID );
		if(parentPanel != null)
			if(parentPanel.size != null)
				parentPanel.size();
	},
	clearCONNECTION_MANAGER_CONNECTION_LIST: function()
	{
		this.currentSelectedConnectionRow = null;
		this.currentSelectedConnectionRowTC = null;
		var dataTable = $(this.elementName + "_ActiveCONNECTION_MANAGER_CONNECTION_LIST");
		if(dataTable != null)
		{
				dataTable.update("<tr><td style='width:10px;'><b>Active&nbsp;&nbsp;</b></td><td style='width:30px;'><b>Authenticated&nbsp;&nbsp;</b></td><td style='width:100px;'><b>Database</b></td><td style='width:100px;'><b>Host</b></td><td style='width:100px;'><b>User</b></td><td style='width:50px;'><b>Port</b></td><td style='width:50px;' title='Set Trusted Context'><b>Set&nbsp;TC&nbsp;&nbsp;</b></td><td style='width:100px;'><b>Comment</b></td></tr>");
		}
	},
	draw: function()
	{
		var menu = null;
		var connectionTableName = this.connectionTableName;
		var output = "";
		if(IS_TOUCH_SYSTEM)
			output += "<div style='width:100%;' align='center'>";
		else
			output += "<div style='padding:5px;'>";
		output += "<table "; 
		if(IS_TOUCH_SYSTEM)
			output += "class='fingerfriendly' style='margin:10px;padding:10px;-webkit-border-radius:5px;width:80%;-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);'";
		else
			output += " style='width:100%;'";
		output += " id='" + this.elementName + "_ActiveCONNECTION_MANAGER_CONNECTION_LIST' cellpadding='0' cellspacing='0' >";
		output += "<tr><td align='center'><img style='float:none;' src='images/loadingpage.gif'/></td></tr>";
		output += "</table>";
		output += "</div'>";

		if(!FORCE_CONNECTION_WITH_DEFAULT && !IS_TOUCH_SYSTEM)
		{
			menu = [
						{
							nodeType : "leaf",
							elementID : this.elementName+ "_newConnection",
							elementValue : "New",
							elementAction : 'onclick="' + this.callBackText + '.createNewConnection();"',
							elementSubNodes : null,
							elementSubNodeDirection : HORIZONTAL
						},
						{
							nodeType : "leaf",
							elementID : this.elementName+ "_setDefault",
							elementValue : "Connect",
							elementAction : 'onclick="' + this.callBackText + '.makeDefaultConnection()"',
							elementSubNodes : null,
							elementSubNodeDirection : HORIZONTAL
						},
						{
							nodeType : "leaf",
							elementID : this.elementName+ "_disconnect",
							elementValue : "Disconnect",
							elementAction : 'onclick="' + this.callBackText + '.disconnectConnection()"',
							elementSubNodes : null,
							elementSubNodeDirection : HORIZONTAL
						},
						{
							nodeType : "leaf",
							elementID : this.elementName+ "_Remove",
							elementValue : "Remove",
							elementAction : 'onclick="' + this.callBackText + '.removeConnections();"',
							elementSubNodes : null,
							elementSubNodeDirection : HORIZONTAL
						},
						{
							nodeType : "leaf",
							elementID : this.elementName+ "_showAll",
							elementValue : "Show All",
							elementAction : 'onclick="' + this.callBackText + '.showAll();"',
							elementSubNodes : null,
							elementSubNodeDirection : HORIZONTAL
						},
						{
							nodeType : "leaf",
							elementID : this.elementName+ "_showOnlyConnected",
							elementValue : "Show Only Connected",
							elementAction : 'onclick="' + this.callBackText + '.showOnlyConnected();"',
							elementSubNodes : null,
							elementSubNodeDirection : HORIZONTAL
						}
				];
		}
		getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID ).setContent(output, 'Connection manager', null, null, menu);
	}
}));
