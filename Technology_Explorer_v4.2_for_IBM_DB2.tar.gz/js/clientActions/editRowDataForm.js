/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
function EditRowDataForm_toggleFieldsOnInput(object, elementID, index, original, originalNull)
{
	var update = $(elementID + "_Option_COLUMN_" + index);
	var image = $(elementID + "_Img_COLUMN_" + index);
	if(object == null || update == null || image == null) return;
	if (object.value != original || originalNull) 
	{
		object.setStyle({background:"#77FF77"});
		update.checked= "true";
		image.show();
	} else 
	{
		object.setStyle({background:""});
		update.checked= "false";
		image.hide();	
	}
}

function EditRowDataForm_toggleFieldsOnNull(object, elementID, index, original, originalNull, editRow) {
	var field = $(elementID + "_COLUMN_" + index);
	var update = $(elementID + "_Option_COLUMN_" + index);
	var image = $(elementID + "_Img_COLUMN_" + index);
	if(field == null || update == null || image == null || object == null) return;
	if (object.checked == true) 
	{
		field.disable();
		object.value = "true";
		field.setStyle({background:""});
		if (originalNull == true && editRow == true)
		{
			update.checked = false;
			image.hide();
		} else
		{
			update.checked = true;
			image.show();
		}
	} else 
	{
		field.enable();
		object.value = "";
		EditRowDataForm_toggleFieldsOnInput(field, elementID, index, original, originalNull);	
		
	}
}

function EditRowDataForm_toggleFieldsOnUpdate(object, elementID, index) {
	var field = $(elementID + "_COLUMN_" + index);
	var image = $(elementID + "_Img_COLUMN_" + index);
	if(field == null || object == null || image == null) return;
	if (object.checked == true) 
	{
		field.setStyle({background:"#77FF77"});
		image.show();
		object.value = "true";
	} else 
	{
		object.value = "";
		field.setStyle({background:""});
		image.hide();
	}
}

// remove single quote of the prefiled value returned from requestPrefill function
function FixPrefiledValue(object) {
	var oldValue = object.value;
	if(oldValue.length >= 2)
		object.value = oldValue.substring(1,oldValue.length-1);
	else
		object.value = oldValue;
}

CORE_CLIENT_ACTIONS.set("EditRowDataForm",Class.create(basePageElement, {
	initialize: function($super, callParameters) {
		$super(callParameters.uniqueID + "_EditForm", "EditRowDataForm");
			
		this.parentStageID = callParameters.stageID;
		this.parentWindowID = callParameters.windowID;
		this.parentPanelID = callParameters.panelID;

		this.callParameters = callParameters;
		
		var parentPanel = getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID);
		
		this.callingTableID = this.callParameters['#Calling_Table_ID'];
		if(parentPanel != null)
		{
			parentPanel.registerNestedObject(this.elementUniqueID, this);
		}
				
		this.draw();
	},
	
	draw: function() {
		var menu = [];
		var thisObject = this;
		var output = "";
		var original = "";
		var originalNull = false;		
		var showUpdateCheckbox = (this.callParameters['Title'] == "Create Like" || this.callParameters['Title'] == "Insert Row");
		var editRow = (this.callParameters['Title'] == "Edit Row Data");
		var components = [];
		
		output += '<script type="text/javascript"> function toggleTextField(textField) { textField.disabled = !textField.disabled } </script>';
		output += '<div class="groupTableTitle">' + this.callParameters['TableName'] + ' </div>';
		output += '<span class="groupTableContent"><table width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td style="vertical-align: bottom;">';
		output += "<table width=100% cellpadding='3px' style='position:static;padding-top:5px;'>";
		output += "<tbody>";
		
		
		if (this.callParameters['Title'] == "Delete Row")
		{
			output += '<tr><td align="left"><b> Permanently delete the row with the following data? </b></td></tr>';
			for(var i = 0; i < this.callParameters['ColumnInfo'].name.length; i++)
			{
				output += '<tr><td align="left"><b>' + this.callParameters['ColumnInfo'].name[i] + ' :</b> ' + this.callParameters['RowData'][i] + '</td></tr>';
			}	
		} else {
			// Create column titles for form
			output += '<tr><td align="left"><b>Column</b></td><td align="left"><b>Value</b></td><td align="left"><b>Type</b></td><td align="left"><b>Null</b></td>';
			if (showUpdateCheckbox)
				output += '<td align="left"><b>Update</b></td><td align="left"><b></b></td></tr>';
			else
				output += '<td align="left"><b>Update</b></td><td align="left"><b></b></td></tr>';
			
			for(var i = 0; i < this.callParameters['ColumnInfo'].name.length; i++)
			{
			
					
				original = (this.callParameters['RowData'][i] != null) ? this.callParameters['RowData'][i] : "";
				originalNull = (this.callParameters['RowData'][i] != null) ? false : true;
				output += '<tr>';
				output += '<td align="left"><b>' + this.callParameters['ColumnInfo'].name[i] + '</b></td>';
				output += '<td >';
				components = this.callParameters['Components']["column"][this.callParameters['ColumnInfo'].name[i]];
				if(!components.isPrefiled)
					output += '<input type="text" id="' + this.elementUniqueID + '_COLUMN_' + i + '" style="width:25em;background:;"  value="" name="' + 'COLUMN_' + i + '" onkeyup="EditRowDataForm_toggleFieldsOnInput(this, \''+this.elementUniqueID + '\' , ' + i + ', \''+original + ', ' + originalNull + '\');" />';
				else {
				
					output += "<table id='" + this.elementUniqueID + '_COLUMN_' + i + "' cellpadding='0px' cellspacing='0px'>";
					output += "<tbody><tr><td style='width:100%;'>";
					output += '<input type="text" id="' + this.elementUniqueID + '_COLUMN_' + i + '_textInput' + '" style="width:25em;background:;"  value="" name="' + 'COLUMN_' + i + '" onChange="EditRowDataForm_toggleFieldsOnInput(this, \''+this.elementUniqueID + '\' , ' + i + ', \''+original + ', ' + originalNull + '\');FixPrefiledValue(this)" />';
					output += "</td><td id='" + this.elementUniqueID + '_COLUMN_' + i + "_buttonHolder' style='width:0%;'>";
					output += "</td></tr></tbody></table>";
				}
				
				output += '</td>';
				output += '<td align="left"><b>(' + this.callParameters['ColumnInfo'].type[i] + ')</b></td>';
				output += '<td><input id="' + this.elementUniqueID + '_Null_COLUMN_' + i + '" name="' + 'Null_COLUMN_' + i + '" type="checkbox" value="true" ';
				output += ' onClick="EditRowDataForm_toggleFieldsOnNull(this, \''+this.elementUniqueID + '\' , ' + i + ', \''+original + '\', ' + originalNull + ', ' + editRow + ');" /></td>';
				//output += '<td><img id="' + this.elementUniqueID + '_Img_COLUMN_' + i + '" style="display:none;" src="./images/typevalue_ok.gif" alt="marked for update" /></td>';
				//output += '<td><input id="' + this.elementUniqueID + '_Option_COLUMN_' + i + '" name="' + 'Option_COLUMN_' + i + '" type="checkbox" value="true" ';
				//Show update check box (default checked) OR show image check 
				if (showUpdateCheckbox)
				{
					output += '<td><input id="' + this.elementUniqueID + '_Option_COLUMN_' + i + '" name="' + 'Option_COLUMN_' + i + '" type="checkbox" value="true" checked';
					output += ' onClick="EditRowDataForm_toggleFieldsOnUpdate(this, \''+this.elementUniqueID + '\' , ' + i + ');"/></td>';
					output += '<td><img id="' + this.elementUniqueID + '_Img_COLUMN_' + i + '" style="display:none;" src="./images/typevalue_ok.gif" alt="marked for update" style="visibility:hidden" /></td>';
				}
				else
				{
					output += '<td><img id="' + this.elementUniqueID + '_Img_COLUMN_' + i + '" style="display:none;" src="./images/typevalue_ok.gif" alt="marked for update" /></td>';
					output += '<td><input id="' + this.elementUniqueID + '_Option_COLUMN_' + i + '" name="' + 'Option_COLUMN_' + i + '" type="checkbox" value="true" ';
					output += ' style="visibility:hidden" /></td>';
				}
				output += '</tr>';
			}	
		}
		output += "</tbody>";
		output += "</table>";		
		output += '</td></tr></tbody></table></span>';
		
		var parentPanel = getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID);
		if(parentPanel != null)
		{	
			parentPanel.setContent(output, this.callParameters['Title'], "");
		}
		
		for(var i = 0; i < this.callParameters['ColumnInfo'].name.length; i++)
		{
			components = this.callParameters['Components']["column"][this.callParameters['ColumnInfo'].name[i]];
			if(components.isPrefiled)
			{
				TABLE_MANIPULATION_MODULES.get("Integrated_PrefillSelection").requestPrefill(this.callingTableID, this.callParameters['ColumnInfo'].name[i], this.elementUniqueID + '_COLUMN_' + i);
			}
		}
		// Fill the values with row data or check null box if null, disable field + null box, uncheck checkbox if tagged uneditable
		if (this.callParameters['Title'] == "Edit Row Data")
		{
			for(var i = 0; i < this.callParameters['ColumnInfo'].name.length; i++)
			{
				components = this.callParameters['Components']["column"][this.callParameters['ColumnInfo'].name[i]];
				
				if (this.callParameters['RowData'][i] != null)
				{
					if (components.editable)
					{
						if(components.isPrefiled == null)
						{
							$(this.elementUniqueID + "_COLUMN_" + i).value = this.callParameters['RowData'][i];
						}
						else
						{
							$(this.elementUniqueID + "_COLUMN_" + i + '_textInput').value = this.callParameters['RowData'][i];
						}
							
					}
				} else
				{
					$(this.elementUniqueID + "_Null_COLUMN_" + i).checked = true;
					EditRowDataForm_toggleFieldsOnNull($(this.elementUniqueID + "_Null_COLUMN_" + i), this.elementUniqueID, i, null, true, editRow);
				}
				if (!components.editable)
				{
					$(this.elementUniqueID + "_COLUMN_" + i).disable();
					$(this.elementUniqueID + "_Null_COLUMN_" + i).disable();
					$(this.elementUniqueID + "_Option_COLUMN_" + i).checked = false;
				}
			}
		}
		
		// Fill the values with row data or check null box if null, update checkbox checked by default
		if (this.callParameters['Title'] == "Create Like")
		{
			for(var i = 0; i < this.callParameters['ColumnInfo'].name.length; i++)
			{
				if (this.callParameters['RowData'][i] != null)
				{
					components = this.callParameters['Components']["column"][this.callParameters['ColumnInfo'].name[i]];
					if(components.isPrefiled == null)
					{
						$(this.elementUniqueID + "_COLUMN_" + i).value = this.callParameters['RowData'][i];
					}
					else
					{
						$(this.elementUniqueID + "_COLUMN_" + i + '_textInput').value = this.callParameters['RowData'][i];
					}
				} else
				{
					$(this.elementUniqueID + "_Null_COLUMN_" + i).checked = true;
					EditRowDataForm_toggleFieldsOnNull($(this.elementUniqueID + "_Null_COLUMN_" + i), this.elementUniqueID, i, null, true, editRow);
				}
			}
		}
		
		//Disable field if marked as auto_generated
		if ((this.callParameters['Title'] == "Create Like") || (this.callParameters['Title'] == "Insert Row"))
		{
			for(var i = 0; i < this.callParameters['ColumnInfo'].name.length; i++)
			{
				components = this.callParameters['Components']["column"][this.callParameters['ColumnInfo'].name[i]];
				if (components.auto_generated)
				{
					$(this.elementUniqueID + "_COLUMN_" + i).value = "";
					$(this.elementUniqueID + "_COLUMN_" + i).disable();
					$(this.elementUniqueID + "_Null_COLUMN_" + i).checked = false;
					$(this.elementUniqueID + "_Null_COLUMN_" + i).disable();
					$(this.elementUniqueID + "_Option_COLUMN_" + i).checked = false;
					$(this.elementUniqueID + "_Option_COLUMN_" + i).disable();
				}
			}
		}
		
		// Disable null values on keys, if "edit row data", also disable changing the value
		for (i=0; i < this.callParameters['KeyIndices'].length; i++)
		{
			if (this.callParameters['Title'] == "Edit Row Data")
				$(this.elementUniqueID + "_COLUMN_" + i).disable();
			$(this.elementUniqueID + "_Null_COLUMN_" + i).disable();
		}
	}
}));