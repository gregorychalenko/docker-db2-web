/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
/*
	The has array TABLE_COLUMN_RENDERING_MODULES contains a list of function to render columns of a given type. 
	the function definition is as follows:
	function(object baseTableData, int rowToRender, columnRenderingInfo)
	*/
var TABLE_COLUMN_RENDERING_MODULES = $H();

var TABLE_ROW_MODULES = $H();

var TABLE_MANIPULATION_MODULES = $H();

CORE_CLIENT_ACTIONS.set("list_table",Class.create(basePageElement, {
	initialize: function($super, callParameters) {
		$super(callParameters.uniqueID + "_list_table", "list_table");

		this.parentStageID = callParameters.stageID;
		this.parentWindowID = callParameters.windowID;
		this.parentPanelID = callParameters.panelID;
		this.parentPageID = callParameters.uniqueID;

		this.pageCallParameters = callParameters;

		this.schema = callParameters.schema;

		this.table = callParameters.table;
		
		this.maxResultsToFetch = callParameters.maxResultsToFetch;
		
		this.maxExecutionTime = AD_HOC_MAX_EXECUTION_TIME;

		this.disableLeftMenu = callParameters.disableLeftMenu != null ? (Object.isString() ? (callParameters.disableLeftMenu == 'true' ? true : false) : callParameters.disableLeftMenu ) : false;

		this.refreshScope = callParameters.refresh == null ? 'replace' :callParameters.refresh;
		this.displayColumnsSet = callParameters.displayColumnsSet;
		
		this.firstLoad = true;
		
		this.sizingError = false;
		
		this.errorIsShowen == false;
		
		this.reloadIndicatorThreshHold = null;
		
		this.objectIsDead = false;
		
		this.parentPanel = getPanel(this.parentStageID, this.parentWindowID,this.parentPanelID);
		this.parentPanel.registerNestedObject(this.elementUniqueID, this);

		if(callParameters.INITIALIZE_TABLE_DISPLAY == true || callParameters.INITIALIZE_TABLE_DISPLAY == null)
		{
			var tableName = "";
			var resetPageStage = false;
			this.baseTableData = this.parentPanel.pageState;
	
			tableName = this.schema != null && this.schema != "" ? this.schema + "." + this.table : this.table;
	
			if(this.baseTableData == null) resetPageStage = true;
			else if(this.baseTableData.localTableDeffinition == null) resetPageStage = true;
			else if(this.baseTableData.fullTableName != tableName) resetPageStage = true;
	
			if(resetPageStage)
			{
				this.parentPanel.refreshType = "callback";
				this.parentPanel.refreshCallback = 'true;';
				
				this.baseTableData = {
					fullTableName : tableName,
					tableName : this.table,
					baseResultSet : 0,
					tableCallParameters : callParameters,
					localTableDeffinition : null,
					queryType : "",
					baseQuery : "",
					commonTableExpressions : null,
					otherTablesToInclude : null,
					displayColumns : null,
					displayColumnsSet : null,
					resultSetIndexByColumnName : null,
					components : null,
					parameters : null,
					orderBy : null,
					where : null,
					baseData : null,
					columnsInfo : null,
					isRowCountComplete : false,
					baseData : null,
					updateTime : null,
					primaryKeys : null,
					rowsReturned : 0,
					totalRows : 0,
					fetchResultsAfterRow : 0,
					baseMaxResultsToFetch : 100,
					baseMaxExecutionTime : 120,
					maxResultsToFetch : 100,
					titleHeight : 0,
					forceDefinitionReload: false,
					loadInProgress: false
				};
				this.parentPanel.pageState = this.baseTableData;
				this.parentPanel.startServerLoadIndicator();
				ObjectManager.getTableDefinition(this.table, this.schema, this.callBackText + ".setTableDefinition", this.callBackText + ".setErrorMessage", this.callBackText + ".setLoading", this.baseTableData.forceDefinitionReload, callParameters.baseFolder);
			}
			else 
			{
				this.parentPanel.refreshType = "callback";
				this.parentPanel.refreshCallback = 'GLOBAL_OBJECT_HOLDER.get(' + this.GUID + ').retrieveTableData()';
	
				if(this.baseTableData.forceDefinitionReload == true)
				{
					this.parentPanel.startServerLoadIndicator();
					ObjectManager.getTableDefinition(this.table, this.schema, this.callBackText + ".setTableDefinition", this.callBackText + ".setErrorMessage", this.callBackText + ".setLoading", this.baseTableData.forceDefinitionReload, callParameters.baseFolder);
				}
				else
				{
					this.processDispalySetup();
					this.draw();
					this.retrieveTableData();
				}
			}
		}
	},
	
	setTableDefinition: function(tableDefinitionObject){
		this.parentPanel.setClientLoadIndicator();
		//Table definition is cloned internally to avoid contamination across views 
		tableDefinitionObject = cloneObject(tableDefinitionObject);
		
		this.baseTableData.localTableDeffinition 	= tableDefinitionObject;
		this.baseTableData.tableName 				= tableDefinitionObject.tableName == "" ? this.table : tableDefinitionObject.tableName;
		this.baseTableData.queryType 				= tableDefinitionObject.queryType;
		
		this.baseTableData.baseResultSet 			= tableDefinitionObject.baseResultSet;
		this.baseTableData.baseQuery 				= tableDefinitionObject.baseQuery;
		this.baseTableData.commonTableExpressions 	= tableDefinitionObject.commonTableExpressions;
		this.baseTableData.otherTablesToInclude 	= tableDefinitionObject.otherTablesToInclude;
		this.baseTableData.baseMaxResultsToFetch 	= parseInt(tableDefinitionObject.rowsPerPage);
		this.baseTableData.baseMaxExecutionTime 	= parseInt(tableDefinitionObject.maxExecutionTime);
		this.baseTableData.maxResultsToFetch 		= (this.maxResultsToFetch==null ? parseInt(tableDefinitionObject.rowsPerPage) : this.maxResultsToFetch);
		this.baseTableData.maxExecutionTime			= (this.maxExecutionTime == null? parseInt(tableDefinitionObject.maxExecutionTime) : this.maxExecutionTime);
		this.baseTableData.displayColumns 			= tableDefinitionObject.displayColumns;
		this.baseTableData.displayColumnsSet 		= tableDefinitionObject.displayColumnsSet;
		this.baseTableData.components 				= tableDefinitionObject.components;
		this.baseTableData.parameters 				= tableDefinitionObject.parameters;
		this.baseTableData.orderBy 					= tableDefinitionObject.orderBy;
		this.baseTableData.primaryKeys 				= tableDefinitionObject.primaryKeys;
		this.baseTableData.reloadindicator 			= tableDefinitionObject.reloadindicator;
		
		this.parentPanel.refreshType = "callback";
		this.parentPanel.refreshCallback = this.callBackText + '.retrieveTableData()';
		
		this.processDispalySetup();
		this.draw();
		this.processParameters();
		this.parentPanel.clearLoadIndicator();
		this.retrieveTableData();
	},
	
	setLoading: function(OnOrOff) {
		if(OnOrOff)
		{
			this.parentPanel.setContent("<table id='" + this.elementUniqueID + "_Object_To_Fit_To_Panel' style='width:100%;height:100%;position:static;'cellspacing='0' cellpadding='0' align='center' valign='center'><tr><td align='center' valign='center'><img style='float:none;' src='images/loadingpage.gif'/></td></tr><tr><td align='center'><h2>Loading table definition</h2></td></tr></table>", 'Loading table definition', null, 'hidden');
		}
	},
	
	setErrorMessage: function(message) {
		this.parentPanel.setContent("<table style='width:100%;height:100%'><tr><td align='center'><h2>" + message + "</h2></td></tr></table>", 'Error', null, 'hidden');
	},

	processParameters: function() {

		var thisObject = this;
		
		var paramLength = thisObject.baseTableData.parameters.length;
		var i = 0;
		var param = null;

		var oldCompareOps = {
								"eq":"=",
								"lt":"<",
								"gt":">",
								"lteq":"<=",
								"gteq":">=",
								"neq":"<>",
								"like":"LIKE",
								"nlike":"NOT LIKE",
								"not":"NOT LIKE",
								"null":"IS NULL",
								"nnull":"IS NOT NULL",
								"between":"BETWEEN"
							};

		var allCallParameters = $H(this.pageCallParameters);
		allCallParameters.each(function(aCallParameter) {
			var key=aCallParameter.key.toUpperCase();
			var component = thisObject.baseTableData.components.column[key];
			var valueToCompaire = "null";
			
			if(component != null)
			{
				var compareOp = allCallParameters.get("compare" + aCallParameter.key);
				if(compareOp == null) compareOp = "eq";
				if(oldCompareOps[compareOp.toLowerCase()]!==undefined) compareOp = oldCompareOps[compareOp.toLowerCase()];
				
				if(Object.isString(aCallParameter.value) && component.fieldType==undefined) {
					valueToCompaire = "'" + aCallParameter.value + "'";
				} else {
					if(component.fieldType != 'n' && aCallParameter.value.substr(0,1)!="'")
						valueToCompaire = "'" + aCallParameter.value + "'";
					else
						valueToCompaire = aCallParameter.value;	
				}

				var searchNode = {
						type: "value",
						column: key,
						compareType: compareOp,
						value: valueToCompaire
					};

				if(thisObject.baseTableData.where == null)
					thisObject.baseTableData.where = searchNode;	
				else {
					if(	thisObject.baseTableData.where.type.toLowerCase() == "group"
					&& thisObject.baseTableData.where.Operand.toLowerCase() == "and" )
					{
						thisObject.baseTableData.where.groupNodes.push(searchNode);
					} else {
						thisObject.baseTableData.where = {
										type:"group",
										Operand: "AND",
										groupNodes: [searchNode,thisObject.baseTableData.where]
									};
					}
				}
			}
			
			if(thisObject.baseTableData.parameters != null)
			{
				for(i=0; i<paramLength; i++)
				{
					if(thisObject.baseTableData.parameters[i].name.toUpperCase() == key)
						thisObject.baseTableData.parameters[i].value = aCallParameter.value;
				}
			}
		});

	},

	destroy: function($super) {
		this.objectIsDead = true;
		$super();
	},

	processDispalySetup: function() {

		if(this.displayColumnsSet==null)
			var tempDisplayColumns = this.baseTableData.displayColumns;
		else {
			if(this.baseTableData.displayColumnsSet==undefined) 
				throw 'Display set: "'+this.displayColumnsSet+'" no display sets defined for table';
			if(this.baseTableData.displayColumnsSet[this.displayColumnsSet]==undefined) 
				throw 'Display set: "'+this.displayColumnsSet+'" not found';
			var tempDisplayColumns = this.baseTableData.displayColumnsSet[this.displayColumnsSet];
		}
		var thisObject = this;
		var elementUniqueID = this.elementUniqueID;
		var GUID = this.GUID;
		var displayClass = "";

		this.baseTableData.displayColumns = [];

		var columnIndex = 0;

		tempDisplayColumns.each(function(Column) {

			var tempComponentGroup = thisObject.baseTableData.components[Column.type];
			if(tempComponentGroup != null)
			{
				var tempComponent = tempComponentGroup[Column.name];
				if(tempComponent != null)
				{
					renderingClass = TABLE_COLUMN_RENDERING_MODULES.get(Column.type);
					displayClass = "";
					if(renderingClass != null)
						if(renderingClass.getDisplayClass != null)
							displayClass = renderingClass.getDisplayClass(tempComponent);

					if(renderingClass.columnCheck != null)
						if(!renderingClass.columnCheck(thisObject.baseTableData, Column.name))
							return;
					
					tempComponent['visible'] = true;
					thisObject.baseTableData.displayColumns.push({
									'isVisible':Column.isVisible,
									'index' : columnIndex,
									'type': Column.type,
									'name': Column.name,
									'typeName' : Column.type + "_" + Column.name,
									'ptypeNameD' : "\"" + Column.type + "\",\"" + Column.name + "\"",
									'ptypeNameS' : "'" + Column.type + "','" + Column.name + "'",
									'renderingClass' : renderingClass,
									'td1' : "<td class='tableCellRoot " + elementUniqueID + "_ColumnClass_" + Column.type + "_" + Column.name + " " + elementUniqueID + "_RowClass_",
									'td2' : "' id='" + GUID + ".dataTableCell." + Column.type + "." + Column.name + ".",
									'td3' : "'>",
									'div1' : "<div class='" + displayClass + " " + elementUniqueID + "_ColumnContainerClass_" + Column.type + "_" + Column.name + " " + elementUniqueID + "_RowContainerClass_",
									'div2' : "' id='" + elementUniqueID + "_CellValueHolder_" + Column.type + "_" + Column.name + "_",
									'div3' : "' style='height:20px;postition:relative;'>",
									'break': Column['break']
								});
					columnIndex++;
				}
				else
					openModalAlert( encodeMessage(CORE_MESSAGE_STORE.LANGUAGE_TABLE_MESSAGES.TABLE_COMPONENT_ERROR, { COMPONENT_NAME:Column.name, COMPONENT_TYPE:Column.type}));
			}
			else
				openModalAlert(  encodeMessage(CORE_MESSAGE_STORE.LANGUAGE_TABLE_MESSAGES.TABLE_COMPONENT_GROUP_ERROR, { COMPONENT_TYPE:Column.type}));
		});
	},
	
	getUseConnection: function(){
		if(this.baseTableData.localTableDeffinition.useConnectWithTag != null)
			return getConnectionWithTag(this.baseTableData.localTableDeffinition.useConnectWithTag);
		return getActiveDatabaseConnection();
	},
	
	getDBMS: function(){
		DBMS = getConnectionDBMS(this.getUseConnection());
		return DBMS;
	},
	
	getQueryBuilder: function(){
		
		DBMS = this.getDBMS();
		
		if(QUERY_BUILDER.get(DBMS) == null)
		{
			this.setErrorFormatted(DATABASE_NOT_CONNECTED_TEXT);
			return null;
		}
		
		return QUERY_BUILDER.get(DBMS);
		
	},
	
	getQuery: function(){
		
		this.baseTableData.dynamicHistoricalXMLQuery = true;
		var output = this.getQueryBuilder().buildSelect(this.baseTableData);
		this.baseTableData.dynamicHistoricalXMLQuery = null;
		
		return output;
	},

	retrieveTableData: function() {
		
		var baseTableData = this.baseTableData;
		
		if(baseTableData.loadInProgress) return;
		baseTableData.loadInProgress = true;

		var elementUniqueID = this.elementUniqueID;
		var thisObject = this;
		var timeSinceLastLoad = new Date().getTime() / 1000;
		
		if(this.reloadIndicatorThreshHold != null)
			timeSinceLastLoad = timeSinceLastLoad - this.reloadIndicatorThreshHold;
		
		if((this.baseTableData.reloadindicator.ageIndicator && timeSinceLastLoad > this.baseTableData.reloadindicator.threshHold) && timeSinceLastLoad > 5)
			this.markOldData(1);
		
		var sqlCount = 0;
		var queryArray = null;
		var keys = $H(thisObject.baseTableData.components).keys();
		var keyLength = keys.length;
		var i = 0;
		var tableColumnRenderingModule = null;
		var DBMS = null;
		var POSTDATA = new Object();
		POSTDATA.USE_CONNECTION = this.getUseConnection();
	
		
		if(thisObject.baseTableData.localTableDeffinition.dataRetrievalAction == null)
		{
			DBMS = this.getDBMS();
			if (DBMS==null) 
			{
				this.setErrorFormatted(CORE_MESSAGE_STORE.LANGUAGE_MESSAGES.DATABASE_NOT_CONNECTED_TEXT);
				baseTableData.loadInProgress = false;
				return;
			}
			for(i=0; i<keyLength; i++)
			{
				tableColumnRenderingModule = TABLE_COLUMN_RENDERING_MODULES.get(keys[i]);
				if(tableColumnRenderingModule != null)
				{
					if(tableColumnRenderingModule.ContainsSecondaryQueries == true)
					{
						queryArray = null;
						queryArray = tableColumnRenderingModule.secondaryQueries(thisObject);
						if(Object.isString(queryArray))
						{
							if(queryArray != "")
								POSTDATA['SQL[' + (sqlCount++) + ']'] = queryArray;
						}
						else if(queryArray != null)
						{
							if(queryArray.length > 0)
							{
								queryArray.each(function(value) { 
									if(Object.isString(value))
										POSTDATA['SQL[' + (sqlCount++) + ']'] = value;
									else
										POSTDATA['SQL[' + value.name + ']'] = value.sql;
								});
							}
						}
					}
				}
			}		
			if(QUERY_BUILDER.get(DBMS) == null) {
				this.setErrorFormatted(CORE_MESSAGE_STORE.LANGUAGE_MESSAGES.QUERY_BUILDER_NOT_FOUND);
				baseTableData.loadInProgress = false;
				return null;
			}
			
			POSTDATA['SQL[CORE_DATA_QUERY]'] = QUERY_BUILDER.get(DBMS).buildSelect(this.baseTableData);
			POSTDATA.action 				= "executeSQL";
			POSTDATA.returntype 			= 'JSON';
			POSTDATA.displayXML 			= true;
			POSTDATA.displayCLOB			= true;
			POSTDATA.displayXMLinline 		= true;
			POSTDATA.displayCLOBinline 		= true;
			POSTDATA.displayBLOB 			= true;
			POSTDATA.displayDBCLOB 			= true;
			POSTDATA.getRowCount			= true;
			POSTDATA.returnFromRow			= this.baseTableData.fetchResultsAfterRow;
			POSTDATA.maxExecutionTime		= this.baseTableData.maxExecutionTime;
			POSTDATA.maxRowReturn			= this.baseTableData.maxResultsToFetch;
			//Optimization since we do not need to display the queries 
			POSTDATA.doNotReturnSQL 		= !ALLOW_DEVELOPER_VIEW;
		}
		else
		{
			$H(this.pageCallParameters).each(function (parm) {
				POSTDATA[parm.name] = parm.value;
			});
			
			POSTDATA.returntype 			= 'JSON';
			POSTDATA.action = this.baseTableData.localTableDeffinition.dataRetrievalAction;
			
			this.baseTableData.parameters.each(function (parm) {
				POSTDATA[parm.name] = parm.value;
			});
		}
		
		new Ajax.Request(ACTION_PROCESSOR, {
					'parameters': POSTDATA,
					'method': 'post',
					'onCreate': function() {
						thisObject.parentPanel.startServerLoadIndicator();
						if(this.errorIsShowen || thisObject.firstLoad || (thisObject.baseTableData.reloadindicator.fullScreenNotifier && timeSinceLastLoad > thisObject.baseTableData.reloadindicator.threshHold))
							thisObject.setError("<table id='" + elementUniqueID + "_Object_To_Fit_To_Panel' style='width:" + thisObject.width + "px;height:" + thisObject.height + "px;position:static;'cellspacing='0' cellpadding='0' align='center' valign='center'><tr><td align='center'><img style='float:none;' src='images/loadingpage.gif'/></td></tr></table>");
					},
					'onComplete' : function() {
						thisObject.parentPanel.clearLoadIndicator();
						thisObject.firstLoad = false;
						baseTableData.loadInProgress = false;
						thisObject.reloadIndicatorThreshHold = new Date().getTime() / 1000;
					},
					'onSuccess': function(transport) {
						thisObject.parentPanel.setClientLoadIndicator();
						if(thisObject.objectIsDead) return;
						var result = transport.responseJSON;
						if(result == null)
						{
//							thisObject.setErrorFormatted("An invalid JavaScript object was returned");
							return;
						}
						if(result.flagGeneralError == true && result.connectionError == true)
							initiateConnectionRefresh();
						if(result.flagGeneralError == true || result.returnCode == "false")
						{
							if(Object.isString(result.returnValue))
							{
								thisObject.setErrorFormatted(result.returnValue);
								return;
							}
							if(!thisObject.baseTableData.localTableDeffinition.ignoreSQLWarnings)
							{
								thisObject.setErrorFormatted(result.returnValue.STMTMSG,result.returnValue.STMT);
								return;
							}
						}

						var resultSet = (thisObject.baseTableData.localTableDeffinition.dataRetrievalAction == null
										?result.returnValue.STMTReturn['CORE_DATA_QUERY'].resultSet[thisObject.baseTableData.baseResultSet ]
										:result.returnValue);
						if (!thisObject.firstLoad) 
							if ( thisObject.baseTableData.rowsReturned > 0 )
								switch (thisObject.refreshScope) {
									case 'replace': break;
									case 'append':
										thisObject.baseTableData.baseData.concat(resultSet.data);
										if( thisObject.baseTableData.baseData.length > thisObject.maxResultsToFetch)
											thisObject.baseTableData.baseData = thisObject.baseTableData.baseData.slice(thisObject.baseTableData.baseData.length-thisObject.maxResultsToFetch.length)
									case 'prepend':
										thisObject.baseTableData.baseData 				= resultSet.data.concat(thisObject.baseTableData.baseData);
										if( thisObject.baseTableData.baseData.length > thisObject.maxResultsToFetch)
											thisObject.baseTableData.baseData = thisObject.baseTableData.baseData .slice(0,thisObject.maxResultsToFetch.length)
									default:
										thisObject.baseTableData.updateTime 			= resultSet.resultTime;
										thisObject.baseTableData.rowsReturned 			= thisObject.baseTableData.baseData.length;
										thisObject.baseTableData.totalRows 				= thisObject.baseTableData.baseData.length; 
										thisObject.baseTableData.isRowCountComplete 	= true;
										thisObject.renderTableData();
										return;
								}
						thisObject.baseTableData.resultSetIndexByColumnName = {};
						
						for(var i = 0; i < resultSet.columnsInfo.name.length; i++)
						{
							resultSet.columnsInfo.name[i] = resultSet.columnsInfo.name[i].toUpperCase();
							thisObject.baseTableData.resultSetIndexByColumnName[resultSet.columnsInfo.name[i]] = i;
						}
						thisObject.baseTableData.columnsInfo 			= resultSet.columnsInfo;
						thisObject.baseTableData.baseData 				= resultSet.data;
						thisObject.baseTableData.updateTime 			= resultSet.resultTime;
						thisObject.baseTableData.rowsReturned 			= parseInt(resultSet.rowsReturned);
						thisObject.baseTableData.totalRows 				= resultSet.rowsInSet; 
						thisObject.baseTableData.isRowCountComplete 	= resultSet.isRowCountComplete;
						
						if(resultSet == null) return;
						
						var queryArray = null;
						var keys = $H(thisObject.baseTableData.components).keys();
						var keyLength = keys.length;
						var i = 0;
						var tableColumnRenderingModule = null;
						
						if(thisObject.baseTableData.localTableDeffinition.dataRetrievalAction == null)
							for(i=0; i<keyLength; i++)
							{
								tableColumnRenderingModule = TABLE_COLUMN_RENDERING_MODULES.get(keys[i]);
								if(tableColumnRenderingModule != null)
									if(tableColumnRenderingModule.ContainsSecondaryQueries == true)
										tableColumnRenderingModule.processSecondaryQueriesReturn(thisObject.baseTableData, result.returnValue.STMTReturn);
							}
						
						thisObject.renderTableData();
					},
					'onException': function(transport,exception) {
						thisObject.setErrorFormatted("Error loading table data",(exception==null ? transport.statusText : ( typeof(exception)=="object" ? exception.name+" : "+exception.description : exception )));
					},
					'onFailure': function(transport,exception) {
						thisObject.setErrorFormatted("Error loading table data",(exception==null ? transport.statusText : ( typeof(exception)=="object" ? exception.name+" : "+exception.description : exception )));
					}
			});
	},

	renderTableData: function() {

		if(Prototype.Browser.IE && IE_SPEED_EXTENSION)
		{
			this.IErenderTableData();
			return;
		}

		this.clearError();

		var rowHolder = $(this.elementUniqueID + "_displayData");
		if(rowHolder == null) return;

		var elementUniqueID = this.elementUniqueID;
		var GUID = this.GUID;

		var thisObject = this;
		var rowColor = 0;
		var rowID = "";
		var row = null;
		var colorSet = MASTER_TABLE_COLOR_SET[0];

		var i = 0; 
		var displayColumnsLength = this.baseTableData.displayColumns.length;
		var displayColumn = null;
		var RAWdata = "";
		
		if(this.baseTableData.rowsReturned == 0)
		{
			this.setErrorFormatted('SQL_NO_DATA');
			return;
		}
		var TableData = "<tbody>";
		for(currentRow = 0; currentRow < this.baseTableData.rowsReturned; currentRow++)
		{
			//row = null;
			//if(!this.firstLoad)
			//	row = $(this.elementUniqueID + "_Row_" + currentRow);
				RAWdata = "<td class='tableRowNumbering tableCellRoot' id='" + GUID + ".rowNumber." + currentRow + "'>"
					+ "<div class='" + elementUniqueID + "_ColumnContainerClass_index_index " + elementUniqueID + "_RowContainerClass_" + currentRow + "' id='" + elementUniqueID + "_Row_" + currentRow + "_Column_index_index' style='text-align:center;vertical-align: middle;postition:relative;'>&nbsp;"
					+ (this.baseTableData.fetchResultsAfterRow + currentRow + 1) + "&nbsp;&nbsp;</div></td>";
				for(i=0; i < displayColumnsLength; i++)
			{
				displayColumn = this.baseTableData.displayColumns[i];
				if(!displayColumn.isVisible) continue;
					RAWdata += displayColumn.td1 + currentRow + displayColumn.td2 + currentRow + displayColumn.td3 + displayColumn.div1 + currentRow + displayColumn.div2 + currentRow + displayColumn.div3;
					if(displayColumn.renderingClass != null)
					RAWdata += displayColumn.renderingClass.render(thisObject, currentRow, thisObject.baseTableData.components[displayColumn.type][displayColumn.name],null,displayColumn);
				else
					RAWdata += "<font style='color:red;font-weight: bold;'>I don't know how to render a type of '" + displayColumn.type + "'</font>";
				
				RAWdata += "</div>"
						+  "</td>";
				}
			rowColor = colorSet[currentRow % 2];
			TableData += "<tr id='" + elementUniqueID + "_Row_" + currentRow + "' style='height:20px;background-color:" + rowColor + ";'>" + RAWdata + " </tr>";
		}
		TableData += "</tbody>";
		rowHolder.update(TableData);
		for(currentRow = 0; currentRow < this.baseTableData.rowsReturned; currentRow++)
		{
			var row = $(this.elementUniqueID + "_Row_" + currentRow);
			if(row != null)
				if(this.baseTableData.localTableDeffinition.rowStyle != null)
					row.setStyle(this.processRowStyle(currentRow));
		}
			
		var pageSelector = $(this.elementUniqueID + "_pageNumberingArea");
		if(pageSelector != null)
		{
			if(this.baseTableData.rowsReturned == this.baseTableData.totalRows.rowsFound && this.baseTableData.totalRows.endFound && this.baseTableData.fetchResultsAfterRow == 0)
				pageSelector.update("");
			else
				pageSelector.update(TABLE_MANIPULATION_MODULES.get("Integrated_PageSwitcher").generateText(this));
		}
		this.size();
	},
	IErenderTableData: function() {

		this.clearError();

		var rowHolder = $(this.elementUniqueID + "_displayData");
		if(rowHolder == null) return;

		var elementUniqueID = this.elementUniqueID;
		var GUID = this.GUID;
		var callBackText = this.callBackText;

		var thisObject = this;
		var rowColor = 0;
		var rowID = "";
		var row = null;
		var colorSet = MASTER_TABLE_COLOR_SET[0];
		
		var i = 0; 
		var displayColumnsLength = this.baseTableData.displayColumns.length;
		var displayColumn = null;
		var RAWdata = "";
		var TableData = "<tbody>";
		
		if(this.baseTableData.rowsReturned == 0)
			this.setErrorFormatted('SQL_NO_DATA');
		else
		{
			RAWdata = "<td></td>";

			for(i=0; i < displayColumnsLength; i++)
			{
				displayColumn = this.baseTableData.displayColumns[i];
				if(!displayColumn.isVisible) continue;
				RAWdata += "<td id='" + elementUniqueID + "_ColumnTitleCell_" + displayColumn.typeName + "' style='border-left-color:#afafaf;border-left-width:2px;border-left-style:ridge;'>";
				RAWdata += "<table cellpadding='0' cellspacing='0' style='height: 20px;width:100%;'>";
				RAWdata += "<tr>";
				//Insert Loop for table manipulation modules column header data
				TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
					if(aTMModule.value.columnHeaderInterface != null)
						RAWdata += aTMModule.value.columnHeaderInterface(displayColumn, thisObject);
				});
				RAWdata += "<td valign='center' id='" + elementUniqueID + "_ColumnTitleText_" + displayColumn.typeName + "' onmousedown='" + callBackText + ".columnMouseDown(" + displayColumn.ptypeNameD + ")' ondblclick='" + callBackText + ".columnHeadMouseDoubleClickAction(event, " + displayColumn.ptypeNameD + ")' onclick='" + callBackText + ".columnHeadMouseClickAction(event, " + displayColumn.ptypeNameD + ")' oncontextmenu='" + callBackText + ".columnHeadContextMenu(event, " + displayColumn.ptypeNameD + ")' >";
				RAWdata += "<nobr>&nbsp;" + this.baseTableData.components[displayColumn.type][displayColumn.name].title + "&nbsp;&nbsp;</nobr>";
				RAWdata += "</td></tr>";
				RAWdata += "</table>";
				RAWdata += "</td>";
			}
			TableData += "<tr class='contextRootBase' id='" + elementUniqueID + "_TableTitlerRow'>" + RAWdata + " </tr>";
					
			for(currentRow = 0; currentRow < this.baseTableData.rowsReturned; currentRow++)
			{
				RAWdata = "<td class='tableRowNumbering tableCellRoot' id='" + GUID + ".rowNumber." + currentRow + "'>";
				RAWdata += (this.baseTableData.fetchResultsAfterRow + currentRow + 1) + "&nbsp;&nbsp;</td>";

				for(i=0; i < displayColumnsLength; i++)
				{
					displayColumn = this.baseTableData.displayColumns[i];
					if(!displayColumn.isVisible) continue;

					RAWdata += displayColumn.td1 + currentRow + displayColumn.td2 + currentRow + displayColumn.td3;

					if(renderingClass != null)
						RAWdata += displayColumn.renderingClass.render(thisObject, currentRow, thisObject.baseTableData.components[displayColumn.type][displayColumn.name],null,displayColumn);
					else
						RAWdata += "<font style='color:red;font-weight: bold;'>I don't know how to render a type of '" + displayColumn.type + "'</font>";
					
					RAWdata += "</td>";

				}
				rowColor = colorSet[currentRow % 2];
				TableData += "<tr id='" + elementUniqueID + "_Row_" + currentRow + "' style='height:20px;background-color:" + rowColor + ";'>" + RAWdata + " </tr>";
			}
			TableData += "</tbody>";
			rowHolder.update(TableData);
			for(currentRow = 0; currentRow < this.baseTableData.rowsReturned; currentRow++)
			{
				var row = $(this.elementUniqueID + "_Row_" + currentRow);
				if(row != null)
				{
					if(this.baseTableData.localTableDeffinition.rowStyle != null)
					{
						if(row == null) row = $(this.elementUniqueID + "_Row_" + currentRow);
						row.setStyle(this.processRowStyle(currentRow));
					}
				}
			}
			
			var pageSelector = $(this.elementUniqueID + "_pageNumberingArea");
			if(pageSelector != null)
			{
				if(this.baseTableData.rowsReturned == this.baseTableData.totalRows.rowsFound && this.baseTableData.totalRows.endFound && this.baseTableData.fetchResultsAfterRow == 0)
					pageSelector.update("");
				else
					pageSelector.update(TABLE_MANIPULATION_MODULES.get("Integrated_PageSwitcher").generateText(this));
			}
		}
	},
	size: function() {
		var thisObject = this;
		var table = $(this.elementUniqueID + "_ColumnTitleHolder_index_index");
		var column = $(this.GUID + ".rowNumber.0");
		var colWidth = 0;
		
		if(column != null && table != null)
		{
			$(this.elementUniqueID + "_ColumnTitleHolder_index_index");
			table.setStyle({width:column.scrollWidth + "px"});
		}
		if(this.baseTableData != null)
		{
			if(this.baseTableData.displayColumns != null)
			{
				this.baseTableData.displayColumns.each(function(displayColumn) {
		
					var column = $(thisObject.elementUniqueID + "_ColumnTitleHolder_" + displayColumn.typeName);
					var topCell = $(thisObject.GUID + ".dataTableCell." + displayColumn.type + "." + displayColumn.name + ".0");
					
					var firstColumn = $(thisObject.elementUniqueID + "_CellValueHolder_" + displayColumn.typeName + "_0");
					
					if(topCell != null && column != null && firstColumn != null)
					{
						var topCellWidth = topCell.scrollWidth - (parseInt(topCell.getStyle('paddingLeft')) + parseInt(topCell.getStyle('paddingRight')));
						var columnWidth = column.scrollWidth - (parseInt(column.getStyle('paddingLeft')) + parseInt(column.getStyle('paddingRight')));
						
						if(topCellWidth > columnWidth)
						{
							firstColumn.setStyle({width:topCellWidth + "px"});
							column.setStyle({width:topCellWidth + "px"});
						}
						else
						{
							firstColumn.setStyle({width:columnWidth + "px"});
							column.setStyle({width:columnWidth + "px"});
						}
					}
				});
			}
		}
	},

	markOldData: function(age) {
		var row = null;
		var rowColor = "";
		var colorSet = MASTER_TABLE_COLOR_SET[age];
		for(currentRow = 0; currentRow < this.baseTableData.rowsReturned; currentRow++)
		{
			rowColor = colorSet[currentRow % 2];
			var row = $(this.elementUniqueID + "_Row_" + currentRow);
			if(row != null)
				row.setStyle({'backgroundColor':rowColor});
		}
	},

	draw: function() {

		var thisObject = this;
		var sortDirection = null;
		var sortIndex = null;
		var output = "<div id='" + this.elementUniqueID + "_mainDisplayArea' style='width:100px;height:100px;overflow:hidden;position:static;'>";
		if(!Prototype.Browser.IE || !IE_SPEED_EXTENSION)
		{
			this.baseTableData.titleHeight = 20;
			output += "<div class='contextRootBase' id='" + this.elementUniqueID + "_titleDisplayArea' style='height:" + this.baseTableData.titleHeight + "px;overflow:hidden;position:static;'>";

				output += "<table class='tableHeader' id='" + this.elementUniqueID + "_title' style='padding:0px;margin:0px;' cellpadding='0px' cellspacing='0px' >";

					output += "<tr id='TableTitlerRow'><td/><td><div id='" + thisObject.elementUniqueID + "_ColumnTitleHolder_index_index' class='tableTitleElement'/></td><td><div class='columnDivider' onmousedown='" + thisObject.callBackText + ".inishilizeColumnHeadResize(\"index\", \"index\");'/></td>";

					thisObject.baseTableData.displayColumns.each(function(displayColumn) {
						if(!displayColumn.isVisible) return;
						output += "<td id='" + thisObject.elementUniqueID + "_ColumnTitleCell_" + displayColumn.typeName + "'>";
						output += "<div id='" + thisObject.elementUniqueID + "_ColumnTitleHolder_" + displayColumn.typeName + "' class='tableTitleElement' style='position:relative;height:20px;'>";
						output += "<table cellpadding='0' cellspacing='0' style='height: 20px;width:100%;'>";
						output += "<tr>";
						//Insert Loop for table manipulation modules column header data
						TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
							if(aTMModule.value.columnHeaderInterface != null)
								output += aTMModule.value.columnHeaderInterface(displayColumn, thisObject);
						});
						output += "<td valign='center' id='" + thisObject.elementUniqueID + "_ColumnTitleText_" + displayColumn.typeName + "' onmousedown='" + thisObject.callBackText + ".columnMouseDown(" + displayColumn.ptypeNameD + ")' ondblclick='" + thisObject.callBackText + ".columnHeadMouseDoubleClickAction(event, " + displayColumn.ptypeNameD + ")' onclick='" + thisObject.callBackText + ".columnHeadMouseClickAction(event, " + displayColumn.ptypeNameD + ")' oncontextmenu='" + thisObject.callBackText + ".columnHeadContextMenu(event, " + displayColumn.ptypeNameD + ")' >";
						output += "<nobr>&nbsp;" + thisObject.baseTableData.components[displayColumn.type][displayColumn.name].title + "&nbsp;</nobr>";
						output += "</td></tr>";
						output += "</table>";
						output += "</div>";
						output += "</td>";
						output += "<td style='visibility:" + (displayColumn.isVisible ? "visible" : "hidden") + ";'><div class='columnDivider' onmousedown='" + thisObject.callBackText + ".inishilizeColumnHeadResize(" +displayColumn.ptypeNameD + ");'/></td>";

					});

					output += "<td style='width:100px;'/></tr>";

				output += "</table>";
			output += "</div>";
		}

			output += "<div id='" + this.elementUniqueID + "_tableErrorDisplayArea' style='display:none;height:200px;overflow-x: auto;overflow-y: auto;position:static;'>"
					+ "</div>"
					+ "<div id='" + this.elementUniqueID + "_tableDisplayArea' style='height:200px;overflow-x: auto;overflow-y: auto;position:static;' ";
			
			if(IS_TOUCH_SYSTEM)
				output += " ontouchstart='" + this.callBackText + ".touchStart(event)' ontouchend='" + this.callBackText + ".touchEnd(event)' ontouchmove='" + this.callBackText + ".touchMove(event)'";
			
			output += " onscroll=\"" + this.callBackText + ".titleScroll();\">";
			if(Prototype.Browser.IE && IE_SPEED_EXTENSION)
				output += "<table id='" + this.elementUniqueID + "_displayData' style='padding:0px;margin:0px;' class='tableCell' cellpadding='0px' cellspacing='0px' ></table>";
			else
				output += "<table id='" + this.elementUniqueID + "_displayData' style='table-layout: fixed;padding:0px;margin:0px;' class='tableCell' cellpadding='0px' cellspacing='0px' ></table>";
			output += "</div>";
		output += "</div>";

		var tempMenuItem = null;
		var localRightMenu = [];
		var localLeftMenu = [];
			if(!this.disableLeftMenu)
			{
			TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
				if(aTMModule.value.panelLeftMenuObject != null)
				{
					var temp = aTMModule.value.panelLeftMenuObject(thisObject, localLeftMenu);
					if(temp != null)
						localLeftMenu = temp;
				}
			});
	
			localLeftMenu.push({
					nodeType : "leaf",
					elementID : this.elementUniqueID + "_pageNumberingArea",
					elementValue : ""
			});
		}
		this.parentPanel.setContent(output, this.baseTableData.localTableDeffinition.pluralName, this.baseTableData.localTableDeffinition.description, 'hidden', localLeftMenu);

		if(this.baseTableData.localTableDeffinition.tableMenu != null)
			createContextMenu("panelMenuLeft_" + this.parentPageID, this.baseTableData.localTableDeffinition.tableMenu, HORIZONTAL, this.parentStageID, this.parentWindowID, this.parentPanelID);
			
		
		var table = $(this.elementUniqueID + "_displayData");
		Event.observe(table, 'click', this.mouseClickHandeler);
		Event.observe(table, 'dblclick', this.mouseDoubleClickHandeler);
		Event.observe(table, 'mousedown', this.mouseDownHandeler);
		Event.observe(table, 'contextmenu', this.mouseContextMenuHandeler);
	},
	
	mouseDoubleClickHandeler : function(event) {
		var element = Event.element(event);
		if(CORE_MOUSE_DOWN_ACTIONS.keys().length == 0)
		{
			if(!element.tagName.toUpperCase() == 'TD' || !element.hasClassName('tableCellRoot'))
				element = Event.findElement(event, "td.tableCellRoot");
			if(element == null) return;
			var returnInfo = stringSplit(element.id, /[.]/);
			var columnType = "";
			var columnName = "";
			var rowNumber = -1;
			var thisObject = GET_GLOBAL_OBJECT('list_table',returnInfo[0]);
			switch(returnInfo[1])
			{
				case "dataTableCell" :
					columnType = returnInfo[2];
					columnName = returnInfo[3];
					rowNumber = returnInfo[4];
					TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
						if(aTMModule.value.cellMouse1DoubleClickAction != null)
							aTMModule.value.cellMouse1DoubleClickAction(thisObject, rowNumber, columnType, columnName);
						if(aTMModule.value.columnMouse1DoubleClickAction != null)
							aTMModule.value.columnMouse1DoubleClickAction(thisObject, rowNumber, columnType, columnName);
						if(aTMModule.value.rowMouse1DoubleClickAction != null)
							aTMModule.value.rowMouse1DoubleClickAction(thisObject, rowNumber, columnType, columnName);
					});
					break;
				case "rowNumber" :
					rowNumber = returnInfo[2];
					TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
						if(aTMModule.value.rowMouse1DoubleClickAction != null)
							aTMModule.value.rowMouse1DoubleClickAction(thisObject, rowNumber);
						if(aTMModule.value.rowHeadMouse1DoubleClickAction != null)
							aTMModule.value.rowHeadMouse1DoubleClickAction(thisObject, rowNumber);
					});
					break;
			}
		}
		else
			Releaseme();
	},
	
	mouseDownHandeler : function(event) {
		if(!Event.isLeftClick(event)) return;
		var element = Event.element(event);
		if(CORE_MOUSE_DOWN_ACTIONS.keys().length == 0)
		{
			if(!element.tagName.toUpperCase() == 'TD' || !element.hasClassName('tableCellRoot'))
				element = Event.findElement(event, "td.tableCellRoot");
			if(element == null) return;
			var returnInfo = stringSplit(element.id, /[.]/);
			var columnType = "";
			var columnName = "";
			var rowNumber = -1;
			var thisObject = GET_GLOBAL_OBJECT('list_table',returnInfo[0]);
			switch(returnInfo[1])
			{
				case "dataTableCell" :
					columnType = returnInfo[2];
					columnName = returnInfo[3];
					rowNumber = returnInfo[4];
					TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
						if(aTMModule.value.cellMouseDownAction != null)
							aTMModule.value.cellMouseDownAction(thisObject, rowNumber, columnType, columnName);
						if(aTMModule.value.rowMouseDownAction != null)
							aTMModule.value.rowMouseDownAction(thisObject, rowNumber);
						if(aTMModule.value.columnMouseDownAction != null)
							aTMModule.value.columnMouseDownAction(thisObject, columnType, columnName);
					});
					break;
				case "rowNumber" :
					rowNumber = returnInfo[2];
					TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
						if(aTMModule.value.rowMouseDownAction != null)
							aTMModule.value.rowMouseDownAction(thisObject, rowNumber);
						if(aTMModule.value.rowHeadMouseDownAction != null)
							aTMModule.value.rowHeadMouseDownAction(thisObject, rowNumber);
					});
					break;
			}
		}
		else
			Releaseme();
	},
	
	mouseContextMenuHandeler : function(event) {
		var element = Event.element(event);
		if(!element.tagName.toUpperCase() == 'TD' || !element.hasClassName('tableCellRoot'))
			element = Event.findElement(event, "td.tableCellRoot");
		if(element == null) return;
		var returnInfo = stringSplit(element.id, /[.]/);
		var columnType = "";
		var columnName = "";
		var rowNumber = -1;
		var thisObject = GET_GLOBAL_OBJECT('list_table',returnInfo[0]);
		switch(returnInfo[1])
		{
			case "dataTableCell" :
				columnType = returnInfo[2];
				columnName = returnInfo[3];
				rowNumber = returnInfo[4];
				thisObject.cellContextMenu(event, rowNumber, columnType, columnName);
				break;
			case "rowNumber" :
				rowNumber = returnInfo[2];
				thisObject.rowHeadContextMenu(event, rowNumber);
				break;
		}
		Event.stop(event);
		return false;
	},
	
	mouseClickHandeler : function(event) {
		var element = Event.element(event);
		if(!element.tagName.toUpperCase() == 'TD' || !element.hasClassName('tableCellRoot'))
			element = Event.findElement(event, "td.tableCellRoot");
		if(element == null) return;
		var returnInfo = stringSplit(element.id, /[.]/);
		var columnType = "";
		var columnName = "";
		var rowNumber = -1;
		
		var thisObject = GET_GLOBAL_OBJECT('list_table',returnInfo[0]);
		switch(returnInfo[1])
		{
			case "dataTableCell" :
				columnType = returnInfo[2];
				columnName = returnInfo[3];
				rowNumber = returnInfo[4];
				TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
					if(aTMModule.value.cellMouse1ClickAction != null)
						aTMModule.value.cellMouse1ClickAction(thisObject, rowNumber, columnType, columnName);
					if(aTMModule.value.columnMouse1ClickAction != null)
						aTMModule.value.columnMouse1ClickAction(thisObject, rowNumber, columnType, columnName);
					if(aTMModule.value.rowMouse1ClickAction != null)
						aTMModule.value.rowMouse1ClickAction(thisObject, rowNumber, columnType, columnName);
				});
				break;
			case "rowNumber" :
				rowNumber = returnInfo[2];
				TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
					if(aTMModule.value.rowMouse1ClickAction != null)
						TMModule.value.rowMouse1ClickAction(thisObject, rowNumber);
					if(aTMModule.value.rowHeadMouse1ClickAction != null)
						aTMModule.value.rowHeadMouse1ClickAction(thisObject, rowNumber);
				});
				break;
		}
	},

	columnMouseDown: function(event, columnType, columnName) {
		if(!Event.isLeftClick(event)) return;
		if(CORE_MOUSE_DOWN_ACTIONS.keys().length == 0)
		{
			TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
				if(aTMModule.value.columnMouseDownAction != null)
					aTMModule.value.columnMouseDownAction(thisObject, columnType, columnName);
				if(aTMModule.value.columnHeadMouseDownAction != null)
					aTMModule.value.columnHeadMouseDownAction(thisObject, columnType, columnName);
			});
		}
		else
			Releaseme();
		return false;
	},

	inishilizeColumnHeadResize: function(columnType, columnName) {
		if(CORE_MOUSE_DOWN_ACTIONS.keys().length == 0)
		{
			var column = $(this.elementUniqueID + "_ColumnTitleHolder_" + columnType + "_" + columnName);
			var columnWidth = column.getWidth();
			column.setStyle({"overflow":"hidden"});

			$$("." + this.elementUniqueID + "_ColumnContainerClass_" + columnType + "_" + columnName).each(function(elm){elm.setStyle({ "width": (columnWidth) + "px", "overflow":"hidden" });});
			$(this.GUID + ".dataTableCell." + columnType + "." + columnName + ".0").setStyle({width:null});
			$(this.elementUniqueID + "_ColumnTitleCell_" + columnType + "_" + columnName).setStyle({width:null});
						
			CORE_MOUSE_DOWN_ACTIONS.set("tableColumnHeaderMove", {
				CORE_Last_Mouse_X : CORE_Current_Mouse_X,
				CORE_Last_Mouse_Y : CORE_Current_Mouse_Y,
				LastTimeCheck : setTimeout(this.callBackText + ".columnHeadResize('" + columnType + "', '" + columnName + "')", 1)
			});
		}
		else
			Releaseme();
		return false;
	},

	columnHeadResize: function(columnType, columnName) {
		var columnMoveNode = CORE_MOUSE_DOWN_ACTIONS.get("tableColumnHeaderMove");
		if(columnMoveNode != null)
		{
			var change = CORE_Current_Mouse_X - columnMoveNode.CORE_Last_Mouse_X;
			if(change >= 1 || change <= -1)
			{
				var column = $(this.elementUniqueID + "_ColumnTitleHolder_" + columnType + "_" + columnName);
				if(column != null)
				{
					var width = column.getWidth();
					if(width + change)
					{
						column.setStyle({ "width": (width + change) + "px"});
						$$("." + this.elementUniqueID + "_ColumnContainerClass_" + columnType + "_" + columnName).each(function(elm){elm.setStyle({ "width": (width + change) + "px"});});
					}
				}
				columnMoveNode.CORE_Last_Mouse_X = CORE_Current_Mouse_X;
				columnMoveNode.CORE_Last_Mouse_Y = CORE_Current_Mouse_Y;
			}
			columnMoveNode.LastTimeCheck = setTimeout(this.callBackText + ".columnHeadResize('" + columnType + "', '" + columnName + "')", 1);
		}
		return false;
	},

	cellContextMenu: function(event, rowNumber, columnType, columnName) {
		var thisObject = this;
		var output = null;
		var baseMenu = [];
		var columnMenu = [];
		var rowMenu = [];
		TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
			if(aTMModule.value.cellMouse2DownMenuObject != null)
				baseMenu = aTMModule.value.cellMouse2DownMenuObject(thisObject, baseMenu, rowNumber, columnType, columnName);
			if(aTMModule.value.columnMouse2DownMenuObject != null)
				columnMenu = aTMModule.value.columnMouse2DownMenuObject(thisObject, columnMenu, columnType, columnName);
			if(aTMModule.value.rowMouse2DownMenuObject != null)
				rowMenu = aTMModule.value.rowMouse2DownMenuObject(thisObject, rowMenu, rowNumber);
		});

		if(columnMenu.length != 0)
		{
			baseMenu.unshift({
							nodeType : "branch",
							elementID : "GENERAL_CONTECT_MENU_COLUMN",
							elementValue : "COLUMN",
							elementAction : null,
							elementSubNodes : columnMenu,
							elementSubNodeDirection : HORIZONTAL
						});
		}

		if(rowMenu.length != 0)
		{
			baseMenu.unshift({
							nodeType : "branch",
							elementID : "GENERAL_CONTECT_MENU_ROW",
							elementValue : "ROW",
							elementAction : null,
							elementSubNodes : rowMenu,
							elementSubNodeDirection : HORIZONTAL
						});
		}

		if(baseMenu.length != 0) openGeneralContextMenu(baseMenu);
		Event.stop(event);
		return false;
	},

	columnHeadContextMenu: function(event, columnType, columnName) {
		var thisObject = this;
		var output = null;
		var baseMenu = [];
		TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
			if(aTMModule.value.columnMouse2DownMenuObject != null)
				baseMenu = aTMModule.value.columnMouse2DownMenuObject(thisObject, baseMenu, columnType, columnName);
			if(aTMModule.value.columnHeadMouse2DownMenuObject != null)
				baseMenu = aTMModule.value.columnHeadMouse2DownMenuObject(thisObject, baseMenu, columnType, columnName);
		});

		if(baseMenu.length != 0) openGeneralContextMenu(baseMenu);
		Event.stop(event);
		return false;
	},
	columnHeadMouseClickAction: function(event, columnType, columnName) {
		var thisObject = this;
		if(this.baseTableData.localTableDeffinition.tableDisplayActions == null) return false;
		if(this.baseTableData.localTableDeffinition.tableDisplayActions.columnhead_click == null) return false;
		if(!this.baseTableData.localTableDeffinition.tableDisplayActions.columnhead_click.disableLocal)return false;
			
		TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
			if(aTMModule.value.columnMouse1ClickAction != null)
				aTMModule.value.columnMouse1ClickAction(thisObject, columnType, columnName);
			if(aTMModule.value.columnHeadMouse1ClickAction != null)
				aTMModule.value.columnHeadMouse1ClickAction(thisObject, columnType, columnName);
		});
		return false;
	},
	columnHeadMouseDoubleClickAction: function(event, columnType, columnName) {
		var thisObject = this;
		TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
			if(aTMModule.value.columnHeadMouse1DoubleClickAction != null)
				aTMModule.value.columnHeadMouse1DoubleClickAction(thisObject, columnType, columnName);
			if(aTMModule.value.columnMouse1DoubleClickAction != null)
				aTMModule.value.columnMouse1DoubleClickAction(thisObject, columnType, columnName);
		});
		return false;
	},
	rowHeadContextMenu: function(event, rowNumber) {
		var thisObject = this;
		var output = null;
		var baseMenu = [];
		TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
			if(aTMModule.value.rowMouse2DownMenuObject != null)
				baseMenu = aTMModule.value.rowMouse2DownMenuObject(thisObject, baseMenu, rowNumber);
			if(aTMModule.value.rowHeadMouse2DownMenuObject != null)
				baseMenu = aTMModule.value.rowHeadMouse2DownMenuObject(thisObject, baseMenu, rowNumber);
		});

		if(baseMenu.length != 0) openGeneralContextMenu(baseMenu);
		Event.stop(event);
		return false;
	},
	
	runTableManipulationModules : function(actionsToRun, returnObject, parameters) {
		var thisObject = this;
		var parametersLength = parameters.length;
		
		var toRun = 'TABLE_MANIPULATION_MODULES.each(function(aTMModule) {';
		
		for(var i in actionsToRun)
		{
			toRun += 'if(aTMModule.value.' + actionsToRun[i] + ' != null) {';
			toRun += (returnObject != null ? 'returnObject = ' : '') + 'aTMModule.value.' + actionsToRun[i] + '(thisObject' + (returnObject != null ? ',returnObject' : '');
			for(var j in parameters)
			{
				toRun += ',parameters[' + j + ']';
			}
			toRun += ");}";
		}
		toRun += '});';
		
		eval(toRun);
		
		return returnObject;
	},

	titleScroll: function() {
		var table = $(this.elementUniqueID + "_tableDisplayArea");
		var title = $(this.elementUniqueID + "_titleDisplayArea");

		if(table != null && title != null)
			title.scrollLeft = table.scrollLeft;
	},

	sizeHeight: function(Amount) {
		this.height = $(this.parentPageID).getHeight();

		var tableErrorDisplayArea =$(this.elementUniqueID + "_tableErrorDisplayArea");

		var tableDisplayArea = $(this.elementUniqueID + "_tableDisplayArea");
		var mainDisplayArea = $(this.elementUniqueID + "_mainDisplayArea");
		if(this.baseTableData != null)
		{
			if(tableDisplayArea != null)
				tableDisplayArea.setStyle({ "height": (this.height - this.baseTableData.titleHeight) + "px" });
			if(tableErrorDisplayArea != null)
				tableErrorDisplayArea.setStyle({ "height": (this.height - this.baseTableData.titleHeight) + "px" });
		}
		if(mainDisplayArea != null)
			mainDisplayArea.setStyle({ "height": (this.height) + "px" });
	},

	setHeight: function(Amount) {
		this.sizeHeight(null);
		this.size();
	},

	sizeWidth: function(Amount) {
		this.setWidth(null);
	},

	setWidth: function(Amount) {
		this.width = $(this.parentPageID).getWidth();
		var mainDisplayArea = $(this.elementUniqueID + "_mainDisplayArea");
		if(mainDisplayArea != null)
			mainDisplayArea.setStyle({ "width": (this.width) + "px" });
		if(this.sizingError)
		{
			this.sizingError = false;
			this.size();
		}
	},

	setErrorFormatted: function(message,detail) {
		if(message!=undefined)
			if(message!=null) {
				var msgId=message.split(" ",1)[0];
				if(msgId.substr(0,1)=="[") { 
					msgId=message.split("] ",2)[1].split(" ",1)[0];
				}
				if (this.baseTableData.localTableDeffinition.messages[msgId]!=undefined) {
					message=this.baseTableData.localTableDeffinition.messages[msgId];
				} else {
					if (CORE_MESSAGE_STORE.LANGUAGE_TABLE_MESSAGES[msgId]!=undefined)
						message=CORE_MESSAGE_STORE.LANGUAGE_TABLE_MESSAGES[msgId];
				}
			}
		this.setError("<table style='width:100%;height:100%'><tr><td align='center'><h2>" + message + "</h2>"+(detail==null?"":detail)+"</td></tr></table>");
	},

	setError: function(message) {
		var contentArea = $(this.elementUniqueID + "_tableDisplayArea");
		var errorArea = $(this.elementUniqueID + "_tableErrorDisplayArea");
		if(contentArea != null)
			contentArea.hide();
		if(errorArea != null)
		{
			this.errorIsShowen = true;
			errorArea.show();
			errorArea.update(message);
		}
	},
	clearError: function() {
		var contentArea = $(this.elementUniqueID + "_tableDisplayArea");
		var errorArea = $(this.elementUniqueID + "_tableErrorDisplayArea");
		if(contentArea != null)
			contentArea.show();
		if(errorArea != null)
		{
			this.errorIsShowen = false;
			errorArea.hide();
			errorArea.update("");
		}
	},
	
	processRowStyle: function(currentRow) {
		var columnName = this.baseTableData.localTableDeffinition.rowStyle.interfaceColumn;
		var rowdata = this.baseTableData.baseData[currentRow][this.baseTableData.resultSetIndexByColumnName[columnName.toUpperCase()]];
		var options = this.baseTableData.localTableDeffinition.rowStyle.options;
		
		if(options == null) return "";
		
		var optionLength = options.length;
		var i = 0;
		for(i=0; i<optionLength; i++)
		{
			if(options[i].gteq != "" && options[i].lteq != "")
			{
				if(rowdata <= options[i].gteq && rowdata >= options[i].lteq)
					return options[i].style;
			}
			else if(options[i].gt != "" && options[i].lt != "")
			{
				if(rowdata < options[i].gt && rowdata > options[i].lt)
					return options[i].style;
			}
			else if(options[i].gt != "" && options[i].lteq != "")
			{
				if(rowdata < options[i].gt && rowdata >= options[i].lteq)
					return options[i].style;
			}
			else if(options[i].gteq != "" && options[i].lt != "")
			{
				if(rowdata <= options[i].gteq && rowdata > options[i].lt)
					return options[i].style;
			}
			else if(options[i].gteq != "")
			{
				if(rowdata <= options[i].gteq)
					return options[i].style;
			}
			else if(options[i].lteq != "")
			{
				if(rowdata >= options[i].lteq)
					return options[i].style;
			}
			else if(options[i].gt != "")
			{
				if(rowdata < options[i].gt)
					return options[i].style;
			}
			else if(options[i].lt != "")
			{
				if(rowdata > options[i].lt)
					return options[i].style;
			}
			else if(options[i].eq != "")
			{
				if(rowdata == options[i].eq)
					return options[i].style;
			}
		}
	},
	touchStart: function(event) {
		this.Current_Mouse_X = 0;
		this.Current_Mouse_Y = 0;
		this.touchMoveEnabled = false;
		if( event.touches && event.touches.length) { 
			this.touchMoveEnabled = true;
			this.Current_Mouse_X = event.touches[0].clientX;
			this.Current_Mouse_Y = event.touches[0].clientY;
		} else { 
			this.touchMoveEnabled = true;
			this.Current_Mouse_X = event.clientX;
			this.Current_Mouse_Y = event.clientY;
		}
	},
	touchMove: function(event) {
		if(this.touchMoveEnabled && event.touches.length == 1 && event.processed == null)
		{
			var panel = $(this.elementUniqueID);
			table = $(this.elementUniqueID + "_tableDisplayArea");
			title = $(this.elementUniqueID + "_titleDisplayArea");
			if(table != null && title != null)
			{
				var local_Mouse_X = 0;
				var local_Mouse_Y = 0;
				if( event.touches && event.touches.length) { 
					local_Mouse_X = event.touches[0].clientX;
					local_Mouse_Y = event.touches[0].clientY;
				} else {
					local_Mouse_X = event.clientX;
					local_Mouse_Y = event.clientY;
				}
				
				table.scrollLeft += this.Current_Mouse_X - local_Mouse_X;
				title.scrollLeft += this.Current_Mouse_X - local_Mouse_X;
				table.scrollTop += this.Current_Mouse_Y - local_Mouse_Y;
				
				this.Current_Mouse_X = local_Mouse_X;
				this.Current_Mouse_Y = local_Mouse_Y;
				
				event.preventDefault();
				return false;
			}
		}
	},
	touchEnd: function(event) {
		this.touchMoveEnabled = false;
	}

}));