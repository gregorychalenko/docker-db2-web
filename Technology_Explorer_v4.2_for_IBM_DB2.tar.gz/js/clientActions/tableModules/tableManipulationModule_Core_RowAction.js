/*******************************************************************************
 * Author: Misato Sakamoto
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
TABLE_MANIPULATION_MODULES.set("Core_RowAction", {
	
	rowMouse2DownMenuObject: function(tableObject, menuArray, rowNumber) {
		if(tableObject.baseTableData.localTableDeffinition.modules.edit === false) return menuArray;
		if(tableObject.baseTableData.detailedView == true) return menuArray;
		
		if((tableObject.baseTableData.localTableDeffinition.queryType == "table") || (tableObject.baseTableData.localTableDeffinition.moduleOverride['createLike']))
		{
			menuArray.push({
				nodeType : "leaf",
				elementValue : "Create Like",
				elementAction : "onClick='TABLE_MANIPULATION_MODULES.get(\"Core_RowAction\").rowAction(\"" + tableObject.GUID + "\", \"Create Like\", \"createLike\", " + rowNumber + ");'"
			});
		}
		if((tableObject.baseTableData.localTableDeffinition.queryType == "table") || (tableObject.baseTableData.localTableDeffinition.moduleOverride['edit']))
		{
			menuArray.push({
				nodeType : "leaf",
				elementValue : "Edit Row",
				elementAction : "onClick='TABLE_MANIPULATION_MODULES.get(\"Core_RowAction\").rowAction(\"" + tableObject.GUID + "\", \"Edit Row Data\", \"edit\", " + rowNumber + ");'"
			});
		}
		if((tableObject.baseTableData.localTableDeffinition.queryType == "table") || (tableObject.baseTableData.localTableDeffinition.moduleOverride['del']))
		{
			menuArray.push({
				nodeType : "leaf",
				elementValue : "Delete Row",
				elementAction : "onClick='TABLE_MANIPULATION_MODULES.get(\"Core_RowAction\").rowAction(\"" + tableObject.GUID + "\", \"Delete Row\", \"del\", " + rowNumber + ");'"
			});
		}
		return menuArray;
	},
	
	panelLeftMenuObject: function(tableObject, menuArray) {
		if(tableObject.baseTableData.localTableDeffinition.modules.edit === false) return menuArray;
		if(tableObject.baseTableData.detailedView == true) return menuArray;
		
		if((tableObject.baseTableData.localTableDeffinition.queryType == "table") || (tableObject.baseTableData.localTableDeffinition.moduleOverride['insert']))
		{
			menuArray.push({
					nodeType : "leaf",
					elementValue : "Insert Row",
					elementAction : "onClick='TABLE_MANIPULATION_MODULES.get(\"Core_RowAction\").rowAction(\"" + tableObject.GUID + "\", \"Insert Row\", \"insert\", " + null + ");'"
			});
		}
		return menuArray;
	},
	
	rowAction: function(tableID, formTitle, actionName, rowNumber) {
		var tableObject = GET_GLOBAL_OBJECT('list_table', tableID);

		var tempParamObject = $H();
		tempParamObject.set('ColumnInfo', tableObject.baseTableData.columnsInfo);
		if (rowNumber == null)
			tempParamObject.set('RowData', "");
		else
			tempParamObject.set('RowData', tableObject.baseTableData.baseData[rowNumber]);
		tempParamObject.set('Components', tableObject.baseTableData.components);
		tempParamObject.set('TableName', tableObject.baseTableData.baseQuery);
		tempParamObject.set('#Calling_Table_ID', tableID);
		
		var keyIndices = new Array();
		var sqlColNames = new Array();
		for (var i=0; i < tableObject.baseTableData.columnsInfo.name.length; i++)
		{
			sqlColNames[i] = tableObject.baseTableData.components.column[tableObject.baseTableData.columnsInfo.name[i]].sql_name;
			if (formTitle == "Edit Row Data")
			{
				for (var j=0; j < tableObject.baseTableData.primaryKeys.length; j++)
				{
					if (sqlColNames[i] == tableObject.baseTableData.primaryKeys[j])
					{
						keyIndices.push(i);
					}
				}
			}
		}
		
		tempParamObject.set('KeyIndices', keyIndices);
		tempParamObject.set('SQLColNames', sqlColNames);
		
		if (tableObject.baseTableData.localTableDeffinition.moduleOverride[actionName])
		{
			runTEScript(this.elementName + "_OverrideRow_" + actionName, tableObject.baseTableData.localTableDeffinition.moduleOverride[actionName], null, null, null, tempParamObject, this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
			return true;
		}  
		
		tempParamObject.set('Title', formTitle);
		
		runTEScript(this.elementName + "_Row_" + actionName, GLOBAL_TE_SCRIPT_STORE.get('EDIT_ROW_SCRIPT'), null, null, "TABLE_MANIPULATION_MODULES.get('Core_RowAction').processRowAction", tempParamObject, this.parentStageID, this.parentWindowID, this.parentPanelID, this.elementName);
		return true;
	},
	
	processRowAction: function(returnStack) {
		
		var returnParameters = returnStack.defaultParameterList;
		var tableID = returnParameters.get('#Calling_Table_ID');
		var returnValue = returnStack.actionReturnValue;
		
		if(returnValue != "true") return;

		var tableObject = GET_GLOBAL_OBJECT('list_table', tableID);
		
		var sqlColNames = returnParameters.get('SQLColNames');
		
		var statement = "";
		var selectStmt = "";
		
		var bindParametersArray = {};	
		var bindParameters = {};
		var selectBindParameters = {};
		
		var firstvar = true;
		
		var conditionsEncoded = false;
		var conditions = null;
		
		var selectRequired = true;
		
		if (returnParameters.get('Title') == "Insert Row" || returnParameters.get('Title') == "Create Like") 
			selectRequired = false;
		
		/* Set SQL statement (and selectStmt) */
		if (!selectRequired) 
		{
			statement += "INSERT INTO " + tableObject.baseTableData.baseQuery + " ( ";
			for(var i = 0; i < tableObject.baseTableData.columnsInfo.name.length; i++)
			{
				if (returnParameters.get('Option_COLUMN_'+i) == "true")
				{
					if (firstvar == false)
					{
						statement += ", ";
					}
					statement += sqlColNames[i];
					firstvar = false;
				}
			}
			firstvar = true;
			statement += ") VALUES (";
			for(i = 0; i < tableObject.baseTableData.columnsInfo.name.length; i++)
			{
				if (returnParameters.get('Option_COLUMN_'+i) == "true")
				{
					if (firstvar == false)
					{
						statement += ", ";
					}
					if (returnParameters.get('Null_COLUMN_'+i) == "true")
					{	
						statement += "NULL";
					} else 
					{
						statement += "?";
					}
					firstvar = false;
				}
			}
			statement += ")";
		} else 
		{
			selectStmt += "SELECT * FROM " + tableObject.baseTableData.baseQuery + " WHERE ";
			if (returnParameters.get('Title') == "Edit Row Data") 
			{
				firstvar = true;
				statement += "UPDATE " + tableObject.baseTableData.baseQuery + " SET ";
				for(var i = 0; i < tableObject.baseTableData.columnsInfo.name.length; i++)
				{
					if (returnParameters.get('Option_COLUMN_'+i) == "true")
					{
						if (firstvar == false)
						{
							statement += ", ";
						}
						if (returnParameters.get('Null_COLUMN_'+i) == "true")
						{	
							statement += sqlColNames[i] + "=NULL";
						} else 
							statement += sqlColNames[i] + "=?";
						firstvar = false;
					} 
				}
				statement += " WHERE ";
			} else if (returnParameters.get('Title') == "Delete Row") {
				statement += "DELETE FROM " + tableObject.baseTableData.baseQuery + " WHERE ";
			}
			for(i = 0; i < tableObject.baseTableData.columnsInfo.name.length; i++)
			{
				if (i != 0)
				{
					statement += " AND ";
					selectStmt += " AND ";
				}
				if (returnParameters.get('RowData')[i] == null)
				{
					statement += sqlColNames[i] + " is NULL";
					selectStmt += sqlColNames[i] + " is NULL";
					
				} else 
				{
					statement += sqlColNames[i] + "=?";
					selectStmt += sqlColNames[i] + "=?";
				}
			}		
		}
				
		/* return if nothing selected to change or insert (and action is not delete) */
		if (firstvar && (returnParameters.get('Title') != "Delete Row"))
			return;
		
		/* set bind parameters for insert or update statement */
		i = 0;
		if (returnParameters.get('Title') != "Delete Row") 
		{	
			
			for(var j = 0; j < tableObject.baseTableData.columnsInfo.name.length; j++)
			{
				if ((returnParameters.get('Option_COLUMN_'+j) == "true") && (returnParameters.get('Null_COLUMN_'+j) !== "true"))
				{
					bindParameters[(i+1)] = {
							'name':tableObject.baseTableData.columnsInfo.name[j],
							'value':returnParameters.get('COLUMN_'+j),
							'dataType':tableObject.baseTableData.columnsInfo.type[j],
							'type':"DB2_PARAM_IN"
					};
					i++;
				}
			}
		}
		
		/* set bind parameters and condition */
		if (selectRequired)
		{
			j = 0;
			for(var k = 0; k < tableObject.baseTableData.columnsInfo.name.length; k++)
			{
				if (returnParameters.get('RowData')[k] != null)
				{
					bindParameters[(j+i+1)] = {
							'name':tableObject.baseTableData.columnsInfo.name[k] + "_original",
							'value':returnParameters.get('RowData')[k],
							'dataType':tableObject.baseTableData.columnsInfo.type[k],
							'type':"DB2_PARAM_IN"
					};
					selectBindParameters[(j+1)] = {
							'name':tableObject.baseTableData.columnsInfo.name[k],
							'value':returnParameters.get('RowData')[k],
							'dataType':tableObject.baseTableData.columnsInfo.type[k],
							'type':"DB2_PARAM_IN"
					};
					j++;
				}
			}
			bindParametersArray = {
					'1':selectBindParameters,
					'2':bindParameters
			};
			
			conditionsEncoded = true;
			conditions = {
					'1': {
						"rowsreturned" : {
								"operator" : "=",
								"condition": 1,
								"onFalse":{
									'nextAction':"endRun",
									'setrunreturn':"false",
									'setrunmessage':"Row does not exist, or row is not unique."
								}
							}
						}
			};    
		} else 
		{
			bindParametersArray = bindParameters;
		}
		
		var parameters = {	
				"action" : "executeSQL",
				"returntype" : 'JSON',
				"conditions" : Object.toJSON(conditions),
				"conditionsEncoded" : conditionsEncoded,
				"bindParameters" : Object.toJSON(bindParametersArray),
				"bindParametersEncoded" : true
		};
		
		if (selectRequired)	
		{
			parameters['SQL[1]'] = selectStmt;
			parameters['SQL[2]'] =  statement;
		} else 	
		{
			parameters['SQL'] = statement;
		}
		
		if(tableObject.baseTableData.localTableDeffinition.useConnectWithTag != null)
		{
			parameters.USE_CONNECTION = getConnectionWithTag(tableObject.baseTableData.localTableDeffinition.useConnectWithTag);
		}
		if(parameters.USE_CONNECTION == null)
		{
			parameters.USE_CONNECTION = getActiveDatabaseConnection();
		}
		
		new Ajax.Request( ACTION_PROCESSOR, {
				'method': 'POST',
				'parameters': parameters,
				'onSuccess': function(transport) {
					var result = transport.responseJSON;
					if(result == null)
					{
						openModalAlert("Invalid JSON object returned ");
						return;
					}
					if(result.flagGeneralError == true && result.connectionError == true)
					{
						initiateConnectionRefresh();
						openModalAlert("Please connect to the database");
					}
					if(result.flagGeneralError == true || result.returnCode == "false")
					{
						if(Object.isString(result.returnValue))
						{
							openModalAlert("<table style='width:100%;height:100%'><tr><td align='center'>" + result.returnValue + "</td></tr></table>");
							return;
						} else if(Object.isString(result.returnMessage) && (result.returnMessage != ""))
						{
							openModalAlert(result.returnMessage);
						} else 
						{
							openModalAlert("<table style='width:100%;height:100%'><tr><td align='center'>" + result.returnValue.STMTMSG + "</td></tr></table>");
							return;
						}
					}
					getPanel(tableObject.parentStageID, tableObject.parentWindowID, tableObject.parentPanelID).reloadPage();
				}
		});
		
	},
	
	actionCallback: function(returnStack)
	{
		var returnValue = returnStack.actionReturnValue;
		var returnObject = null;
		if(typeof(returnValue) == "object" && returnValue != null)
		{
			returnObject = returnValue;
			returnValue = returnObject['description'];
		}
		
		if("false" != String(returnValue).toLowerCase())
		{			
			
			if(getActiveDatabaseConnection() != null)
			{
						panelItem.value.reloadPage();
			}

			this.connectionWatcher();
		}
	}
});