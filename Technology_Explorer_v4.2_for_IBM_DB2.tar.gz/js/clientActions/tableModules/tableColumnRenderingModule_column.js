/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
TABLE_COLUMN_RENDERING_MODULES.set("column", {
	
	groupTitle: "Columns",
	
	columnCheck: function(baseTableObject, columnName) {
		var columnObject = baseTableObject.components.column[columnName];
		columnObject.title = columnObject.title == null ? "" : columnObject.title;
		columnObject.titleNoQuots = columnObject.title.replace("'", "&#39;").replace('"', "&quot;");
		if(columnObject.fieldType == null) columnObject.fieldType = 's';
		columnObject.fieldType = columnObject.fieldType.toLowerCase();
		return true;
	},
	
	render: function(tableObject, rowToRender, columnObject, maskingColumn, displayColumn) {

		if(columnObject.display == null)
		{
			columnObject.display = [];
			var hasMask = false;
			var showValue = true;
			if(columnObject.componentAvalibility == null)
			{
				columnObject.display.push({type:'component', value:'value'});
			}
			else
			{
				columnObject.componentAvalibility.each(function(renderItem) {
					switch(renderItem) {
						case "value":
							break;
						case "mask":
							hasMask = true;
							break;
						case "inlineGraph":
							showValue = false;
						default:
							columnObject.display.push({type:'component', value:renderItem});
					}
				});
				if(showValue)
				{
					if(hasMask)
						columnObject.display.push({type:'component', value:'mask'});
					else
						columnObject.display.push({type:'component', value:'value'});
				}
			}
		}
		if(columnObject.localQueryDataIndex == null) 
		{
			columnObject.localQueryDataIndex = tableObject.baseTableData.resultSetIndexByColumnName[columnObject.name.toUpperCase()];
			columnObject.localQueryDataType = DB2_DATA_TYPE_CLASSIFICATION[tableObject.baseTableData.columnsInfo.type[columnObject.localQueryDataIndex].toLowerCase()];
			if(columnObject.localQueryDataType == null)
				columnObject.localQueryDataType = DB2_STRING;
		}
		if(columnObject.display.length == 0) return "";
		
		var output = "";
		
		var i = 0;
		
		var displayItems = columnObject.display.length;
		var mask = null;
		var value = null;
		if(columnObject.localQueryDataType != DB2_BLOB)
		{
			if(displayItems > 1)
				output = "<table style='table-layout: fixed;padding:0px;margin:0px;' cellpadding='0px' cellspacing='0px' ><tbody><tr>";
			for(i = 0; i < displayItems; i++)
			{
				mask = null;
				value = tableObject.baseTableData.baseData[rowToRender][columnObject.localQueryDataIndex];
				
				if(columnObject.formatnumber != null)
				{
					value = this.formatnumber(value, columnObject.formatnumber);
				}

				if(value == null && columnObject.nullMask != null)
				{
					mask = columnObject.nullMask;
				}
				else if(columnObject.mask != null )
				{
					if(columnObject.mask[value] != null)
					{
						mask = columnObject.mask[value];
					}
				}
				if(displayItems > 1)
					output += "<td valign='top' style='min-width:" + DEFAULT_ICON_WIDTH + "px;'>";
				if(columnObject.display[i].type == 'component')
				{
					if(displayColumn!=undefined) 
						if(displayColumn['break']=="column") 
							if(rowToRender!=0)
								if (tableObject.baseTableData.baseData[rowToRender][columnObject.localQueryDataIndex]==tableObject.baseTableData.baseData[rowToRender-1][columnObject.localQueryDataIndex] )
									value='';
					switch(columnObject.display[i].value)
					{
						case "mask":
							if(value != null || mask != null)
								output += this.display_mask(value, mask, tableObject, rowToRender, columnObject, columnObject.localQueryDataType);
							break;
						case "value":
							output += this.display_value(value, tableObject, rowToRender, columnObject, columnObject.localQueryDataType);
							break;
						case "image":
							if(value != null || mask != null)
								output += this.display_image(mask, tableObject, rowToRender, columnObject);
							break;
						case "link":
							if(value != null || mask != null)
								output += this.display_link(mask, tableObject, rowToRender, columnObject);
							break;
						case "inlineGraph":
							if(value != null || mask != null)
								output += this.display_inlineGraph(tableObject, rowToRender, columnObject);
							break;
						default:
							if(value != null || mask != null)
								output += this.display_other(mask, columnObject.display[i].value, tableObject, rowToRender, columnObject);
					}
				}
				else output += columnObject.display[i].value;
				if(displayItems > 1)
					output += "</td>";
			}
			if(displayItems > 1)
				output += "</tr></tbody></table>";
		}
		else
			output += "<font style='color:green;font-weight: bold;'>BLOB data</font>";
		return output;
	},
	
	getObject: function(displayItem, columnName, rowToRender, tableObject)
	{
		var columnObject = tableObject.baseTableData.components.column[columnName];
		
		if(columnObject.Index == null) 
		{
			columnObject.localQueryDataIndex = tableObject.baseTableData.resultSetIndexByColumnName[columnObject.name.toUpperCase()];
			columnObject.localQueryDataType = DB2_DATA_TYPE_CLASSIFICATION[tableObject.baseTableData.columnsInfo.type[columnObject.localQueryDataIndex].toLowerCase()];
		}
		
		var value = tableObject.baseTableData.baseData[rowToRender][columnObject.localQueryDataIndex];
		var mask = null;
		
		if(value == null && columnObject.nullMask != null)
		{
			mask = columnObject.nullMask;
		}
		else if(columnObject.mask != null )
		{
			if(columnObject.mask[value] != null)
			{
				mask = columnObject.mask[value];
			}
		}
		var displayObject = columnObject.components == null ? null : columnObject.components[displayItem];
		if(mask != null)
		{
			if(mask[displayItem] != null)
			{
				displayObject = mask[displayItem];
			}
		}
		return displayObject;
	},
	
	formatnumber: function(value, Options)
	{
		if(Options == null) return value;
		value = Number(value);
		if(value == null) return null;
		if(Options.parseFloat) value = parseFloat(value);
		if(Options.parseInt) value = parseInt(value);
		
		if(Options.toExponentialVal != -1) value = value.toExponential(Options.toExponentialVal);
		
		if(Options.toFixedVal != -1) value = value.toFixed(Options.toFixedVal);
		
		if(Options.toPrecisionVal != -1) value = value.toPrecision(Options.toPrecisionVal);
		
		if(Options.toBaseVal != -1) value = value.toString(Options.toBaseVal);
		
		return Options.pre + value + Options.post;
	},
	
	getDisplayClass : function(columnObject)
	{

		switch(columnObject.fieldType)
		{
			case "n":
				return "table-Number";
			case "l":
				return "table-LOBText";
		}
		return "table-NormalText";
	},

	
	display_mask: function(value, mask, tableObject, rowToRender, columnObject, type) {
		if(tableObject.baseTableData.baseData != null)
		{
			if(mask != null)
			{
				if(mask.mask != null)
				{
					value = mask.mask;
				}
				else if(columnObject.hide_Non_Maked_Value == true)
				{
					value = "";
				}
			}
				
			return this.display_value(value, tableObject, rowToRender, columnObject, type);
		}
	},
	
	display_link: function(mask, tableObject, rowToRender, columnObject) {
		var icon = columnObject.components.link_icon != null ? columnObject.components.link_icon : "images/icon-help-contextual-light.gif";
		var link = columnObject.components.link;
		if(mask != null)
		{
			if(mask.link != null)
			{
				link = mask.link;
			}
			else if(columnObject.hide_Non_Maked_Value == true)
			{
				link = null;
			}
		}
		if(link == null)
			return "";
			
		return "<a onclick='OpenURLInFloatingWindow(\"" + link + "\")'><img border='0' src='" + icon + "'></a>";
	},
	
	display_image: function(mask, tableObject, rowToRender, columnObject) {
		var image = columnObject.components.image;
		
		if(mask != null)
		{
			if(mask.image != null)
			{
				image = mask.image;
			}
			else if(columnObject.hide_Non_Maked_Value == true)
			{
				image = null;
			}
		}
		
		if(image != null)
			return "<img border='0' src='" + image + "' />";
		return "";
	},
	
	display_other: function(mask, displayItem, tableObject, rowToRender, columnObject) {
		var displayObject = columnObject.components == null ? null : columnObject.components[displayItem];
		if(mask != null)
		{
			if(mask[displayItem] != null)
			{
				displayObject = mask[displayItem];
			}
			else if(columnObject.hide_Non_Maked_Value == true)
			{
				displayObject = null;
			}
		}
		if(displayObject != null)
		{
			if(displayObject.icon == null)
				displayObject.icon = columnObject.components[displayItem + "_icon"];
				
			var renderingClass = TABLE_COLUMN_RENDERING_MODULES.get(displayItem);
			if(renderingClass != null)
			{
				return renderingClass.render(tableObject, rowToRender, displayObject, columnObject.name);
			}
		}
		
		return "";
	},
	display_inlineGraph: function(tableObject, rowToRender, columnObject, type){
		var value = tableObject.baseTableData.baseData[rowToRender][tableObject.baseTableData.resultSetIndexByColumnName[columnObject.inline_histogram.columnName.toUpperCase()]];
		var flipColor = columnObject.inline_histogram.flipColor;
		var style = columnObject.inline_histogram.style;
		
		if(value == null) {return "<font style='color:red;font-weight: bold;'>null</font>";}
		if(value < 0) {return "";} //PWK do not draw graph if -1
		
		var left = parseInt(value);
		left = left > 100 ? 100 : left;
		colorCoding = flipColor ? 100 - left : left;
	
		var right = 100 - left;
		var colour = "#00FF00";
		if(colorCoding <= 33)
		{
			var hexCode = (156+colorCoding*3).toString(16);
			var index = hexCode.indexOf('.');
			if(index > 0)
				hexCode = hexCode.substr(0,index);
			
			colour = "#00" + (hexCode.length == 1 ? "0" + hexCode : hexCode) + "00";
		}
		else if(colorCoding < 66)
		{
			var hexCode = (7.5*(colorCoding-33)).toString(16);
			var index = hexCode.indexOf('.');
			if(index > 0)
				hexCode = hexCode.substr(0,index);

			colour = "#" + (hexCode.length == 1 ? "0" + hexCode : hexCode) + "FF00";
		}
		else
		{
			var hexCode = (254 - (7.5*(colorCoding-66))).toString(16);
			var index = hexCode.indexOf('.');
			if(index > 0)
				hexCode = hexCode.substr(0,index);

			colour = "#FF" + (hexCode.length == 1 ? "0" + hexCode : hexCode) + "00";
		}
	
		var toreturn = '<table class="TableBar" style="width:100%;min-width: 100px"><tr><td><table style="' + style + ';width:100%;"><tr>';
		toreturn += '<td width="' + left + '%" bgcolor="' + colour + '" ></td><td width="' + right + '%" ></td></tr></table></td>';
		
		if(columnObject.fieldType != "bg_wo")
		{
				toreturn += "<td align='right' style='width:10px;'>&nbsp;" + left.toFixed(2) + "%</td>";
		}
		return toreturn + "</tr></table>";
		
	},
	display_value: function(value, tableObject, rowToRender, columnObject, type) {
		if(tableObject.baseTableData.baseData != null)
		{
			if(value === null || value === undefined)
			{
				return "<font style='color:red;font-weight: bold;'>null</font>";
			}
			switch(columnObject.fieldType)
			{
				case 'l':
				case 's':
					if(value.length > LONG_FIELD_MAX && tableObject.baseTableData.detailedView != true)
					{
						return "<table style='padding:0px;margin:0px;' cellpadding='0px' cellspacing='0px'><tr><tdstyle='padding:0px;margin:0px;'><nobr>" + value.substr(0,LONG_FIELD_MAX-3).escapeHTML() + "...</nobr></td><image onclick='TABLE_COLUMN_RENDERING_MODULES.get(\"column\").showMore(\"" + tableObject.GUID + "\"," + rowToRender + ", \"" + columnObject.name + "\");' src='"+ IMAGE_BASE_DIRECTORY + "/icon-down-on.gif'/></td><td></tr></table>";
					}
					if(value.length > LONG_FIELD_MAX)
					{
						return String(value).escapeHTML();
					}
					break;
				case 'html':
				case 'raw':
					return value;
					break;
			}
			if(type == DB2_NUMBER)
				return "<nobr>" + value + "</nobr>";
			
			return "<nobr>" + String(value).escapeHTML() + "</nobr>";
		}
	},
	
	showMore : function(tableID, rowToRender, columnName) {
		
		var tableObject = GET_GLOBAL_OBJECT('list_table', tableID);
		var columnObject = tableObject.baseTableData.components.column[columnName];
		
		if(columnObject.Index == null) 
		{
			columnObject.localQueryDataIndex = tableObject.baseTableData.resultSetIndexByColumnName[columnObject.name.toUpperCase()];
			columnObject.localQueryDataType = DB2_DATA_TYPE_CLASSIFICATION[tableObject.baseTableData.columnsInfo.type[columnObject.localQueryDataIndex].toLowerCase()];
		}
		
		var value = tableObject.baseTableData.baseData[rowToRender][columnObject.localQueryDataIndex];
		var mask = null;
		if(value == null && columnObject.nullMask != null)
		{
			mask = columnObject.nullMask;
		}
		else if(columnObject.mask != null )
		{
			if(columnObject.mask[value] != null)
			{
				mask = columnObject.mask[value];
			}
		}
		if(mask != null)
			if(mask.mask != null)
				value = mask.mask;
				
		show_GENERAL_BLANK_POPUP(null, 	value);	
	},
	
	
	
	//Indicates if this column type requiers column data to be returned in the general query
	containsColumnForQuery : true, // boolean
	//return a list of columns to be retrived which will be appended to the column section of the select statment
	columnQueryPortion : function(baseTableObject) { 
		var columnList = "";
		var parmPresent = false;
		if(baseTableObject.components.column != null) 
		{
			columns = $H(baseTableObject.components.column);
			columns.each(function(column)
			{
				if(column.value.sql_name != null)
				{
					if(parmPresent) columnList += ",";
					parmPresent = true;
					
					columnList += column.value.sql_name + " AS " + column.key;
				}
			});
		}
		
		return columnList;
	}
});