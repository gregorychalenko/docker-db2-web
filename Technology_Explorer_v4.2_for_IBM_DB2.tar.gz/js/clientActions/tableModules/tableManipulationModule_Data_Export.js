/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
TABLE_MANIPULATION_MODULES.set("Data_Export_New", {
	//When present this object should return a menu JSON object to be added to the top right table menu bar
	panelLeftMenuObject: function(tableObject, menuArray) {
		if(IS_TOUCH_SYSTEM) return menuArray;
		var menuID = "Data_Export_New";
		this.exportHeadingType='title';
		this.exportOutputType='csv';
		var output = "<table width='500px'>"
					+ "<tr><td>Type</td><td>"
					+ 		"<select onchange='TABLE_MANIPULATION_MODULES.get(\"" + menuID + "\").setParameter(\"exportOutputType\",this.value);'/>"
					+			'<option selected="selected" value="csv">csv - comma delimitered</option>'
					+			'<option value="html">html</option>'
					+			'<option value="xml">xml</option>'
					+		'</select>'
					+ 	'</td></tr>'
					+ "<tr><td>Heading</td><td>"
					+ 		"<select onchange='TABLE_MANIPULATION_MODULES.get(\"" + menuID + "\").setParameter(\"exportHeadingType\",this.value);'/>"
					+			'<option selected="selected" value="title">Title</option>'
					+			'<option value="column">Column Name</option>'
					+			'<option value="noHeading">No Heading</option>'
					+		'</select>'
					+ 	'</td></tr>'
					+ "</table>"
					+ "<input type='button' value='Generate' onclick='TABLE_MANIPULATION_MODULES.get(\"" + menuID + "\").output(" + tableObject.GUID + ");'/>";
	
		var menuFloatingPanel = new floatingPanel(tableObject.elementUniqueID + "_" + menuID + '_Menu', 'RAW', output, tableObject.elementUniqueID + "_" + menuID + '_Menu_button', false, false);
		getPanel(tableObject.parentStageID, tableObject.parentWindowID, tableObject.parentPanelID).registerNestedObject(tableObject.elementUniqueID + "_" + menuID + '_Menu', menuFloatingPanel);
		menuFloatingPanel.draw();

		menuArray.push({
				nodeType : "leaf",
				elementID : tableObject.elementUniqueID + "_" + menuID + '_Menu_button',
				elementValue : "Export",
				elementAction : 'onClick="FLOATINGPANEL_activeFloatingPanels.get(\'' + tableObject.elementUniqueID + "_" + menuID + '_Menu\').show_and_size(\'' + tableObject.elementUniqueID +"_" + menuID + '_Menu_button\');"'
		});
		return menuArray;
	
	},

	setParameter: function(name,value) {
		this[name]=value;
	},
	
	output: function(tableID,outputType,headType) {
		var tableObject = GET_GLOBAL_OBJECT('list_table', tableID);
		if (tableObject.baseTableData.columnsInfo.name.length=0) {
			alert('no columns in output');
			return;
		}
		var output="";
		switch (this.exportOutputType) {
			case 'csv':
				headingRowPrefix='';
				headingRowSuffix='\n';
				headingColPrefix=',';
				headingColPrefixFirst='';
				headingColSuffix='';
				rowPrefix='';
				rowSuffix='\n';
				colPrefix=',"';
				colPrefixFirst='"';
				colSuffix='"';
				break;
			case 'xml':
				output+="<"+tableObject.baseTableData.tableName+"s>";
				rowPrefix="<"+tableObject.baseTableData.tableName+">";
				rowSuffix="</"+tableObject.baseTableData.tableName+">";
				colPrefix=null;
				colSuffix=null;
				break;
			case 'html':
				output+="<html><body>";
			default:
				output+="<table>";
				headingRowPrefix="<tr>";
				headingRowSuffix="</tr>";
				headingColPrefix="<th>";
				headingColPrefixFirst=headingColPrefix;
				headingColSuffix="</th>";
				rowPrefix="<tr>";
				rowSuffix="</tr>";
				colPrefix="<td>";
				colPrefixFirst=colPrefix;
				colSuffix="</td>";
		}
		if (	this.exportOutputType!='xml' 
			&& this.exportHeadingType !="noHeading"
			) { 
			output+=headingRowPrefix;
			switch (this.exportHeadingType)  {
				case 'column':
					prefix=headingColPrefixFirst;
					for (column in tableObject.baseTableData.components.column)	{
						output+=prefix+column+headingColSuffix;
						prefix=headingColPrefix;
					}
					break;
				case 'title':
					prefix=headingColPrefixFirst;
					for (column in tableObject.baseTableData.components.column)	{
						output+=prefix+tableObject.baseTableData.components.column[column].title+headingColSuffix;
						prefix=headingColPrefix;
					}
					break;
			}
			output+=headingRowSuffix;
		}
		for( var row = 0; row < tableObject.baseTableData.rowsReturned; row++) {
			output+=rowPrefix;
			first=true;
			for (var column in tableObject.baseTableData.components.column)	{ 
				value=tableObject.baseTableData.baseData[row][tableObject.baseTableData.resultSetIndexByColumnName[column]];
				output+= (colPrefix==null?"<"+column+">":(first?colPrefixFirst:colPrefix))
						+ (value==null?"":value)
						+ (colSuffix==null?"</"+column+">":colSuffix);
				first=false;
			}
			output+=rowSuffix;
		}

		switch (this.exportOutputType) {
			case'html':
				output+="</table></html>";
				break;
			case'xml':
				output+="</"+tableObject.baseTableData.tableName+"s>";
				break;
		}
		dataExportedWindow = open('','displayWindow','width=800,height=400,left=60,top=60,scrollbars=yes');
		dataExportedWindow .document.open();
		dataExportedWindow .document.write(output);
		dataExportedWindow .document.close(); 

	}
});