/*******************************************************************************
 *  Author: Peter Prib
 * 
 *  Copyright Frygma Pty Ltd (ABN 90 791 388 622 2009) 2009 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/
 
CORE_CLIENT_ACTIONS.set("chart",  Class.create(CORE_CLIENT_ACTIONS.get("list_table"), {
	initialize: function($super, callParameters) {
		this.firstChartLoad = true;
		x=0;				// set up color pallet
		this.colourPallet=[];
		delta=255/5;
		for (i=0;i<5;i++){
			for (j=0;j<5;j++){
				for (k=0;k<5;k++){
					this.colourPallet[x++] = 'rgb(' + Math.floor(i*delta) + ',' + Math.floor(j*delta) + ','+ Math.floor(k*delta) +')';
	    		}
    		}
  		}
		if(callParameters.table == null) this.throwError("Could not render chart");
		//this is where the data that is being graphed is stored
		this.localDataSet = [];

		this.disableLeftMenu = callParameters.disableLeftMenu != null ? (Object.isString() ? (callParameters.disableLeftMenu == 'true' ? true : false) : callParameters.disableLeftMenu ) : false;
		
		this.parentPanel = getPanel(this.parentStageID, this.parentWindowID, this.parentPanelID);
		
		this.menuDirectory = callParameters.$menuDirectory;
		this.contextMenuDirectory = callParameters.$contextMenuDirectory;
		this.showOptions=(callParameters.$showOptions == null?true:callParameters.$showOptions=='true');
		this.chartName = callParameters.$chartName==null ? 'default' : callParameters.$chartName;
		this.chartTitle = callParameters.$chartTitle==null ? callParameters.$chartName : callParameters.$chartTitle;
		this.chartType = callParameters.$type==null ? 'line' : callParameters.$type.toLowerCase();
		this.chartWidth = 100;
 		this.chartHeight = 100;
		this.colour=[];
		this.xAxisPosition = 0;
		this.yAxisPosition = 0;
		this.display='chart';

		this.scaleUpOnly = Object.isString(callParameters.scaleUpOnly) ? (callParameters.scaleUpOnly == 'true' ? true : false) : callParameters.scaleUpOnly;
		this.maxYScale = 1;

		this.flipDataSet = callParameters.$flipDataSet=='true' ? true : false;
		this.showPoints = callParameters.$showPoints=='true' ? true : false;
		this.tickIncrement = 5;
		this.legendDisplay=(callParameters.$legend==null?"show":callParameters.$legend);
		switch (this.legendDisplay) {
				case 'show':
				case 'hide':
					break;
				default:
					throw "parameter legend can only equal show or hide";
		}
		if(callParameters.$colours != null) {
			var colours='black,'+callParameters.$colours;
			this.colour=colours.split(',');
		}
		if(callParameters.$slices != null) {
			this.slices=callParameters.$slices;
			switch (this.slices) {
				case 'row':
				case 'column':
					break;
				default:
					throw "parameter slices can only equal row or column";
			}
		} else this.slices='row';
		this.grouping=null;
		this.delta=null;
		this.deltaNormaliser=1;
		this.legendPositionX=60;
		this.legendPositionY=0;
		switch (this.chartType) {
			case 'line':
			case 'bar':
			case 'pushline':
			case 'setline':
			case 'stack':
				this.yAxisUpperBound = callParameters.$yAxisUpperBound;
				this.yAxisLowerBound = callParameters.$yAxisLowerBound;
			case 'pie':
				this.checkExists(callParameters.$xAxis,'Missing parameter xAxis');
				this.xAxis=callParameters.$xAxis.toUpperCase();
				this.checkExists(callParameters.$yAxis,'Missing parameter yAxis');
				this.yAxis=callParameters.$yAxis.toUpperCase();
				this.ySeries=this.yAxis.split(',');
				
				this.grouping=callParameters.$grouping;
				if (this.grouping==undefined)
					this.grouping = callParameters.$pivotColumn;
				 else
					if(callParameters.$pivotColumn!=undefined)
						this.throwError('Both pivot and grouping defined, pivot is alias for grouping');
				if (this.grouping==undefined) this.grouping=null;
				else this.grouping=this.grouping.toUpperCase();
				this.delta=callParameters.$delta;
				if (this.delta==undefined) this.delta=null;
				else this.delta=this.delta.toUpperCase();
				break;
			default:
				this.throwError('Unknown chart type: ' + callParameters.$type);
		}
		this.yScaling="AUTO";
		switch (this.chartType) {
			case 'line':
			case 'bar':
			case 'pushline':
			case 'setline':
			case 'stack':
				this.yScaling=callParameters.$yScale;
				if (this.yScaling==undefined) this.yScaling="AUTO";
				else this.yScaling=this.yScaling.toUpperCase();
				break;
			case 'pie':
				this.yScaling="NOAXIS";
				break;
			default:
		}
		delete callParameters.$type;
		delete callParameters.$chartTitle;
		delete callParameters.$chartName;
		delete callParameters.$xAxis;
		delete callParameters.$yAxis;
		delete callParameters.$yScale;
		delete callParameters.$grouping;
		$super(callParameters);
		
		this.parentPanel.refreshCallback = this.callBackText + '.refresh()';
	},
	throwError: function(msg) {
		alert(msg);
		throw msg;
	},
	loadContextMenus: function() {
		var thisObject = this;
		if (this.contextMenuDirectory==null) return;
		POSTDATA = new Object();
		POSTDATA.uniqueID 				= this.elementUniqueID;
		POSTDATA.stageID 				= this.parentStageID;
		POSTDATA.windowID 				= this.parentWindowID;
		POSTDATA.panelID 				= this.parentPanelID;
		POSTDATA.returntype 			= 'JSON';
		POSTDATA.baseMenuFolder			= this.contextMenuDirectory;
		POSTDATA.defaultStage 			= this.elementUniqueID + "_stage";
		POSTDATA.action				 	= "menu";
		
		new Ajax.Request(ACTION_PROCESSOR, {
				'parameters': POSTDATA,
				'method': 'post',
				'onCreate': function() {
						thisObject.parentPanel.startServerLoadIndicator();
				},
				'onComplete' : function() {
					thisObject.parentPanel.clearLoadIndicator();
				},
				'onSuccess': function(transport) {
					thisObject.parentPanel.setClientLoadIndicator();
					var menu = transport.responseJSON;
					if(menu.length != 0) {
						if(menu[0].elementPageWindows != null || menu[0].elementLinkList != null) {
							loadDecodedPage(menu[0].elementPageWindows, menu[0].elementLinkList);
						}
					}	
					thisObject.setMenuOptions(menu);
					thisObject.parentPanel.setWindowTitle(thisObject.chartTitle,menu,null);
				},
				'onFailure': function(transport,error) {
					thisObject.setError("Error Loading Menu, error: "+ error);
				}
		});
	},
	loadMenus: function() {
		var thisObject = this;
		if (this.menuDirectory==null) return;
		POSTDATA = new Object();
		POSTDATA.uniqueID 				= this.elementUniqueID;
		POSTDATA.stageID 				= this.parentStageID;
		POSTDATA.windowID 				= this.parentWindowID;
		POSTDATA.panelID 				= this.parentPanelID;
		POSTDATA.returntype 			= 'JSON';
		POSTDATA.baseMenuFolder			= this.menuDirectory;
		POSTDATA.defaultStage 			= this.elementUniqueID + "_stage";
		POSTDATA.action				 	= "menu";
		
		new Ajax.Request(ACTION_PROCESSOR, {
				'parameters': POSTDATA,
				'method': 'post',
				'onCreate': function() {
						thisObject.parentPanel.startServerLoadIndicator();
				},
				'onComplete' : function() {
					thisObject.parentPanel.clearLoadIndicator();
				},
				'onSuccess': function(transport) {
					thisObject.parentPanel.setClientLoadIndicator();
					var menu = transport.responseJSON;
					if(menu.length != 0) {
						if(menu[0].elementPageWindows != null || menu[0].elementLinkList != null) {
							loadDecodedPage(menu[0].elementPageWindows, menu[0].elementLinkList);
						}
					}
					thisObject.setMenuOptions(menu);
					getWindow(thisObject.parentStageID, thisObject.parentWindowID ).setWindowTitle(thisObject.chartTitle,menu,null);
				},
				'onFailure': function(transport,error) {
					thisObject.setError("Error Loading Menu, error: "+ error);
				}
		});
	},

	setParameter: function(name,value) {
		this[name]=value;
		switch (name) {
			case 'legendDisplay': 
						this.legendDisplay=value;
						this.legend.setStyle({'display': (this.legendDisplay=="hide"?"none":"block")});
						return (this.legendDisplay=="hide"?"show":"hide");
		}
		this.chartSize();
		switch (name) {
			case 'slices': return (value=='row'?'column':'row');
			case 'yScaling': return (value=='AUTO'?'EXPONENTIAL':'AUTO');
			case 'chartType': 
				switch (this.chartType) {
					case 'bar': return 'stack';
					case 'stack': return 'bar';
					case 'setline': return 'pushline';
					case 'pushline': return 'setline';
				}
			case 'display': return (value=='chart'?'data':'chart');
		}
	},

	setMenuOptions: function(menuArray) {
		if(!this.showOptions) return;
		if(this.optionsDialog==null) {
			this.optionsDialog = new floatingPanel(this.elementUniqueID + '_optionsDialog', 'RAW', "", this.elementUniqueID + '_optionsDialog_button', false, false);
			this.parentPanel.registerNestedObject(this.elementUniqueID + '_optionsDialog', this.optionsDialog);
		}
		var thisObject = this;
		if(!this.disableLeftMenu)
		{
			TABLE_MANIPULATION_MODULES.each(function(aTMModule) {
				if(aTMModule.value.panelLeftMenuObject != null) {
					var temp = aTMModule.value.panelLeftMenuObject(thisObject, menuArray);
					if(temp != null) menuArray = temp;
				}
			});
		}
		options='';
		switch (this.chartType) {
			case 'pie':
				options+='<tr><td>Slice</td><td>' 
						+'<input type="button" value="'
													+(this.slices=='row'?'column':'row')
													+'" onclick="this.value='+this.callBackText+'.setParameter('+"'slices'"+',this.value)"/>'
					+'</td></tr>';
				break;
			case 'line':
				options+='<tr><td>Y Scaling</td><td>'
						+'<input type="button" value="'
													+(this.yScaling=='AUTO'?'EXPONENTIAL':'AUTO')
													+'" onclick="this.value='+this.callBackText+'.setParameter('+"'yScaling'"+',this.value)"/>'
					+'</td></tr>';
				break;
			case 'pushline':
			case 'setline':
				options+='<tr><td>Chart Type</td><td>'
						+'<input type="button" value="'
													+(this.chartType=='setline'?'pushline':'setline')
													+'" onclick="this.value='+this.callBackText+'.setParameter('+"'chartType'"+',this.value)"/>'
					+'</td></tr>';
				break;
			case 'bar':
			case 'stack':
				options+='<tr><td>Chart Type</td><td>'
						+'<input type="button" value="'
													+(this.chartType=='bar'?'stack':'bar')
													+'" onclick="this.value='+this.callBackText+'.setParameter('+"'chartType'"+',this.value)"/>'
					+'</td></tr>';
				break;
		}
		options+='<tr><td>Legend</td><td>'
				+'<input type="button" value="'+(this.legendDisplay=="hide"?"show":"hide")+'" onclick="this.value='+this.callBackText+'.setParameter('+"'legendDisplay'"+',this.value)"/>'
					+'</td></tr>';
		options+='<tr><td>Show</td><td>'
				+'<input type="button" value="'+(this.display=="chart"?"data":"chart")+'" onclick="this.value='+this.callBackText+'.setParameter('+"'display'"+',this.value)"/>'
					+'</td></tr>';
		this.optionsDialog.draw();
		this.optionsDialog.setContent('<table>'+options+this.getMetricColumnsOptions()+'</table>','Options', null, null, null);
		menuArray.push({
				nodeType : "leaf",
				elementID : this.elementUniqueID + '_optionsDialog_button',
				elementValue : "Options",
				elementAction : 'onClick="FLOATINGPANEL_activeFloatingPanels.get(\'' + this.elementUniqueID + '_optionsDialog\').show_and_size(\'' + this.elementUniqueID + '_optionsDialog_button\');"'
		});
	},
	refresh : function() {
		this.firstChartLoad = true;
		this.retrieveTableData();
	},
	checkExists : function(value,errorMessage) {
	 	if (value==null) alert(errorMessage);
	},
	sizeWidth: function(Amount) {
		try { this.chartSize(); } catch(e) {}
	},
	sizeHeight: function(Amount) {
		try { this.chartSize(); } catch(e) {}
	},
	setWidth: function(Amount) {
		try { this.chartSize(); } catch(e) {}
	},
	setHeight: function(Amount) {
		try { this.chartSize(); } catch(e) {}
	},
	processDispalySetup: function() {
		this.baseTableData.chartTitle = this.chartTitle;
	},
	setError: function(ErrorMSG) {
		this.setDisplay("<table style='width:100%;height:100%'><tr><td align='center'><h2>"+ErrorMSG+"</h2></td></tr></table>");
	},
	setDisplay: function(data) {
		this.firstChartLoad = true;
		var container = $(this.parentPageID);
		if(container != null)
			container.update(data 
						+ "<table id='" + this.elementUniqueID + "_detailNode' style='border-style: solid; border-width:1px; font-size:10px; top:0px; left:60px ; position:absolute ; display:block; background-color: #FFFFFF;'"
						+	"></table>"
						);
 		this.detailNode = document.getElementById(this.elementUniqueID + "_detailNode");
	},
	renderTableData: function($super) {

		if (this.display=='data') {
			this.firstChartLoad = true;
			$super();
			return;
		}

		if(this.chartType == 'pushline') {
			var localColumns = [];
			var i = 0;
			
			for( var i= 0; i < this.data.length; i++) {
				if (this.data[i][j]==null) continue;
				xPos=this.xAxisPosition+Math.floor((i)*this.tickIncrement)+(j-1)*this.barWidth;
				yPos=this.yPosition(this.yScale(this.data[i][j]));
				this.ctx.lineTo(xPos,yPos);
				if(this.showPoints)	
					this.ctx.arc(xPos,yPos, 3, 0, Math.PI*2, false);
			}
			this.localDataSet;
		} else {
			if(this.flipDataSet)
				this.localDataSet = this.baseTableData.baseData.reverse();
			else
				this.localDataSet = this.baseTableData.baseData;
		}
		
		this.buildDataSet();
		if(this.firstChartLoad) {
			this.firstChartLoad = false;
			this.drawCanvas();
			this.loadMenus();
			this.loadContextMenus();
		} 
		this.chartSize();
	},
	chartSize: function () {
		if(this.canvas==null) return;
		try {this.resize();} catch(e){this.setError(e);return;}
		this.redrawChart();
	},
	redrawChart: function () {
		if(this.canvas==null) return;
		var errors;
		switch (this.chartType) {
			case 'pie':
				var colourCnt=(this.slices=='row'?this.data.length:this.columnIndex.length);
				break;
			default:
				var colourCnt=this.columnIndex.length;
		}
		if (colourCnt>this.colour.length) {
			if (colourCnt < 7 && this.colour.length==0 ) {
				this.colour[0]='black';
				this.colour[1]='#99CCFF'; // 'blue';
				this.colour[2]='red';
				this.colour[3]='green';
				this.colour[4]='#FF9933'; //'orange';
				this.colour[5]='#CC99FF';  //'purple';
				this.colour[6]='yellow';
			}  
			var delta=this.colourPallet.length/colourCnt;
			for( var i= this.colour.length; i < colourCnt; i++) {this.colour[i]=this.colourPallet[Math.floor(i*delta)];}
		}
		this.ctx.clearRect(0,0,this.chartWidth,this.chartHeight);
		this.ctx.strokeStyle = "black";
		this.ctx.lineWidth=1;
		switch (this.chartType) {
			case 'line':
			case 'bar':
			case 'pushline':
			case 'setline':
			case 'stack':
				this.drawLineAxis();
				break;
			default:
		}
		var thisObject = this;
		var offset = 0;
		switch (this.chartType) {
			case 'line':
				for( var j= 1; j < this.columnIndex.length; j++) {
					try {
						this.plot(j, 1, (this.deltaIndex[this.columnIndex[j]]? this.deltaData : this.data) );
					} catch(e) {
						errors += 'error plotting '+ this.label[i] + '  ' +e +'\n';
					}
				}
				break;
			case 'pushline':
			case 'setline':
				this.barWidth=Math.floor(this.tickIncrement/(this.columnIndex.length-1));
				for( var j= 1; j < this.columnIndex.length; j++) {
					try {
						this.plotSet(j, 1, (this.deltaIndex[this.columnIndex[j]]? this.deltaData : this.data) );
					} catch(e) {
						errors += 'error plotting '+ this.label[i] + '  ' +e +'\n';
					}
				}
				this.ctx.stroke();
				break;
			case 'bar':
				var xPos = 0;
				var yPos = 0;
				this.barWidth=Math.floor(this.tickIncrement/(this.columnIndex.length-1));
				for( var i= 0; i < this.data.length; i++) {
					for( var j= 1; j < this.columnIndex.length; j++) {
						if (this.data[i][j]==null) continue;
						xPos=this.xAxisPosition+Math.floor((i+0.5)*this.tickIncrement)+(j-1)*this.barWidth;
						yPos=this.yPosition(this.yScale(this.data[i][j]));
						this.ctx.fillStyle = this.colour[j];
						this.ctx.fillRect(xPos,yPos,this.barWidth,this.yAxisPosition-yPos);
					}
				}
				break;
			case 'stack':
				var xPos = 0;
				var yPos = 0;
				var y=0;
				this.barWidth=this.tickIncrement;
				for( var i= 0; i < this.data.length; i++) {
					xPos=this.xAxisPosition+Math.floor((i+0.5)*this.tickIncrement);
					var total=0;
					for( var j= 1; j < this.columnIndex.length; j++) {
						if (this.data[i][j]==null) continue;
						total+=this.data[i][j];
					}
					yPos=this.yAxisPosition-this.yScale(total);
					for( var j= 1; j < this.columnIndex.length; j++) {
						if (this.data[i][j]==null) continue;
						y=this.yScale(this.data[i][j]);
						this.ctx.fillStyle = this.colour[j];
						this.ctx.fillRect(xPos,yPos,this.barWidth,y);
						yPos+=y;
					}
				}
				break;
			case 'pie':
				var xPos = 0;
				var yPos = 0;
				var piesCount=(this.slices=='row'?this.columnIndex.length:this.data.length);
				var squareSize=Math.sqrt((this.chartHeight*this.chartWidth)/piesCount);
				if (squareSize>this.chartHeight) squareSize=this.chartHeight;
				if (squareSize>this.chartWidth) squareSize=this.chartWidth;
				if (squareSize<30) {
					alert('Not enough space to draw pie chart, number of charts: '+piesCount+' chart width:' + this.chartWidth + 'height:' + this.chartHeight);
					break;
				}
				for( var i=(this.slices=='row'?1:0); i < piesCount; i++) {
					this.drawPie(xPos,yPos,squareSize,i);
					xPos+=squareSize;
					if (xPos>this.chartWidth) {
						xPos=0;
						yPos+=squareSize;
						if (xPos>this.chartWidth) {
							alert('Not enough space to draw pie chart');
							break;
						}
					}
				}
				break;
			default:
				break;
		}
		while (this.legend.rows.length> 0) {this.legend.deleteRow(0);}
		switch (this.chartType) {
			case 'pie':
				if(this.slices=='row') {
					for(var i = 1; i < this.data.length; i++) {
						this.legend.insertRow(-1).insertCell(-1).innerHTML= "<a style='color:" + this.colour[i] + "' >" + this.data[i][0] + "</a>";
					}
				} else {
					for(var i = 1; i < this.columnIndex.length; i++) {
						this.legend.insertRow(-1).insertCell(-1).innerHTML="<a style='color:" + this.colour[i] + "' >" + this.label[i] + "</a>";
					}		
				}		
				break;
			default:
				this.legend.insertRow(-1).insertCell(-1).innerHTML="x axis: " + this.label[0];
				for(var i = 1; i < this.columnIndex.length; i++) {
					this.legend.insertRow(-1).insertCell(-1).innerHTML= "<a style='color:" + this.colour[i] + "' >" + this.label[i] + "</a>";
				}
		}
		if (errors!=null) throw errors;
	},
	
	canvasCoords: function (callingEvent) {
	    var xPos = callingEvent.clientX - this.canvasOffset[0]-10;
	    var yPos = callingEvent.clientY - this.canvasOffset[1]-10 ;
		while (this.detailXY.rows.length> 0) {this.detailXY.deleteRow(0);}
		var XYRow=this.detailXY.insertRow(-1);
		switch (this.chartType) {
			case 'line':
				var xPlot= (xPos -this.xOffset)/this.xRatio;
				var xMinRange= (xPos- 5 - this.xOffset)/this.xRatio;
				var xMaxRange= (xPos+ 5 - this.xOffset)/this.xRatio;
				switch (this.yScaling) {
					case "AUTO" : 
						var yPlot= (this.yOffset - yPos)/this.yRatio;
						var yMinRange= (this.yOffset - yPos - 5)/this.yRatio;
						var yMaxRange= (this.yOffset - yPos + 5)/this.yRatio;
						break;
					case "EXPONENTIAL" : 
						var yPlot= this.yOffset==yPos?0: Math.exp((this.yOffset - yPos)/this.yRatio);
						var yMinRange= this.yOffset==yPos?0: Math.exp((this.yOffset - yPos-5)/this.yRatio);
						var yMaxRange= this.yOffset==yPos?0: Math.exp((this.yOffset - yPos+5)/this.yRatio);
						break;
				}
				XYRow.insertCell(-1).innerHTML= "x: "+this.dataToString(0,xPlot);
				XYRow=this.detailXY.insertRow(-1);
				XYRow.insertCell(-1).innerHTML= "y: "+this.dataToString(1,yPlot);
				for( var row= 0; row < this.data.length; row++) {
					if (this.data[row][0]< xMinRange) continue;
					if (this.data[row][0]> xMaxRange) continue;
					for( var i= 0; i < this.data[row].length; i++) {
						if (isNaN(this.data[row][i])) continue;
						if(this.deltaIndex[this.columnIndex[i]]) {
							if (this.deltaData[row][i]< yMinRange) continue;
							if (this.deltaData[row][i]> yMaxRange) continue;
						} else {
							if (this.data[row][i]< yMinRange) continue;
							if (this.data[row][i]> yMaxRange) continue;
						}
						XYRow=this.detailXY.insertRow(-1);
						XYRow.insertCell(-1).innerHTML=this.label[i];
						XYRow.insertCell(-1).innerHTML="x: "+this.dataToString(0,this.data[row][0]);
						if(this.deltaIndex[this.columnIndex[i]])
							XYRow.insertCell(-1).innerHTML="y: "+this.dataToString(i,this.deltaData[row][i]);
						else
							XYRow.insertCell(-1).innerHTML="y: "+this.dataToString(i,this.data[row][i]);
					}
				}
				break;
			case 'pushline':
			case 'setline':
				break;
			case 'bar':
			case 'stack':
				var x=Math.floor((xPos - this.xAxisPosition)/this.tickIncrement-0.5);
				XYRow.insertCell(-1).innerHTML="x:";
				switch (this.dataType[0]) {
					case 'timestamp' :
					case 'date' :
					case 'datetime' :
						XYRow.insertCell(-1).innerHTML=this.dataToString(0,(xPos -this.xOffset)/this.xRatio);
						break;
					default:
						XYRow.insertCell(-1).innerHTML=this.data[x][0];
				}
				XYRow=this.detailXY.insertRow(-1);
				XYRow.insertCell(-1).innerHTML= "y:";
				XYRow.insertCell(-1).innerHTML=this.dataToString(1,(this.yOffset - yPos)/this.yRatio);
				break;
			default:
				break;
		}
		if (yPos<this.chartHeight/2) {
		 	this.detailXY.setStyle({'top':  yPos + 'px'});
		} else {
		 	this.detailXY.setStyle({'top':  (yPos-this.detailXY.getHeight()) + 'px'});
		}
		if (xPos<this.chartWidth/2) {
			this.detailXY.setStyle({'left': xPos + 'px'});
		} else {
			this.detailXY.setStyle({'left': (xPos -this.detailXY.getWidth())  + 'px'});
		}
		this.detailXY.setStyle({'display': 'block'});

//		this.ctx.save();
		this.ctx.strokeStyle = "blue";
		this.ctx.lineWidth=1;
		this.ctx.beginPath();		  			// x axis
		this.ctx.moveTo(xPos+0.5 ,this.yAxisPosition);  
		this.ctx.lineTo(xPos+0.5 ,0);
		this.ctx.stroke();
												// y axis  												 
		this.ctx.beginPath();					  
		this.ctx.moveTo(this.xAxisPosition,yPos+0.5);  
		this.ctx.lineTo(this.chartWidth,yPos+0.5);  
		this.ctx.stroke(); 
	},
	canvasCoordsReset: function (callingEvent) {
//		this.ctx.restore();
		this.redrawChart();
		this.detailXY.setStyle({'display': 'none'});
		while (this.detailXY.rows.length> 0) {this.detailXY.deleteRow(0);}
	},
	moveLegendSet: function (callingEvent) {
		this.legendOffsetX=callingEvent.clientX-this.legendPositionX;
		this.legendOffsetY=callingEvent.clientY-this.legendPositionY;
		this.legend.setStyle({'filter': ''});
		this.legend.setStyle({'opacity': ''});
		var _dragElement=this.legend;
//		this.legend.onmousemove=this.moveLegend;
		if(!IS_TOUCH_SYSTEM)
			eval("this.legend.onmousemove=function(callingEvent) {"+this.callBackText+".moveLegend(callingEvent,this,"+this.callBackText+");};");
		this.legend.focus(); 
		 // prevent text selection in IE 
		 this.legend.onselectstart = function () { return false; };
		  // prevent IE from trying to drag an image 
		this.legend.ondragstart = function() { return false; }; 
		
	},
	moveLegendReSet: function () {
		this.legend.setStyle({'filter': 'alpha(opacity=80)'});
		this.legend.setStyle({'opacity': '0.5'});
		this.legend.onmousemove=null;
	},
	moveLegend: function (callingEvent,object,parentData) {
	 	if (callingEvent == null) callingEvent = window.event; 
		parentData.legendPositionX=callingEvent.clientX-parentData.legendOffsetX;
		parentData.legendPositionY=callingEvent.clientY-parentData.legendOffsetY;
		object.setStyle({'left': parentData.legendPositionX + 'px'});
		object.setStyle({'top':  parentData.legendPositionY + 'px'});
	},
	yPosition: function (value) {
		if (value==null) return this.yAxisPosition;
		if (value==Infinity) return 0;
		if (value==-Infinity) return this.yOffset;
		return this.yOffset-value;
	},
	yScale: function (value) {
		switch (this.yScaling) {
			case "AUTO" : return value*this.yRatio;
			case "EXPONENTIAL" :
				if (value>0) return Math.log(value)*this.yRatio;
				if (value<=0) return Math.log(this.yDataMin*0.1)*this.yRatio;
				return null;
			default:
				this.throwError( "unknown y scaling: " + this.yScaling);
		}
	},
	xPosition: function (value) {
		return this.xOffset+value;
	},
	xScale: function (value) {
		return value*this.xRatio;
	},
	drawPie: function (x,y,d,i) {
 	  	var total=0;
 	  	if (this.slices=='row') {
			var arrayLength=this.data.length;
			for( var row= 0; row < arrayLength; row++) {
				total+=this.data[row][i];
			}
 	  	} else {
			var arrayLength=this.data[i].length;
			for( var j= 1; j < arrayLength; j++) {
				total+=this.data[i][j];
			}
		}
		if (total==0) return; 
		var xCentre=x+d/2;
		var yCentre=y+d/2;
		var radius=d/2*0.98;
		var angleStart=0;
		var angleEnd=0;
		var unitDegreesRatio=2 * Math.PI/total;
		for( var row= (this.slices=='row'?0:1); row < arrayLength; row++) {
			angleStart=angleEnd;
			angleEnd+=(this.slices=='row'?unitDegreesRatio*this.data[row][i]:unitDegreesRatio*this.data[i][row]);
	 	  	this.ctx.fillStyle = this.colour[row];
 		    this.ctx.beginPath();
	    	this.ctx.moveTo(xCentre, yCentre); 
  			this.ctx.arc(xCentre, yCentre, radius,angleStart,angleEnd,false);
	    	this.ctx.lineTo(xCentre, yCentre); 
			this.ctx.closePath();
			this.ctx.fill();
		}
		this.ctx.fillStyle = "black";
 	  	if (this.slices=='row') {
			this.ctx.fillText(this.label[i],x,y+10);
 	  	} else {
			this.ctx.fillText(this.localDataSet[i][this.columnIndex[0]],x,y+10);
		}
	},
	plotSet: function (y, offset, data)
	{
		this.ctx.strokeStyle = this.colour[y * offset];
		this.ctx.lineWidth=3;
		this.ctx.beginPath();
		for( var i= 0; i < data.length; i++) {
			if (data[i][y]==null) continue;
			xPos=this.xAxisPosition+Math.floor((i)*this.tickIncrement)+(y-1)*this.barWidth;
			yPos=this.yPosition(this.yScale(data[i][y]));
			this.ctx.lineTo(xPos,yPos);
			if(this.showPoints)
				this.ctx.arc(xPos,yPos, 3, 0, Math.PI*2, false);
		}
		this.ctx.stroke();
	},
	plot: function (y, offset, data) {
		if(data.length==0) return;
		if(data.length==1) {
			dataX=this.data[0][0];
			dataY=data[0][y];
			if (dataX==null || dataY==null) return;
			this.ctx.fillStyle = this.colour[y * offset];  
			this.ctx.fillRect (this.xPosition(this.xScale(dataX))-3,this.yPosition(this.yScale(dataY))-3,6,6);  
		 	return;
		}
		var dataY;
		var dataX;
		var errors;
		this.ctx.strokeStyle = this.colour[y * offset];
		this.ctx.lineWidth=1;
		var linePointCnt=0;
		for( var row= 0; row < data.length; row++) {
			try {
				dataX=this.data[row][0];
				dataY=data[row][y];
				if (dataX==null || dataY==null || isNaN(dataX) || isNaN(dataY)) {
					if(linePointCnt>0) {
						this.ctx.stroke();
						if(linePointCnt==1 && !this.showPoints) 
							this.ctx.fillRect (this.xPosition(this.xScale(this.data[row-1][0]))-3,this.yPosition(this.yScale(data[row-1][y]))-3,6,6);  
						linePointCnt=0;
					}
					continue;
				}
				plotX=this.xPosition(this.xScale(dataX));
				plotY=this.yPosition(this.yScale(dataY));
				if(++linePointCnt>1) {
					this.ctx.lineTo(plotX,plotY);
					continue;
				}
				this.ctx.beginPath();
				this.ctx.moveTo(plotX,plotY); 
			} catch (e) {
				errors += " x: " + dataX + " ( " + plotX + " ) " + " y: " + dataY + " ( " + plotY + " ) " + "\n" + e + "\n";
				this.ctx.stroke();
				linePointCnt=0;
			} 
		}
		if(linePointCnt>0) this.ctx.stroke();
		if(this.showPoints)
			for( var row= 0; row < data.length; row++) {
				dataY=this.yPosition(this.yScale(data[row][y]));
				if(dataY==undefined) continue;
				if(dataY==null) continue;
				this.ctx.arc(this.xPosition(this.xScale(this.data[row][0])),dataY, 3, 0, Math.PI*2, false);
			}
		this.ctx.stroke();
		if (errors!=null) throw errors;
	},
	draw: function($super) {
		if (this.display=='data') {
			$super();
			return;
		}
		this.parentPanel.setContent("", "loading", null, 'hidden', null);
	},
	drawCanvas: function() {
		if (this.data==null) this.buildDataSet();
		var output = "<canvas id='" + this.elementUniqueID + "_chart' width='"+this.chartWidth+"' height='"+this.chartHeight+"'"
				if(!IS_TOUCH_SYSTEM)
						output += " onmousedown=\""+this.callBackText + ".canvasCoords(event);\""
						+ " onmouseup=\""+this.callBackText + ".canvasCoordsReset();\"";
		output += " style='padding-top:10px;padding-left:10px;'></canvas>"
					+ "<table id='" + this.elementUniqueID + "_legend' style='font-size:10px; position:absolute; top: "+this.legendPositionY+"px; left: "+this.legendPositionX+"px; display:"+(this.legendDisplay=="hide"?"none":"block")+"; background:transparent; border:transparent; z-index: 8; background-color: #FFFFFF; filter:alpha(opacity=80); opacity:0.5;'"
					if(!IS_TOUCH_SYSTEM)
						output += " onmousedown=\""+this.callBackText + ".moveLegendSet(event);\""
						+ " onmouseup=\""+this.callBackText + ".moveLegendReSet();\"";
		output +=	"></table>"
					+ "<table id='" + this.elementUniqueID + "_detailXY' style='font-size:10px; top:0px; left:60px ; position:absolute ; display:none; background:transparent; border:transparent; z-index: 11; background-color: #FFFFFF; filter: alpha(opacity=80); opacity:0.6;'"
						if(!IS_TOUCH_SYSTEM)
						output += " onmouseup=\""+this.callBackText + ".canvasCoordsReset();\"";
		output +=	"></table>"
					;
		var menu=[];
		this.setMenuOptions(menu);
		this.parentPanel.setContent(output, this.baseTableData.chartTitle, null, 'hidden', menu);
		this.legend = document.getElementById(this.elementUniqueID + "_legend");
		this.detailXY = document.getElementById(this.elementUniqueID + "_detailXY");
 		this.canvas = initCanvas(document.getElementById(this.elementUniqueID + "_chart"));
		if (this.canvas!=null) {
			if (!this.canvas.getContext) {
				this.setError('canvas-unsupported');
				return;
			}
			this.canvasOffset=Element.cumulativeOffset(this.canvas);
			this.canvas.style.cursor = 'crosshair';
			this.ctx = this.canvas.getContext('2d');
			this.ctx.font = "10px sans-serif";
			try {this.resize();} catch(e){this.setError(e);return;}
		}
	},
	drawXAxisTick: function(x) {
		this.ctx.beginPath();		  			
		this.ctx.moveTo(x+0.5,this.yAxisPosition+5);  
		this.ctx.lineTo(x+0.5,this.yAxisPosition-5);
		this.ctx.stroke(); 
	},
	drawYAxisTick: function(y) {
		if(y==Infinity) return;
		if(y==-Infinity) return;
		this.ctx.beginPath();		  			
		this.ctx.moveTo(this.xAxisPosition+5,y+0.5);  
		this.ctx.lineTo(this.xAxisPosition-5,y+0.5);
		this.ctx.stroke(); 
	},
	dataToString: function(i,value) {
		switch (this.dataType[i]) {
			case 'timestamp' :
			case 'datetime' :
			case 'time' :
			case 'date' :
				var ts = new Date();
				ts.setTime(parseInt(value));
				var axisLabel='';
				switch (this.dataType[0]) {
						case 'timestamp' :
						case 'date' :
						case 'datetime' :
							if (this.precision[0] >= 1440) axisLabel+=ts.getFullYear()+'-';
							if (this.precision[0] >= 1440) axisLabel+=this.padLeadZero(ts.getMonth()+1,2)+'-';
							if (this.precision[0] >= 1440) axisLabel+=this.padLeadZero(ts.getDate(),2);
							if (this.precision[0] >= 1440) axisLabel+=' ';
						case 'time' :
							if (this.precision[0] >= 360) axisLabel+=this.padLeadZero(ts.getHours(),2)+':';
							if (this.precision[0] >=  60) axisLabel+=this.padLeadZero(ts.getMinutes(),2)+':';
							if (this.precision[0] >=  1) axisLabel+=this.padLeadZero(ts.getSeconds(),2);
				}
				return 	axisLabel;
			case 'int' :
			case 'real' :
				if (value>Math.pow(10,18)) return Math.round(value/Math.pow(10,15)).toString()+'P';
				if (value>Math.pow(10,15)) return Math.round(value/Math.pow(10,12)).toString()+'T';
				if (value>Math.pow(10,12)) return Math.round(value/Math.pow(10,9)).toString()+'G';
				if (value>Math.pow(10,9)) return Math.round(value/Math.pow(10,6)).toString()+'M';
				if (value>Math.pow(10,6)) Math.round(value/Math.pow(10,3)).toString()+'K';
				if (value ==Math.round(value)) return value.toString();
				if (value>=10000) return value.toFixed(0);
				if (value>=1000) return value.toFixed(1);
				if (value>=100) return value.toFixed(2);
				if (value>=10) return value.toFixed(3);
				if (value>=1) return value.toFixed(4);
				if (value>=0.1) return value.toFixed(5);
				if (value>=0.01) return value.toFixed(6);
				if (value>=0.001) return value.toFixed(7);
				return value.toString();
		}
		return value.toString();
	},
	padLeadZero : function(value,size) {
		return "000000000000".substr(0,size-value.toString().length)+value;
	},
	drawLineAxis: function() {
		this.ctx.fillStyle = "black";
		this.ctx.lineWidth=1;
		this.ctx.beginPath();		  			// x axis
		this.ctx.moveTo(this.xAxisPosition+0.5,this.yAxisPosition);  
		this.ctx.lineTo(this.xAxisPosition+0.5,0);
		this.ctx.stroke();
												// x ticks
		switch (this.chartType) {
			case 'line':
				if (this.xTicks.length>1) {
					var axisLabel='';
					var ts = new Date();
					ts.setTime(parseInt(this.xTicks[0]));
					switch (this.dataType[0]) {
						case 'timestamp' :
						case 'date' :
						case 'datetime' :
							if (this.precision[0] < 1440) axisLabel+=ts.getFullYear()+'-';
							if (this.precision[0] < 1440) axisLabel+=this.padLeadZero(ts.getMonth()+1,2)+'-';
							if (this.precision[0] < 1440) axisLabel+=this.padLeadZero(ts.getDate(),2);
							if (this.precision[0] < 1440) axisLabel+=' ';
						case 'time' :
							if (this.precision[0] < 360) axisLabel+=this.padLeadZero(ts.getHours(),2)+':';
							if (this.precision[0] <  60) axisLabel+=this.padLeadZero(ts.getMinutes(),2)+':';
							if (this.precision[0] <   1) axisLabel+=this.padLeadZero(ts.getSeconds(),2);
					}
					this.ctx.textAlign='left';
					this.ctx.fillText(axisLabel,0,this.chartHeight-this.axisOffset/2);
				}
				for(var i = 0; i< this.xTicks.length; i++) {
					var pos=this.xPosition(this.xScale(this.xTicks[i]));
					this.drawXAxisTick(pos);
					this.ctx.textAlign='center';
					this.ctx.fillText(this.dataToString(0,this.xTicks[i],true), pos,this.chartHeight-this.axisOffset/2);
				} 
				break;
			case 'bar':
			case 'pushline':
			case 'setline':
			case 'stack':
				if (this.xTicks.length==0) this.tickIncrement=this.xMax; 
				else this.tickIncrement=Math.floor(this.xMax/(this.xTicks.length+1));
				var k = Math.ceil((50/this.tickIncrement));
				for(var i = 0; i< this.xTicks.length; i+= k) {
					
					var pos=this.axisOffset + this.tickIncrement*(i+1);
					if(this.chartType == 'setline')
						pos -= this.tickIncrement;

					this.drawXAxisTick(pos);
					this.ctx.textAlign='center';

					switch (this.dataType[0]) {
						case 'timestamp' :
						case 'date' :
						case 'datetime' :
							var axisLabel='';
							var ts = new Date();
							ts.setTime(parseInt(this.xTicks[0]));
							if (this.precision[0] < 1440) axisLabel+=ts.getFullYear()+'-';
							if (this.precision[0] < 1440) axisLabel+=this.padLeadZero(ts.getMonth()+1,2)+'-';
							if (this.precision[0] < 1440) axisLabel+=this.padLeadZero(ts.getDate(),2);
							switch (this.dataType[0]) {
								case 'timestamp' :
								case 'datetime' :
									if (this.precision[0] < 1440) axisLabel+=' ';
								case 'time' :
									if (this.precision[0] < 360) axisLabel+=this.padLeadZero(ts.getHours(),2)+':';
									if (this.precision[0] <  60) axisLabel+=this.padLeadZero(ts.getMinutes(),2)+':';
									if (this.precision[0] <   1) axisLabel+=this.padLeadZero(ts.getSeconds(),2);
							}
							this.ctx.fillText(axisLabel, pos,this.chartHeight-this.axisOffset/2);
							break;
						default:					
							this.ctx.fillText(this.localDataSet[this.xTicks[i]][this.columnIndex[0]], pos,this.chartHeight-this.axisOffset/2);
					} 
				}
				break;
			default:
		}
		
												// y axis  												 
		this.ctx.beginPath();					  
		this.ctx.moveTo(this.xAxisPosition,this.yAxisPosition+0.5);
		if(this.chartType == 'setline')
			this.ctx.lineTo(this.chartWidth-this.tickIncrement,this.yAxisPosition+0.5); 
		else
			this.ctx.lineTo(this.chartWidth,this.yAxisPosition+0.5);  
		this.ctx.stroke(); 
												// y ticks

		for(var i = 0; i< this.yTicks.length; i++) {
			var pos=this.yPosition(this.yScale(this.yTicks[i]));
			this.drawYAxisTick(pos);
			this.ctx.textAlign='left';
			this.ctx.fillText(this.dataToString(1,this.yTicks[i]),0 , pos+3);
		} 
	},
	calculateTicks: function(max,min,type,metric) {
		var tickPosition = [];
		if (max==null) return tickPosition;
		var tickCount = Math.floor(this.yMax/20);
		if(tickCount < 1) tickCount = 1; 
		var i=0;
		var k=0;
		var duration=max-min;
		switch (type) {
			case 'timestamp' :
			case 'time' :
			case 'date' :
			case 'datetime' :
				this.precision[metric]=1;
				duration=Math.floor(duration/60000);   // minutes?
				if (duration > 0) {
					this.precision[metric]=60;
					var minTS= new Date();
					minTS.setTime(parseInt(min));
					var maxTS= new Date();
					maxTS.setTime(parseInt(max));
					minTS.setMilliseconds(0);					
					minTS.setSeconds(0);
					duration=Math.floor(duration/60);   // hours?
					if (duration > 0) { 	
						this.precision[metric]=360;
						minTS.setMinutes(0);
						duration=Math.floor(duration/24);   // days?
						if (duration > 0) { 	
							this.precision[metric]=1440;
							minTS.setHours(0);
							for(var j=1; j<100 ; j++) {
								if (duration<j*5+1) break; 
							}
							duration=j*24*60*60*1000;
						} else {
							duration=Math.floor((max-min)/(60*60*1000));             // hours
							duration=(Math.floor(duration/5)+1)*60*60*1000;
						}
					} else {	
						duration=Math.floor((max-min)/(60*1000));             // minutes
						if (duration<5) {
							duration=60*1000;
						} else if (duration<25) {
							duration=5*60*1000;
						} else {
							duration=10*60*1000;
						}
					} 					
					for(i = minTS.getTime() ; i < max;i=i+duration ) {
						if (i>min && i<=max) tickPosition[k++]=i;
						
					}
					break;
				}
				duration=max-min;
			case 'real':
			case 'int':
				min = parseFloat(min);
				max = parseFloat(max);
				var range = max-min;
				var tickSpan = (Math.floor(range/tickCount)).toPrecision(1);
				for(var j=0; j<=tickCount+10 ; j++) {
					tickPosition[j]= min + (j*tickSpan);
				}
				break;
			default:
				this.throwError("Unknown type: "+type+" for axis tick creation");
		}
		return tickPosition;
	},
	resize: function() {
 		this.width = $(this.parentPageID).getWidth();
 		this.height = $(this.parentPageID).getHeight();
		this.chartWidth = this.width - 25;
		this.chartHeight = this.height;
		this.canvas.setAttribute('width', this.chartWidth);
		this.canvas.setAttribute('height', this.chartHeight);
		this.axisOffset= 40;
		switch (this.dataType[0]) {
			case "int":
			case "real":
			case "date":
			case "time":
			case "datetime":
			case "timestamp":
				this.xAxisPosition = this.axisOffset;
				this.xMax = this.width-this.axisOffset;
				if(this.dataMin[0]==this.dataMax[0]) {
					 this.dataMin[0]=this.dataMax[0]-1;
					 this.dataMax[0]=this.dataMax[0]+1;
				} 
				this.xRatio = this.xMax/(this.dataMax[0]-this.dataMin[0]);
				this.xOffset= this.xAxisPosition-this.xScale(this.dataMin[0]);
				this.xTicks = this.calculateTicks(this.dataMax[0],this.dataMin[0],this.dataType[0],0);
				break;
			case "string":
				switch (this.chartType) {
					case 'stack':
					case 'bar':
					case 'pushline':
					case 'setline':
						this.xAxisPosition = this.axisOffset;
						this.xMax = this.width-this.axisOffset;
						break;    // xTicks built whilst building data
					case 'pie':
						break;
					case 'line':
					default:
						this.throwError("invalid x axis data type string for chart type " + this.chartType);
				}
				break;
//			case "clob":
//			case "dbclob":
//			case "blob":
//			case "xml":
			default:
		}		
		this.yAxisPosition = this.chartHeight-this.axisOffset;
		this.yMax = this.yAxisPosition-5;
		
		this.yDataMin = this.yAxisLowerBound;
		this.yDataMax = this.yAxisUpperBound;
		
		switch (this.chartType) {
			case 'stack':
				this.yDataMin= this.yDataMin != null ? this.yDataMin : 0;
				this.yDataMax= this.yDataMax != null ? this.yDataMax : 0;
				for( var i= 1; i < this.columnIndex.length; i++) {
					if (this.dataMax[i]==null) continue;
					this.yDataMax+=this.dataMax[i];
				}
				this.yDataMax=this.yDataMax*1.01;
				break;
			case 'bar':
			case 'pushline':
			case 'setline':
				this.yDataMin= this.yDataMin != null ? this.yDataMin : 0;
				this.yDataMax= this.yDataMax != null ? this.yDataMax : 0;
				for(var i = 1; i < this.columnIndex.length; i++) {
					if (this.yDataMax<this.dataMax[i]) this.yDataMax=this.dataMax[i];
				}
				this.yDataMax=this.yDataMax*1.1;
				break;
			default:
				this.yDataMax= this.yDataMax != null ? this.yDataMax : this.dataMax[1];
				this.yDataMin= this.yDataMin != null ? this.yDataMin : this.dataMin[1];
				for(var i = 1; i < this.columnIndex.length; i++) {
					if (this.yDataMax<this.dataMax[i]) this.yDataMax=this.dataMax[i];
					if (this.yDataMin>this.dataMin[i]) this.yDataMin=this.dataMin[i];
				}
				this.yDataMax= this.yDataMax == null ? 1 : this.yDataMax;
				this.yDataMin= this.yDataMin == null ? 0 : this.yDataMin;
				if(this.yDataMin==this.yDataMax)  
					if(this.yDataMax==0)
						this.yDataMax=1;
				this.yDataMin=this.yDataMin*0.99;
				this.yDataMax=this.yDataMax*1.01;
				break;
		} 
		switch (this.yScaling) {
			case "AUTO" : 
				if(this.scaleUpOnly && this.maxYScale < this.yDataMax)
					this.maxYScale = this.yDataMax;
				else if(!this.scaleUpOnly)
					this.maxYScale = this.yDataMax;
				this.yDataMax = this.maxYScale;
				this.yRatio = this.yMax/(this.yDataMax-this.yDataMin);
				if(this.yRatio==Infinity) this.yRatio=1
				if (isNaN(this.yRatio)) throw "y ratio calculation error, charting width:"+ this.yMax + " max:"+ this.yDataMax + " min:"+ this.yDataMin;
				this.yOffset= this.yAxisPosition+this.yScale(this.yDataMin);
				if (isNaN(this.yOffset)) throw "y offset calculation error, start position:"+ this.yAxisPosition + " plot value:"+ this.yDataMin + " ratio:"+ this.yRatio;
				this.yTicks = this.calculateTicks(this.yDataMax,this.yDataMin,this.dataType[1],1);
				break;
			case "EXPONENTIAL" : // graphing zero and below in exponential doesn't work
				if(this.yDataMax<=0) this.yDataMax=1;
				if(this.yDataMin<=0) {             
					this.yDataMin=this.yDataMax;
					var y;
					for( var row = 0; row < this.data.length; row++) {
						for(var i = 1; i < this.columnIndex.length; i++) {
						    y=(this.deltaIndex[this.columnIndex[i]]?this.deltaData[row][i]:this.data[row][i]);
							if (y==undefined) continue;
							if (y<=0) continue;
							if (y==null) continue;
							if (y<this.yDataMin) this.yDataMin=y;
						}
					}
					this.yDataMin=this.yDataMin*0.9;
				}  
				this.yRatio = this.yMax/(Math.log(this.yDataMax) - Math.log(this.yDataMin));
				if (this.yRatio==0) this.yRatio=1;
				this.yOffset= this.yAxisPosition+Math.floor(this.yScale(this.yDataMin));
				this.yTicks=[];
				var k=0;
				for( var i= 20 ; i > -20 && k < 8 ; i--) {
					if (Math.pow(10,i) > this.yDataMax) continue;
					if (Math.pow(10,i) < this.yDataMin) continue;
					this.yTicks[k++]=(Math.pow(10,i)/10)*10;
				} 
				if (k=0) {
					mid=this.yDataMin+(this.yDataMax-this.yDataMin)/2;
					for( var i= 20 ; i > -20 ; i--) {
						if (Math.pow(10,i) > min) continue;
					}
					for( var j=1 ; j < 10 ; j++) {
						if (Math.pow(10,i)*j < min) continue;
						this.yTicks[0]=Math.pow(10,i)*j;
						break;
					}
				} 
				break;
			case "NOAXIS" :
				break; 
			default:
				this.throwError( "unknown y scaling: " + this.yScaling);
		}
	},
	dataConversion: function(i,value) {
		if (value==null) return null;
		switch (this.dataType[i]) {
		 	case 'real':
		 		try{return parseFloat(value);} catch(e) {return null;}
		 	case 'int':
		 		try{return parseInt(value);} catch(e) {return null;}
		 	case 'timestamp':
		 		try{return Date.parse(value.substr(0,4)+'/'+value.substr(5,2)+'/'+value.substr(8,11))
		 				+ parseInt(value.substr(21,3));} catch(e) {return null;}
		 	case 'time':
		 	case 'datetime':
		 	case 'date':
		 		try{return Date.parse(value);} catch(e) {return null;}
			default: 
				return value;
		}
	},	
	buildDataSet: function() {
		if (this.baseTableData.rowsReturned <1) throw 'No data to chart';
		this.groupingValue="";
		this.columnIndex=[];
		this.deltaIndex=[];
		this.dataType=[];
		this.precision=[];
		this.group=[];
		this.data=null;
		this.label=[];
		this.groupIndex;
		this.groupValue=[];
		this.xTicks=[];
		this.yTicks=[];
		this.deltaCol=[];
		if (this.delta!=null) {
			var deltaArray=this.delta.split(",");
			deltaArray[deltaArray.length]=this.xAxis;
			for (var j=0; j<deltaArray.length;j++) {
				for (var i=0; i < this.baseTableData.columnsInfo.name.length; i++)	{
					if(this.baseTableData.columnsInfo.name[i]==deltaArray[j]) break;
				}
				if (i >= this.baseTableData.columnsInfo.name.length)
					this.throwError( "delta column "+deltaArray[j]+" not found" );

				switch (this.baseTableData.columnsInfo.type[i]) {
					case 'real': 
					case 'double': 
					case 'int':
					case 'bigint':
					case 'timestamp':
					case 'date':
						break;
					default:
						this.throwError( "delta column "+deltaArray[j]+" not numeric but "+this.baseTableData.columnsInfo.type[i] );
				}
				this.deltaCol[i]=this.baseTableData.columnsInfo.type[i];
			}
		}

		this.setColumnDetails(0,this.xAxis);
		if (this.grouping==null) {
			for( i = 0; i < this.ySeries.length; i++) {
				this.setColumnDetails(i+1,this.ySeries[i]);
			}
		} else {
			this.groupIndex=[];
			var groupingArray=this.grouping.split(",");
			j=0;
			for (var j=0; j<groupingArray.length;j++) {
				for (var i= 0; i < this.baseTableData.columnsInfo.name.length; i++)	{
					if(this.baseTableData.columnsInfo.name[i]==groupingArray[j]) break;
				}
				if (i >= this.baseTableData.columnsInfo.name.length)
					this.throwError( "grouping column "+groupingArray[j]+" not found" );
				this.groupIndex[j]=i;
			}
		}
		this.data=[];
		this.deltaData=[];
		this.dataMax=[];
		this.dataMin=[];
		
		var x = -1;
		if(this.delta!=null) 
			switch (this.deltaIndex[this.columnIndex[0]]) {
				case 'timestamp':
					var xNormliseFactor=1000/this.deltaNormaliser;
					break;
				default:
					var xNormliseFactor=this.deltaNormaliser;
			}	
		var xCol=this.columnIndex[0];
		for( var row = 0; row < this.baseTableData.rowsReturned; row++) {
			if (this.grouping==null) {
				this.data[++x]=[];
				this.deltaData[x]=[];
			} else {
				if (x==-1) {
					this.data[++x]=[];
					this.deltaData[x]=[];
				} else if (this.localDataSet[row][xCol] !=  this.localDataSet[row-1][xCol]) {
					this.data[++x]=[];
					this.deltaData[x]=[];
				}
				var newGroupingValue='';
				for( i = 0; i < this.groupIndex.length; i++) {
					newGroupingValue+=' '+ this.localDataSet[row][this.groupIndex[i]];
				}
				if (this.groupingValue!=newGroupingValue) {
					this.groupingValue=newGroupingValue;
					this.group[0]=this.groupingValue;
					var i;
					for( i = 0; i < this.groupValue.length; i++) {
						if(this.groupingValue==this.groupValue[i]) break;
					}
					if (i >= this.groupValue.length) {
						this.groupValue[i]=this.groupingValue;
						for(i = 0; i < this.ySeries.length; i++) {
							this.setColumnDetails(this.columnIndex.length,this.ySeries[i]);
						}
					}
				}
			}
			switch (this.chartType) {
				case 'line': break;
				case 'bar':
				case 'pushline':
				case 'setline':
				case 'stack':
					 this.xTicks[x]=row;
					 break;
			}
			for(var i = 0; i < this.columnIndex.length; i++) {
				if (this.group[i]!=this.groupingValue) {
					if (this.data[x][i]== undefined) this.data[x][i]=null; 
					continue;
				}
				var value = this.dataConversion(i,this.localDataSet[row][this.columnIndex[i]]);
				this.data[x][i] = value;
				if (this.deltaIndex[this.columnIndex[i]]) {
					if(i==0) {
						if (x>0) {
							this.deltaData[x][0] = value-this.data[x-1][0];
							xNormaliser=this.deltaData[x][0]/xNormliseFactor;
						}
					} else { 
						if (x==0)
							value=null;
						else  {
							value = (value - this.data[x-1][i]) / xNormaliser;
							this.deltaData[x][i] = value; 
						}
					}
				}
		 		if (this.dataMin[i]==null) {
		 			this.dataMin[i]=value;
		 			this.dataMax[i]=value;
		 		} else if (this.dataMin[i]>value) {
		 			this.dataMin[i]=value;
		 		} else if (this.dataMax[i]<value) {
		 			this.dataMax[i]=value;
		 		}
			}
		}
	},
   setColumnDetails: function(index,columnName) {
		for (var i= 0; i < this.baseTableData.columnsInfo.name.length; i++)	{
			if(this.baseTableData.columnsInfo.name[i]==columnName) break;
		}
		if (i >= this.baseTableData.columnsInfo.name.length)
			this.throwError("column "+columnName+" not found");
		this.deltaIndex[i]=false;
		if(this.delta!=null)
			this.deltaIndex[i]=(this.deltaCol[i]!=undefined);
		this.columnIndex[index]=i;
		this.dataType[index]=this.baseTableData.columnsInfo.type[i];
		this.label[index]=this.groupingValue + " " + this.baseTableData.components.column[columnName].title;
		this.group[index]=this.groupingValue;
	},
   setMetrics: function(select) {
   		this.ySeries=[];
   		var j=0;
  		for (var i = 0; i < select.options.length; i++) {
    		if (select.options[i].selected)	this.ySeries[j++] = select.options[i].value;
 		}
 		this.yAxis=this.ySeries.join();
 		this.renderTableData();
	},
    setGrouping: function(select) {
   		grouping=[];
   		var j=0;
  		for (var i = 0; i < select.options.length; i++) {
    		if (select.options[i].selected)	grouping[j++] = select.options[i].value;
 		}
 		if (grouping.length==0) this.grouping=null;
 		else this.grouping=grouping.join();
 		this.renderTableData();
	},
    setDelta: function(select) {
   		delta=[];
   		var j=0;
  		for (var i = 0; i < select.options.length; i++) {
    		if (select.options[i].selected)	delta[j++] = select.options[i].value;
 		}
 		if (delta.length==0) this.delta=null;
 		else this.delta=delta.join();
 		this.renderTableData();
	},
   getMetricColumnsOptions: function() {
   		option='<tr><td>Y Metrics</td><td><select multiple="multiple" onclick="'+this.callBackText + '.setMetrics(this)"/>';
		for (var i= 0; i<this.baseTableData.columnsInfo.name.length; i++)	{
			switch (this.baseTableData.columnsInfo.type[i]) {
				case 'real': 
				case 'double': 
				case 'int':
				case 'bigint':
					if(this.baseTableData.components.column[this.baseTableData.columnsInfo.name[i]]==null) break;
					selected=""; 
					for (var j=0;j<this.ySeries.length; j++)	{
						if(this.ySeries[j]==this.baseTableData.columnsInfo.name[i]) {
							selected='selected="selected"';
							break;
						}
					}
					option+='<option value="'+this.baseTableData.columnsInfo.name[i]+'" '+selected+'>'+this.baseTableData.components.column[this.baseTableData.columnsInfo.name[i]].title+'</option>';
					break;
			}
		}
		option+='</select></td></tr>'
   			+'<tr><td>Grouping</td><td><select multiple="multiple" onclick="'+this.callBackText + '.setGrouping(this)"/>';
		var grouping=this.grouping==null?[]:this.grouping.split(',');
		for (var i= 0; i<this.baseTableData.columnsInfo.name.length; i++)	{
			switch (this.baseTableData.columnsInfo.type[i]) {
				case 'string': 
					if(this.baseTableData.components.column[this.baseTableData.columnsInfo.name[i]]==null) break;
					selected=""; 
					for (var j=0;j<grouping.length; j++)	{
						if(grouping[j]==this.baseTableData.columnsInfo.name[i]) {
							selected='selected="selected"';
							break;
						}
					}
					option+='<option value="'+this.baseTableData.columnsInfo.name[i]+'" '+selected+'>'+this.baseTableData.components.column[this.baseTableData.columnsInfo.name[i]].title+'</option>';
					break;
			}
		}
		option+='</select></td></tr>'
   			+'<tr><td>Delta</td><td><select multiple="multiple" onclick="'+this.callBackText + '.setDelta(this)"/>';
		var delta=this.delta==null?[]:this.delta.split(',');
		for (var i= 0; i<this.baseTableData.columnsInfo.name.length; i++)	{
			switch (this.baseTableData.columnsInfo.type[i]) {
				case 'real': 
				case 'double': 
				case 'int':
				case 'bigint':
					if(this.baseTableData.components.column[this.baseTableData.columnsInfo.name[i]]==null) break;
					selected=""; 
					for (var j=0;j<delta.length; j++)	{
						if(delta[j]==this.baseTableData.columnsInfo.name[i]) {
							selected='selected="selected"';
							break;
						}
					}
					option+='<option value="'+this.baseTableData.columnsInfo.name[i]+'" '+selected+'>'+this.baseTableData.components.column[this.baseTableData.columnsInfo.name[i]].title+'</option>';
					break;
			}
		}
		option+='</select></td></tr>';
		return option;  
	}
}));