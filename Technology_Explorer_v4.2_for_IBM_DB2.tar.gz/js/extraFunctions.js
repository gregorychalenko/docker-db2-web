/*******************************************************************************
 *  Author: Peter Prib
 * 
 *   Copyright Frygma Pty Ltd (ABN 90 791 388 622 2009) 2009 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/
 
 /*
 
 Added functions from core base.
 
 */
 
function hideElements() {
	for (var i = 0; i < arguments.length; i++) { 
		document.getElementById(arguments[i]).style.display="none";
	}
/** removed as no longer working
	//Added by Matthew
	var GENERAL_BLANK_POPUP = activeFloatingPanel.get('GENERAL_BLANK_POPUP');
	if(GENERAL_BLANK_POPUP != null)
		GENERAL_BLANK_POPUP.close();
**/
}

function displayElements() {
	for (var i = 0; i < arguments.length; i++) { 
		document.getElementById(arguments[i]).style.display="block";
	}
}

function swapDisplayNext(icon) {
	if (icon.name=="collapsed") {
		icon.src = "images/icon-down-on.gif";
		icon.name="expanded";
		if(icon.nextSibling!=null)
			icon.nextSibling.style.display="block";
	} else {
		icon.src = "images/icon-right-on.gif";
		icon.name="collapsed";
		if(icon.nextSibling!=null)
			icon.nextSibling.style.display="none";
	}
	activeModalPanel.each(function(ID) { ID.value.size();});
}


function commandSwapDisplay(icon) {
	var i = 0;
	if (icon.name=="collapsed") {
		icon.src = "images/icon-down-on.gif";
		icon.name="expanded";
		for (i = 0; i < icon.nextSibling.rows.length; i++) { 
			icon.nextSibling.rows[i].style.display="block";
			icon.nextSibling.rows[i].cells[0].style.display="";
		}
	} else {
		selected=false;
		for (i = 0; i < icon.nextSibling.rows.length; i++) { 
			if(icon.nextSibling.rows[i].cells[0].childNodes[0].checked) {
				selected=true;
			}
		}
		if (!selected) {
			alert("Item not selected so can't collapse");
			return;
		}
		icon.src = "images/icon-right-on.gif";
		icon.name="collapsed";
		for (i = 0; i < icon.nextSibling.rows.length; i++) { 
			if(!icon.nextSibling.rows[i].cells[0].childNodes[0].checked) {
				icon.nextSibling.rows[i].style.display="none";
			} else {
				icon.nextSibling.rows[i].cells[0].style.display="none";
			}
		}
	}
	activeModalPanel.each(function(ID) { ID.value.size();});
}

function commandSelectSwap(element) {
	icon=element.parentNode.parentNode.parentNode.parentNode.previousSibling;
	commandSwapDisplay(icon);
}

function checkFormCompleted(form) {
	return true;
}

function checkValue(inObject,type) {
    input=inObject.value;
	if (input==null || input=="" ) return true;
   	switch (type) {
   		case "int" :
   			//Added by Matthew
   			if(input.match(/^[0-9]*$/) == null) {
   				input = prompt('Invalid integer, please change',input);
           		inObject.value=input;
   			}
   			break;
   		default:
   			break;
    	}
   	return true;
}
// below added again
function centerElement(elementIdToCenter) {
	if(elementIdToCenter == null)	return;
	var toCenter = document.getElementById(elementIdToCenter);
	var width = toCenter.getWidth();
	var height = toCenter.getHeight();
	var elementParent = toCenter.ancestors();
	var Pwidth = elementParent[0].getWidth();
	var Pheight = elementParent[0].getHeight();
	width = parseInt(Pwidth/2, 10) - parseInt(width/2, 10);
	height = parseInt(Pheight/2, 10) - parseInt(height/2, 10);
	toCenter.setStyle({'top': height + 'px'});
	toCenter.setStyle({'left': width + 'px'});
}
function showCommandHelp (callingEvent,elementId) {
	centerElement(elementId);
    var helpPanel=document.getElementById(elementId);
    helpPanel.style.display="block";
    helpPanel.style.border="groove";
    helpPanel.style.backgroundColor="#B8BFD8";
    helpPanel.style.position="absolute";
 	helpPanel.setStyle({'top': (callingEvent.clientY + 10) + 'px'});
	helpPanel.setStyle({'left': callingEvent.clientX + 'px'});
}

function commandRepeatClause (element) {
	tBody=element.parentNode.parentNode.parentNode;
	rowIndex=element.parentNode.parentNode.sectionRowIndex;
	newRow=tBody.insertRow(rowIndex+1);
	idOld=tBody.rows[rowIndex].getAttributeNode("id").value;
	newRow.innerHTML=tBody.rows[rowIndex].innerHTML;
	newRow.className="cmdRepeatable";
	newRow.setAttribute('id',idOld);
	commandRepeatClauseRebuild (tBody);
}

function commandRepeatClauseRebuild (tBody) {
	idTable=tBody.parentNode.getAttributeNode("id").value;
	for (i=0;i<tBody.childNodes.length;i++) {
		idOld=tBody.childNodes[i].getAttributeNode("id").value;
		idNew=idTable+'#'+i;
		tBody.childNodes[i].getAttributeNode("id").value=idNew;
  		node = tBody.childNodes[i].getElementsByTagName('*');
  		idOld=idOld+"_";
  		idNew=idNew+"_";
  		for (j=0;j<node.length;j++) {
			attnode=node[j].getAttributeNode("id");
			if (attnode!=null) attnode.value=attnode.value.replace(idOld,idNew);
			attnode=node[j].getAttributeNode("name");
			if (attnode!=null) attnode.value=attnode.value.replace(idOld,idNew);
			if (node[j].nodeName=='INPUT') {
				if (	node[j].getAttributeNode("type").value=='radio'
					|| node[j].getAttributeNode("type").value=='hidden'
					) {
					attnode=node[j].getAttributeNode("value");
					if (attnode!=null) attnode.value=attnode.value.replace(idOld,idNew);
				}
			}
  		}
  	}
  	i--;
	tBody.childNodes[0].childNodes[0].value=i;
   	activeModalPanel.each(function(ID) { ID.value.size();});
}

function commandGetReference (element,reference) {
	var divOverride=element.parentNode;
	var prefixId=divOverride.getAttributeNode("id").value;
	var referenceElement=document.getElementById(reference);
	if(referenceElement==null) {
		alert(" reference: "+reference+" not found");
		return;
	}
  	divOverride.innerHTML=referenceElement.cells[0].innerHTML;
  	var node = divOverride.getElementsByTagName('*');
  	for (i=0;i<node.length;i++) {
		attnode=node[i].getAttributeNode("id");
		if (attnode!=null) attnode.value = prefixId+'_'+attnode.value;
		attnode=node[i].getAttributeNode("name");
		if (attnode!=null) attnode.value = prefixId+'_'+attnode.value;
		if (node[i].nodeName=='INPUT') {
			if (node[i].getAttributeNode("type").value=='radio') {
				node[i].value = prefixId+'_'+node[i].value;
			}
		}
  	}
  	divOverride.innerHTML='<input type="hidden" value="'+prefixId+'" name="'+prefixId+'"/>'+divOverride.innerHTML;

   	activeModalPanel.each(function(ID) { ID.value.size();});
}

function commandCheckCompleted (node) {
	var isOK=true;
	var i;
	if (arguments.length==0) {
		var errNodes=document.getElementsByName("commandErrorMessage"); 
		for (i=0;i<errNodes.length;i++) {
			errNodes[i].parentNode.removeChild(errNodes[i]);
		}		
		var node = document.getElementById('commandForm');
	}
	if (node == null) throw 'commandCheckCompleted came across null node';
	try {
	  	switch(node.nodeName) {
			case '#text': break;
			case 'TEXTAREA':
			case 'INPUT':
				if (node.type != 'text' &&  node.type != 'textarea') break; 
				if (node.value != null)  
			 		if (node.value != '') break;
			    node.style.backgroundColor="red";
/**			    commandSetError(node,'Required input field not completed');
			    node.setAttribute('onchange','this.style.backgroundColor="#FFFFFF";this.setAttribute("onchange",null);this.parentNode.removeChild(this.previousSibling)');
**/			    node.setAttribute('onchange','this.style.backgroundColor="#FFFFFF";this.setAttribute("onchange",null)');
			 	isOK=false;
			 	break;
			case 'TABLE':
				switch (node.className) {
					case 'cmdSelectList':
						for (i=0;i<node.rows.length;i++) {
							if (node.rows[i].cells[0].childNodes[0].checked) {
								return commandCheckCompleted (node.rows[i].cells[1]);
							}
						}
						for (i=0;i<node.rows.length;i++) {
							if (node.rows[i].cells[0].childNodes[0].defaultChecked) {
								return commandCheckCompleted (node.rows[i].cells[1]);
							}
						}
						node.parentNode.childNodes[0].src='images/error.gif';
						return false;
						break;
					case 'cmdDynRef':
						if(node.rows[0].cells[1].childNodes[0].nodeName == 'BUTTON') {
							node.rows[0].cells[1].childNodes[0].style.backgroundColor="red";
							isOK = false;
							break;
						}
						isOK = (isOK && commandCheckCompleted (node.rows[0].cells[1]));
						break;
					default:
						for (i=0;i<node.rows.length;i++) {
							isOK = (isOK && commandCheckCompleted (node.rows[i]));
						}
						break;
				}
				break;
			case 'BUTTON':
				node.style.backgroundColor="red";
				isOK=false;
				break;
			case 'TR':
				for (i=0;i<node.cells.length;i++) {
					isOK = ( isOK && commandCheckCompleted (node.cells[i]));
				}
  				break;
			default:
				for (i=0;i<node.childNodes.length;i++) {
					if (!(node.childNodes[i].nodeName == '#text'))
						isOK = (isOK && commandCheckCompleted (node.childNodes[i]));
				}
				break;
		} 
	} catch (e) {
		commandSetError(node,e);
		isOK = false;
	}
	if(arguments.length==0) 
		if(!isOK) 
			alert('Not completed\n\n Complete missing items before proceeding or cancel');
	return isOK;		
}

function commandSetError (node,errorMessage){
	var top=0;
	var nodePos=node;
	while (nodePos != null ) {
		top+=nodePos.offsetTop;
		nodePos=nodePos.offsetParent;
	}	
	var div = document.createElement('div');
	div.setAttribute('name','commandErrorMessage');
	div.style.display="block";
	div.style.border="groove";
	div.style.backgroundColor="red";
    div.style.position="absolute";
 	div.setStyle({'top': (top + 10) + 'px'});
  	div.innerHTML=errorMessage;
  	node.parentNode.insertBefore(div,node);
 }

function getNodesByXPath (xmlDOM,node,xPath) {
	var selectedNodes = null;
	if (window.ActiveXObject) {    // IE
		try{
			var nodes=node.selectNodes(xPath);
			selectedNodes=[];
			for (i=0;i<nodes.length;i++) {
				selectedNodes.push(nodes[i].childNodes[0]);
			}
	  		return selectedNodes;
		}
		catch (e) {throw "Xpath issue, path "+xPath+" error: " + (typeof(e)=="object"?e.name + ": " +e.description:e);}
	}
	if (document.implementation && document.implementation.createDocument) {
		selectedNodes=[];
		var xpe = new XPathEvaluator();
		var nsResolver = xmlDOM.createNSResolver( xmlDOM.ownerDocument == null ? xmlDOM.documentElement : xmlDOM.ownerDocument.documentElement);
		try{var iterator=xpe.evaluate(xPath,node,nsResolver,XPathResult.ANY_TYPE,null);}
		catch (e) {
			throw "Xpath issue, path "+xPath+" error: " + (typeof(e)=="object"?e.name + ": " +e.description:e);
		}
  		while(item = iterator.iterateNext()) {selectedNodes.push(item);}
  		return selectedNodes;
   	}
   	throw 'Browse cannot handle xpath';
}

function getXSLTransformed  (xmlDOM,xsl,parameters) {
	if (xsl==null || xsl=="" ) throw "xsl is null or blank";
	try {var xslDOM = getDOMParsed(xsl);
	} catch (e) { throw "error parsing xsl, "+ e + ' xsl: '+ xsl;}
	if (window.ActiveXObject) {   //ie code
		if(parameters!=undefined)
			for (var paramName in parameters) {
				xmlDOM.addParameter(paramName, parameters[paramName]);
			}
		return getDOMParsed(xmlDOM.transformNode(xslDOM));
 										  // code for Mozilla, Firefox, Opera, etc.
	} else if (document.implementation && document.implementation.createDocument)  {
		xsltProcessor=new XSLTProcessor();
		try { xsltProcessor.importStylesheet(xslDOM);
		} catch (e) {
			throw "error in xsl syntax, "+ e+ ' xsl: '+ xsl; 
		}
		if(parameters!=undefined)
			for (var paramName in parameters) {
				xsltProcessorsetParameter(null,paramName,parameters[paramName]);
			}
		return xsltProcessor.transformToDocument(xmlDOM,document);
	}
	throw "browser not supported for xsl transform";
}

function getDOMParsedhandler () {
	switch (this.readyState) {
		case 0: return; //UNSENT
		case 1: return; //OPENED
		case 2: return; //HEADERS_RECEIVED
		case 3: return; //LOADING
		case 4:  //done
			if(this.status == 200) { // so far so good
				if(this.responseXML != null ) return;   // success!
  				else throw 'Empty response';
 			}
  			throw 'fetched the wrong page or network error, status: '+ this.status;
  		default:
  		throw 'unknown ready state:'+this.readyState + ' status: '+ this.status;
	}
}

function appendXML2HTML (node,xmlDOM,xslDOM,parameters) {
	if (window.ActiveXObject) {    //IE
		if(parameters!=undefined)
			for (var paramName in parameters) {
				xmlDOM.addParameter(paramName, parameters[paramName]);
			}
		node.innerHTML=xmlDOM.transformNode(xslDOM);
  	} else if (document.implementation && document.implementation.createDocument) {
  		xsltProcessor=new XSLTProcessor();
  		xsltProcessor.importStylesheet(xslDOM);
		if(parameters!=undefined)
			for (var paramName in parameters) {
				xsltProcessor.setParameter(null,paramName,parameters[paramName]);
			}
  		node.appendChild(xsltProcessor.transformToFragment(xmlDOM,document));
  	}
}

var DOMParsed = $H();

function getDOMParsed (data,xmlName) {
	var xhttp = null;
  	if(xmlName!==undefined) {
		if (DOMParsed[xmlName]!==undefined) return DOMParsed[xmlName]; 
  	}
	if (data.indexOf('<')<0) {
		if (DOMParsed[data]!==undefined) return DOMParsed[data]; 
		xmlName=data;
		if (window.XMLHttpRequest) xhttp=new window.XMLHttpRequest();
		else xhttp=new ActiveXObject("Microsoft.XMLHTTP");
//		xhttp.onreadystatechange = this.getDOMParsedhandler;
		xhttp.withCredentials = "true";
		xhttp.open("GET",data,false);
		xhttp.setRequestHeader('Content-Type', 'application/xml');  
		xhttp.setRequestHeader('Access-Control-Allow-Origin', '*');
		xhttp.setRequestHeader("If-Modified-Since", new Date(0));
		xhttp.send();
		data= xhttp.responseText; 
	}
	if (window.DOMParser) {
		parser=new DOMParser();
		var xmlDOM=parser.parseFromString(data,"text/xml");
	  	if (xmlDOM.documentElement.nodeName=="parsererror") throw " xml parser error: "+xmlDOM.documentElement.childNodes[0].nodeValue+ ' xml: '+ data;
	} else { //try Internet Explorer
	 	try {
	 		xmlDOM=new ActiveXObject("Microsoft.XMLDOM");
			xmlDOM.async="false";
			xmlDOM.loadXML(data);
			xmlDOM.setProperty("SelectionLanguage","XPath");
			xmlDOM.setProperty("SelectionNamespaces","xmlns:xhtml='http://www.w3.org/1999/xhtml' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:xs='http://www.w3.org/2001/XMLSchema'");  
		} catch(e) {
				throw 'Load xml failure: ' + e + ' xml: '+ data;
		}
  	}
  	if(xmlName!==undefined) DOMParsed[xmlName]=xmlDOM;
  	return xmlDOM;
}

function getXMLString(xmlDOM){
	try { //  Mozilla browsers
		var serializer = new XMLSerializer();
		return serializer.serializeToString(xmlDOM);
	} 
	catch (e) { // Internet Explorer 
		return xmlDOM.xml;
	}
}


function initCanvas(canvas) {
    if (window.G_vmlCanvasManager && window.attachEvent && !window.opera) {
    	canvas = window.G_vmlCanvasManager.initElement(canvas);
    }
    return canvas;
}

//***** used for filling in options on select
function selectGetListAJAXRequest(id,inSQL) {
	var i =0;
	var selectNode = document.getElementById(id);
	if (selectNode==null) {alert('selectGetListAJAXRequest could find id: '+id);return;}
	for (i=selectNode.length-1;i>=0;i--) {selectNode.remove(selectNode.i);}
	selectNode.insertRow(-1).insertCell(-1).innerHTML='<img height="40px" width="40px" src="images/loadingpage.gif"/>';
	POSTDATA.SQL = '';
/**
	var p=0;
	while () {
		var i=inSQL.substr(p).indexOf(':');
		if(i>=0) {
			var idDep=variable.substr(p+1);
			var idDepLength=idDep.indexOf('.');
			idDep=idDep.substr(0,idDepLength);
			var node = document.getElementById(idDep);
			if (null.length==null || null.length==0) {
				return;
			}
			POSTDATA.SQL += "'"+node.options[node.selectedIndex].text+"'";
	}
**/

	POSTDATA = new Object();
	POSTDATA.returntype 	= 'JSON';
	POSTDATA.action         = 'executeSQL';
	POSTDATA.USE_CONNECTION = getActiveDatabaseConnection();
	new Ajax.Request(ACTION_PROCESSOR, {
		'parameters': POSTDATA,
		onSuccess: function(transport) {
			var i = 0;
			var opt = null;
			for (i=selectNode.length-1;i>=0;i--) {selectNode.remove(selectNode.i);}
			selectNode.parentNode.nextSibling.childNodes[0].style.display="none";
			var result = transport.responseJSON;
			try{
				if(result == null) throw "An invalid JavaScript object was returned";
				if(result.flagGeneralError == true && result.connectionError == true) initiateConnectionRefresh();
				if(result.flagGeneralError == true || result.returnCode == "false" || result.returnCode == false) 
					throw (Object.isString(result.returnValue)?result.returnValue:result.returnValue.STMTMSG);
			} catch(e) {
				opt=document.createElement('option');
				opt.text=e;
				try{selectNode.add(opt,null);} catch (e) {selectNode.add(opt);}
				return;
			}
			for (i=1;i<result.returnValue.resultSet[0].data.length;i++) {
				opt=document.createElement('option');
				opt.text=result.returnValue.resultSet[0].data[i];
				try{selectNode.add(opt,null);} catch (e) {selectNode.add(opt);}
			}
			selectCheckDependencies(id);
		},
		'onException': function(transport,exception) {
			var opt=document.createElement('option');
			opt.text=exception;
			try{selectNode.add(opt,null);} catch (e) {selectNode.add(opt);}
		},
		onComplete: function(transport) {
		}
	});
}
function selectCheckDependencies(id,detailDependencies) {
		var path = null;
		var selectNode = null;
		var i = 0;
		var j = 0;
		var changed=[];
		for(i=0;i<detailDependencies.length;i++) {
			dep=detailDependencies[i];
			if(dep[1]!=id) continue;
			for (j=0;j<changed.length;j++) {change=changed[j];if(dep[0]==change[0]) break;}
			if(j==changed.length) changed.push(j);
		}
		for (i=0;i<changed.length;i++) {
			var dep=detailDependencies[i];	
			sqlNode=dep[2];
			var sql='';
			var sqlOK=true;
			for (var iS=0;iS<sqlNode.childNodes.length;iS++) {
               	if(sqlNode.childNodes[iS].nodeType==3) {
               		sql+=sqlNode.childNodes[iS].nodeValue;
               		continue;
               	}
               	if(sqlNode.childNodes[iS].nodeName=="db2mc:value") {
					variable=sqlNode.childNodes[iS].getAttribute('id');
					if(variable!=null) {
						selectNode = document.getElementById(id);
						if (selectNode.length==0) {
							sql+="***logic error not found***";
							sqlOK=False;
							continue;
						}
						sql+=selectNode.options[selectNode.selectedIndex].text;
						continue;
					}
					var variable=sqlNode.childNodes[iS].getAttribute('xpath');
					if(variable!=null) {
						var iVA=variable.indexOf('db2mc:attr(');
						if(iVA>=0) {
							var attr=variable.substr(iVA+11);
							var iVAe=attr.indexOf(')');
							attr=attr.substr(0,iVAe);
							selectNode = document.getElementById(this.elementUniqueID+'_in_'+attr);
							if (selectNode.length==null || selectNode.length==0) {
								//alert("logic error attribute "+attr+" not found" );
								continue;
							}
							path =variable.substr(0,iVA)+selectNode.options[selectNode.selectedIndex].text+variable.substr(iVA+12+iVAe);
						} else path=variable;
						var parentNode=dep[3];
						nodes=getNodesByXPath(this.xmlData,parentNode,path);
						if(nodes.length!=1) {
							alert("logic error expected 1 but found "+nodes.length+" xpath: "+path);
							sql+="***logic error too many nodes***";
							sqlOK=false;
						} else sql+=nodes[0].nodeValue;
						continue;
					}
				}
			}
			selectNode=document.getElementById(this.elementUniqueID+'_in_'+dep[0]);
			selectNode.parentNode.nextSibling.childNodes[0].style.display="block";
			selectGetListAJAXRequest(dep[0],sql); 
		}
}

function getPHPSessionId() {
	try {
	    var PHPSESSID=document.cookie.substr(document.cookie.lastIndexOf('PHPSESSID=')+10,document.cookie.length);
   		return PHPSESSID.substr(0,PHPSESSID.indexOf(';'));
   	} catch(e) {return null;}

}

function resetCaching() {
	DOMParsed = $H();
}