/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
var activeModalPanel = $H();
function openModalWindow(data, type, callingActionStack, parameters)
{
	if(type == null)
		type = "RAW";
	return new modalPanel("modalPanel_" + getGUID(), type, data, false, callingActionStack, parameters);
}
var modalPanel = Class.create(panel, {
	initialize: function($super, myID, Type, Data, hideMenuBar, callingActionStack, parameters) {
		$super(myID,null, null, false, Type, Data, "", null, parameters);
		activeModalPanel.set(this.elementUniqueID, this);
		this.destroyOnHide = false;
		this.CallingActionStack = callingActionStack;
		if(this.CallingActionStack != null)
		{
			try{
					this.CallingActionStack.localVariables.result = {
							returnCode: 'false',
							returnValue : ""
						};
			}catch (e){
			}
		}
		this.hideMenuBar = hideMenuBar;
		if(hideMenuBar == null)
		this.hideMenuBar = false;
		this.level = getTopZindex();
		this.visibleFloatingObject = null;
		this.AllowAutoClosingOfFloatingObject = true;
		if(visibleFloatingObject != null)
		{
			if(visibleFloatingObject.type != "CONTEXTBASE")
			{
				this.visibleFloatingObject = visibleFloatingObject;
				this.AllowAutoClosingOfFloatingObject = AllowAutoClosingOfFloatingObject;
				visibleFloatingObject = null;
				AllowAutoClosingOfFloatingObject = true;
			}
		}
		if(this.overflowStyle == null)
			this.overflowStyle = "hidden";
		this.minLeft = this.minLeft == null ? 50 : this.minLeft;
		this.minRight = this.minRight == null ? 50 : this.minRight;
		this.contentStyle = this.contentStyle == null ? "" : this.contentStyle;
		this.draw();
	},
	setDestroyOnHide: function(destroyOnHide) {
		this.destroyOnHide = destroyOnHide;
	},
	show_and_size: function()
	{
		this.size();
	},
	setContent: function(Content, Title, PanelInformation)
	{
		var panelTitle = $("panelTitle_" + this.elementUniqueID);
		var contentHolder = $(this.elementUniqueID);
		var theDataObjectChildren = [];
		if(PanelInformation == null)//l
			PanelInformation = "";
		if(Title == null)
			Title = "";
		if(Content != null && contentHolder != null)
		{
			contentHolder.update(Content);
			theDataObjectChildren = contentHolder.select('div[id="title"]');
			if(theDataObjectChildren.size() > 0)
			{
				Title = theDataObjectChildren[0].innerHTML;
			}
			theDataObjectChildren = contentHolder.select('div[id="panelInformation"]');
			if(theDataObjectChildren.size() > 0)
			{
					PanelInformation = theDataObjectChildren[0].innerHTML;
			}
		}
		Title = Title.replace(/ /g, '&nbsp;');
		if(panelTitle != null)
		{
			if(PanelInformation != "")
			{
				Title = "<table><tr><td>" + Title + "</td><td><img style='float:none' id='{$pageID}_PageInformationButton' onMouseUp=\"stopPropagation(event);\" onMouseDown='show_GENERAL_BLANK_POPUP(null, decodeURIComponent(\"<NOBR>" + escape(PanelInformation) + "</NOBR>\"));' src=\"images/info.gif\"/></td></tr></table>";
			}
			panelTitle.update(Title);
		}
		this.size();
	},
	modalPanelControls: function () {
		return "";
	},
	modalPanelLeft: function () {
		return "";
	},
	modalPanelRight: function() {
		return "";
	},
	draw: function() {
		this.hideMenuBar = true;
		this.elementUniqueID = this.elementName;
		output  = "<div id='" + this.elementUniqueID + "_modalWindowLayout'>"
				+ 	"<div id='" + this.elementUniqueID + "_modalBackgroundDiv' class='modalPopupTransparent' style='z-index: " + getTopZindex() + ";'> "
				+	"</div>"
				+  	"<div class='modalPopupWindow' id='" + this.elementUniqueID + "_container' style='border-color:#ddd;-webkit-border-radius:5px;-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);display:block;background-color:#E1E1E1;overflow:hidden;z-index: " + getTopZindex() + ";'>"
				+  		"<table id='" + this.elementUniqueID + "_content' cellpadding='0' cellspacing='0'>"
				+  			"<tr>"
				+  				"<td>"
				+  					"<table style='width:100%;height:25px;background:-webkit-gradient(linear, left top, left bottom, from(#bbb), to(#eee));' cellpadding='0' cellspacing='0'  class='contextBase'>"
				+  						"<tr>"
				+  							"<td align='left' style='width:0px;padding-left:5px;' id='" + this.elementUniqueID + "_fixedRightMenu'>"
				+  							"</td>"
				+  							"<td align='left'>"
				+								"<div id='panelTitle_" + this.elementUniqueID + "'>"
				+  								"</div>"
				+							"</td>"
				+  							"<td align='right' style='width:0px;' id='" + this.elementUniqueID + "_fixedLeftMenu'>"
				+  							"</td>"
				+  						"</tr>"
				+  					"</table>"
				+  				"</td>"
				+  			"</tr>"
				+  			"<tr>"
				+  				"<td align = 'center'>"
				+  					"<table style='width:100%;height:100%;background-color:white;' cellpadding='5px' cellspacing='0'  class='contextBase'>"
				+  						"<tr><td style='width:" + this.minLeft + "px;'>" + this.modalPanelLeft() 
				+ 							"</td>"
				+							"<td>"
				+ 								"<div id='" + this.elementUniqueID + "_ContentContainer' style='position:static;overflow:" +  this.overflowStyle + ";text-align:left;" + this.contentStyle + "'>"
				+ 									"<form id='" + this.elementUniqueID + "'>"
				+  									"</form>"
				+								"</div>"
				+  							"</td>"
				+							"<td style='width:" + this.minRight + "px;'>" + this.modalPanelRight()
				+ 							"</td>"
				+						"</tr>"
				+  						"<tr>"
				+							"<td></td>"
				+							"<td align='center' style='width:10px;text-align:center;' id='" + this.elementUniqueID + "_fixedCenterMenu'>"
				+ 								this.modalPanelControls()
				+  							"</td>"
				+							"<td></td>"
				+						"</tr>"
				+				  "</table>"
				+ 				"</td>"
				+  			"</tr>"
				+  		"</table>"
				+ 	"</div>"
				+ "</div>";
		$("PageBody").insert(output);
		var thisObject = this;
		$(this.elementUniqueID).observe('keypress', function(event) {
				if(event.keyCode == Event.KEY_RETURN)
				{
					thisObject.returnCallOK();
					event.stop();
					return false;
				}
			});
		this.size();
			createContextMenuOnPanelObject(this.elementUniqueID + "_fixedLeftMenu", [
			{
				nodeType: "LEAF",
				elementID : "Close",
				elementValue : CORE_MESSAGE_STORE.LANGUAGE_MESSAGES.CLOSE,
				elementAction : (IS_TOUCH_SYSTEM ? "ontouchstart" : "onClick" ) + "=\"activeModalPanel.get('" + this.elementUniqueID + "').destroy();\"",
				elementSubNodes : null,
				elementSubNodeDirection : HORIZONTAL
			}
			], HORIZONTAL, this);
		if(this.TYPE != "RAW")
		{
			this.reloadPage();
		}
		else
		{
			this.setContent(this.DATA);
		}
	},
	returnCallOK: function() {
		return;
	},
	sizeWidth: function(Amount) {
		this.size();
	},
	sizeHeight: function(Amount) {
		this.size();
	},
	setWidth: function(Amount) {
		this.size();
	},
	setHeight: function(Amount) {
		this.size();
	},
	destroy: function($super, fillReturn) {
		var thisObject = this;
		fillReturn = fillReturn == null ? true : fillReturn;
		try {
			if(this.CallingActionStack != null && fillReturn)
			{
				this.CallingActionStack.localVariables.result.returnValue = [];
				var localFormOptions = $(this.elementUniqueID).serialize(true);
				var keys = Object.keys(localFormOptions);
				keys.each(function(key){
					thisObject.CallingActionStack.localVariables.result.returnValue[key] = localFormOptions[key];
					thisObject.CallingActionStack.localVariables.parameters.set(key, localFormOptions[key]);
					thisObject.CallingActionStack.defaultParameterList.set(key, localFormOptions[key]);
				});
			}
		} catch(e) {}
		this.myParent = null;
		this.nestedObject.each(function(pair)
		{
			if(pair.value != null)
			pair.value.destroy();
		});
		this.nestedObject = $H();
		Element.remove($(this.elementUniqueID + "_modalWindowLayout"));
		activeModalPanel.unset(this.elementUniqueID);
		if(visibleFloatingObject != null)
		{
			visibleFloatingObject.close();
		}
		visibleFloatingObject = this.visibleFloatingObject;
		AllowAutoClosingOfFloatingObject = this.AllowAutoClosingOfFloatingObject;
		try {
			if(this.CallingActionStack != null)
			{
				this.CallingActionStack.localVariables.parameters.set("RETURN_CODE", decodeURIComponent(this.CallingActionStack.localVariables.result.returnCode));
				this.CallingActionStack.localVariables.parameters.set("RETURN_VALUE", decodeURIComponent(this.CallingActionStack.localVariables.result.returnValue));
				this.CallingActionStack.actionResults.set(this.CallingActionStack.actionScript.name,this.CallingActionStack.localVariables.result);
				this.CallingActionStack.thisObject.executeFollowOnActions(this.CallingActionStack, 0, 0, 0);
			}
		} catch(e) {}
		$super();
	},
	size: function() {
			var modalWindowContainer = $(this.elementUniqueID + "_container");
			var modalWindowBackground = $(this.elementUniqueID + "_modalBackgroundDiv");
			var modalWindowContent = $(this.elementUniqueID + "_ContentContainer");
			modalWindowBackground.show();
			modalWindowBackground.setStyle({"width": pageWidth + 'px',"height": pageHeight + 'px', "left":"0px","top":"0px"});
			modalWindowContent.setStyle({"width": this.minWidth + "px", "height" : this.minHeight + "px", "overflow":"hidden"});
			var contentWidth = modalWindowContent.scrollWidth;
			var contentHeight = modalWindowContent.scrollHeight;
			contentWidth = contentWidth < this.minWidth ? this.minWidth : (this.maxWidth == null ? contentWidth : (this.maxWidth < contentWidth ? this.maxWidth : contentWidth));
			contentHeight = contentHeight < this.minHeight ? this.minHeight : (this.maxHeight == null ? contentHeight : (this.maxHeight < contentHeight ? this.maxHeight : contentHeight));
			modalWindowContent.setStyle({"width": (modalWindowContent.scrollWidth) + 'px'});
			modalWindowContent.setStyle({"height": (modalWindowContent.scrollHeight) + 'px'});
			var containerWidth = modalWindowContainer.scrollWidth;
			var containerHeight = modalWindowContainer.scrollHeight;
			// If the content is bigger than the page size, limit the modal panel's size to the pagesize - (offset + minimum margins)
			if (pageHeight < (MODALPANEL_TOP_MINIMUM_MARGIN + MODALPANEL_BOTTOM_MINIMUM_MARGIN + containerHeight))
			{
				modalWindowContainer.style.top = MODALPANEL_TOP_MINIMUM_MARGIN + 'px';
				modalWindowContent.setStyle({ "height": (contentHeight - ((containerHeight - pageHeight) + (MODALPANEL_TOP_MINIMUM_MARGIN + MODALPANEL_BOTTOM_MINIMUM_MARGIN)) + 15) + 'px', "overflow": "auto" });
			}
			else
			{
				modalWindowContainer.style.top = ((pageHeight - containerHeight) / 2) + 'px';
				modalWindowContent.setStyle({ "height": (contentHeight + 15) + 'px' , "overflow": "auto" });
			}
			if (pageWidth <(MODALPANEL_LEFT_MINIMUM_MARGIN + MODALPANEL_RIGHT_MINIMUM_MARGIN + containerWidth))
			{
				modalWindowContainer.style.left = MODALPANEL_LEFT_MINIMUM_MARGIN + 'px';
				modalWindowContent.setStyle({ "width": (contentWidth - ((containerWidth - pageWidth) + (MODALPANEL_LEFT_MINIMUM_MARGIN + MODALPANEL_RIGHT_MINIMUM_MARGIN))) + 'px', "overflow": "auto" });
			}
			else
			{
				modalWindowContainer.style.left = ((pageWidth - containerWidth) / 2) + 'px';
				modalWindowContent.setStyle({"width": (contentWidth) + 'px', "overflow": "auto" });
			}
		}
	});