/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
function openModalForm(data, type, callingActionStack, parameters)
{
	if(type == null)
		type = "RAW";
	new modalPanelForm("alertModalPanel_" + getGUID(), type, data, false, callingActionStack, parameters);
}
var modalPanelForm = Class.create(modalPanel, {
	initialize: function($super, myID, Type, Data, hideMenuBar, callingActionStack, parameters) {
		this.buttonA = Object.isString(parameters['buttonOK']) ? parameters['buttonOK'] : (Object.isString(parameters['buttonA']) ? parameters['buttonA'] : CORE_MESSAGE_STORE.LANGUAGE_MESSAGES.OK);
		this.buttonB = Object.isString(parameters['buttonCancel']) ? parameters['buttonCancel'] : (Object.isString(parameters['buttonB']) ? parameters['buttonB'] : CORE_MESSAGE_STORE.LANGUAGE_MESSAGES.CANCEL);
		this.exitScript = parameters['exitScript'];
		this.exitScript=(this.exitScript == null)?"":"try {"+this.exitScript+";} catch (e) {alert(e); return;};";
		if(parameters != null)
		{
			var OtherButtons = $H();
			var tempHash = new Hash(parameters);
			tempHash.each(function(item) {
				if(item.key.substring(0,7).toLowerCase() == "button_")
				{
					OtherButtons.set(item.key.substring(7), item.value);
				}
			});
			this.OtherButtons = OtherButtons;
		}
		this.minLeft = 0;
		this.minRight = 0;
		$super(myID, Type, Data, hideMenuBar, callingActionStack, parameters);
	},
	modalPanelControls: function () {
		var output = "";
		var elementUniqueID = this.elementUniqueID;
		var exitScript=this.exitScript;
		output += "<table align='right' style='width:100%;position:static;'><tr><td></td>";
		output += "<td style='text-align:right;width:5px'><button ";
                if(IS_TOUCH_SYSTEM)
                        output += "style='border-color:#ddd;-webkit-border-radius:5px;padding:5px;margin:5px;background:-webkit-gradient(linear, left top, left bottom, from(#eee), to(#aaa));-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);'";
                output += " onClick=\""+exitScript+"activeModalPanel.get('" + elementUniqueID + "').returnCallOK();\">" + this.buttonA.replace(/ /g, '&nbsp;') + "</button></td>";
		if(this.OtherButtons != null)
		{
			this.OtherButtons.each(function(item) {
			output += "<td style='text-align:right;width:5px'><button  ";
	                if(IS_TOUCH_SYSTEM)
        	                output += "style='border-color:#ddd;-webkit-border-radius:5px;padding:5px;margin:5px;background:-webkit-gradient(linear, left top, left bottom, from(#eee), to(#aaa));-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);'";
                	output += " onClick=\""+exitScript+"activeModalPanel.get('" + elementUniqueID + "').returnCall('" + item.key + "');\">" + item.value.replace(/ /g, '&nbsp;') +"</button></td>";
			});
		}
		output += "<td style='text-align:right;width:5px'><button ";
                if(IS_TOUCH_SYSTEM)
                        output += "style='border-color:#ddd;-webkit-border-radius:5px;padding:5px;margin:5px;background:-webkit-gradient(linear, left top, left bottom, from(#eee), to(#aaa));-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);'";
                output += " selected onClick=\"activeModalPanel.get('" + elementUniqueID + "').destroy();\">" + this.buttonB.replace(/ /g, '&nbsp;') + "</button></td>";
		output += "</tr></table>";
		return output;
	},
	modalPanelLeft: function () {
		return "";
	},
	modalPanelRight: function() {
		return "";
	},
	returnCallOK: function() {
		if(this.CallingActionStack != null)
		{
			try{
					this.CallingActionStack.localVariables.result.returnCode= 'true';
			}catch (e){
			}
		}
		this.destroy();
	},
	returnCall: function(returnValue) {
		if(this.CallingActionStack != null)
		{
			try{
					this.CallingActionStack.localVariables.result.returnCode= returnValue;
			}catch (e){
			}
		}
		this.destroy();
	}
});