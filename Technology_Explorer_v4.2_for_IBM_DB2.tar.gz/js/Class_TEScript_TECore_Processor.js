/*******************************************************************************
 *Copyright IBM Corp. 2007 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
var actionRunID = 0;
var actionStackHolder = $H();

var runTEScript = function(actionGUID, theScript, actionWorkingBlock, localTrigerObjectName, callBackFunction, localVariables, stageID, windowID, panelID, pageID)
{
	if(Object.isString(theScript))
	{
		theScript = eval('(' + theScript + ')');
	}
	var TEScriptMain = new actionScript(actionGUID, theScript, localVariables, stageID, windowID, panelID, pageID);
	TEScriptMain.callAction(actionWorkingBlock, localTrigerObjectName, callBackFunction, localVariables);
};
var GetAllTEScripts = function(script, actionList) {
	actionList.set(script.name, script);
	script.tasks.each(function(task) {
		if(task != null)
		{
			GetAllTEScriptsProcessIFBlock(task, actionList);
		}
	});
};
var GetAllTEScriptsProcessIFBlock = function(IFBlock, actionList) {
	if(IFBlock.taskList == null) return;
	if(!Object.isArray(IFBlock.taskList))
	{
		IFBlock.taskList = [IFBlock.taskList];
	}
	IFBlock.taskList.each(function(taskList) {
		taskList.tasks.each(function(task) {
			if(task.type == "action")
			{
				GetAllTEScripts(task, actionList);
			}
			else if(task.type == "IF")
			{
				if(task != null)
				{
					GetAllTEScriptsProcessIFBlock(task, actionList);
				}
			}
		});
	});
};
var TEScriptStackBase = Class.create({
	initialize: function(parentAction, actionWorkingBlock, localTrigerObjectName, defaultParameterList) {
		//Action Run Identification
		this.ID = ++actionRunID;
		//This Action Object
		this.thisObject = parentAction;
		//The stage this action is running with in
		this.stageID = parentAction.parentStageID;
		//The window this action is running with in
		this.windowID = parentAction.parentWindowID;
		//The panel this action is running with in
		this.panelID = parentAction.parentPanelID;
		//The working block this action is running with in
		this.workingBlock = actionWorkingBlock;
		//The object which called this action
		this.trigerObject = localTrigerObjectName;
		//The hash array of return values from actions with in this call
		this.actionResults = $H();
		this.sharedActionResults = $H();
		this.defaultParameterList = defaultParameterList;
		//The main return value of the action
		this.actionReturnValue = "true";
		this.callBackActionScriptStack = [];
		this.callBackVariableStack = [];
		this.callBackFunctionStack = [];
		this.callBackIDFlagStack = [];
		this.actionScript = null;
		this.localVariables = {};
		actionStackHolder.set(this.ID, this);
	},
	pushAndCall : function(callFunction, callVariables, callScript, callBackFunction, flag) {
		try
		{
			this.callBackActionScriptStack.push(this.actionScript);
			this.callBackVariableStack.push(this.localVariables);
			this.callBackFunctionStack.push(callBackFunction);
			this.callBackIDFlagStack.push(flag);
			if(callScript != null)
				this.actionScript = callScript;
			if(callVariables != null)
				this.localVariables = callVariables;
			if(callFunction != null)
					setTimeout(callFunction, 1);
		}
		catch(e)
		{
			 alert('Action call error');
		}
	},
	push : function(callVariables, callScript, callBackFunction, flag) {
		this.callBackActionScriptStack.push(this.actionScript);
		this.callBackVariableStack.push(this.localVariables);
		this.callBackFunctionStack.push(callBackFunction);
		this.callBackIDFlagStack.push(flag);
		if(callScript != null)
			this.actionScript = callScript;
		if(callVariables != null)
			this.localVariables = callVariables;
	},
	popAndCall : function() {
		try
		{
			this.actionScript = this.callBackActionScriptStack.pop();
			this.localVariables = this.callBackVariableStack.pop();
			var callbackFunction = this.callBackFunctionStack.pop();
			var popedFlag = this.callBackIDFlagStack.pop();
			if(callbackFunction != null)
					setTimeout(callbackFunction, 1);
			if(popedFlag == "DoublePOP")
				this.popAndCall();
		}
		catch(e)
		{
			 alert('Action call error');
		}
	},
	popToAndCall : function(flag) {
		try
		{
			var popedFlag = null;
			var callbackFunction = null;
			do{
				this.actionScript = this.callBackActionScriptStack.pop();
				this.localVariables = this.callBackVariableStack.pop();
				callbackFunction = this.callBackFunctionStack.pop();
				popedFlag = this.callBackIDFlagStack.pop();
				if("DoublePOP" == popedFlag)
						setTimeout(callbackFunction, 1);
			} while( flag != popedFlag && this.callBackActionScriptStack.length > 0)
			if(callbackFunction != null)
					setTimeout(callbackFunction, 1);
		}
		catch(e)
		{
			alert('Action callback error');
		}
	},
	exitAction : function () {
		try
		{
			var callbackFunction = null;
			var popedFlag = null;
			do{
				this.actionScript = this.callBackActionScriptStack.pop();
				this.localVariables = this.callBackVariableStack.pop();
				callbackFunction = this.callBackFunctionStack.pop();
				popedFlag = this.callBackIDFlagStack.pop();
				if("DoublePOP" == popedFlag)
				{
					setTimeout(callbackFunction, 1);
				}
			} while(this.callBackActionScriptStack.length > 0)
			if(callbackFunction != null)
				setTimeout(callbackFunction, 1);
		}
		catch(e)
		{
			 alert('Action call error');
		}
	},
	getStackCallBackText : function () {
		return "actionStackHolder.get(" + this.ID + ")";
	},
	remove : function() {
		//Note: the action script frame work is designed to run the same script in parallel, thuse a counter must be used here and not a boolean
		this.thisObject.isRunning++;
		actionStackHolder.unset(this.ID);
	}
});
var actionScript = Class.create(basePageElement,{
	initialize: function($super, actionID, script, defaultParameterList, StageID, WindowID, PanelID, PageID, consoled, sharedActionResults) {
		$super(actionID, "TEScript");
		this.scriptHead = script;
		this.scriptActionMap = $H();
		GetAllTEScripts(script, this.scriptActionMap);
		this.parentStageID = StageID;
		this.parentWindowID = WindowID;
		this.parentPanelID = PanelID;
		this.parentPageID = PageID;
		this.workingBlock = "";
		//Note: the action script frame work is designed to run the same script in parallel, thuse a counter must be used here and not a boolean
		this.isRunning = 0;
		
		if(defaultParameterList != null)
			this.defaultParameterList = defaultParameterList;
		else
			this.defaultParameterList = $H();
		if(sharedActionResults != null)
		{
			this.sharedActionResults = sharedActionResults;
		}
		else
		{
			this.sharedActionResults = $H();
		}
		this.defaultParameterList.set("CALLING_STAGE", this.parentStageID);
		this.defaultParameterList.set("CALLING_WINDOW", this.parentWindowID);
		this.defaultParameterList.set("CALLING_PANEL", this.parentPanelID);
		this.defaultParameterList.set("CALLING_PAGE", this.parentPageID);
		this.consoled = consoled;
		if(this.parentStageID != "" && this.parentWindowID != "" && this.parentPanelID != "" && this.parentStageID != null && this.parentWindowID != null && this.parentPanelID != null)
			getPanel(this.parentStageID,this.parentWindowID,this.parentPanelID).registerNestedObject(this.elementUniqueID, this);
	},
	callAction: function(actionWorkingBlock, localTrigerObjectName, callBackFunction, localVariables) {
		//Note: the action script frame work is designed to run the same script in parallel, thuse a counter must be used here and not a boolean
		this.isRunning++;
	
		var localStack = new TEScriptStackBase(this, actionWorkingBlock, localTrigerObjectName, this.defaultParameterList);
		if(Object.isHash(actionWorkingBlock))
		{
				actionWorkingBlock.each(function(pair) {
					localStack.defaultParameterList.set(pair.key, pair.value);
				});
		}
		localStack.localVariables = localVariables;
		if(callBackFunction == null)
			callBackFunction = "";
		if(callBackFunction != "")
			callBackFunction = callBackFunction + "(" + localStack.getStackCallBackText() + ");";
		localStack.push({}, this.scriptHead, callBackFunction +localStack.getStackCallBackText() + ".remove()");
		if(localStack.actionScript.lockScreen)
		{
			if(LOCK_SCREEN())
				localStack.push(null, null, "UNLOCK_SCREEN()", "DoublePOP");
		}
		localStack.pushAndCall(this.callBackText + ".processParameters(" + localStack.getStackCallBackText() + ", 0)", null, null, this.callBackText + ".executeTEScript(" + localStack.getStackCallBackText() + ")" , "acton");
	},
	destroy: function($super) {
		if(this.isRunning <= 0)
			$super();
		else
		{
			try{
				setTimeout(this.callBackText + ".destroy()", 100);
			} catch(e) {
				$super();
			}
		}
	},
	executeTEScript: function(localStack) {
		localStack.localVariables.result = {
					returnCode: 'true',
					returnValue : ""
			};
		switch(localStack.actionScript.actionType.toUpperCase()) {
			case "SERVERACTION":
					this.raiseAction(localStack);
				break;
			case "ALERT" :
					this.raiseAlert(localStack);
				break;
			case "DIALOG" :
					this.raiseDialog(localStack);
				break;
			case "PROMPT":
					this.raisePrompt(localStack);
				break;
			case "CONFIRM" :
					this.raiseConfirmation(localStack);
				break;
			case "FORM" :
					this.raiseForm(localStack);
				break;
			case "FILEDIALOG" :
					this.raiseFileDialog(localStack);
				break;
			default:
				this.executeFollowOnActions(localStack, 0, 0, 0);
		}
	},
	executeFollowOnActions: function(localStack, currentTask, taskListPos, taskPos)
	{
		if(localStack.actionScript.tasks != null)
		{
			var tasks = localStack.actionScript.tasks;
			var numberOfTasks = tasks.length;
			for(0; currentTask < numberOfTasks; currentTask++)
			{
				if(tasks[currentTask].type == "task")
				{
					localStack.pushAndCall(localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'localStack.actionScript.tasks'," + currentTask + " , 0, 0)", null, null,
															localStack.thisObject.callBackText + ".executeFollowOnActions(" + localStack.getStackCallBackText() + ", " + (currentTask+1) + ")", "controlGroup");
					return;
				}
				else if(tasks[currentTask].type == "IF")
				{
					var followOnAction = tasks[currentTask];
					if(this.ifEvalProcessor(localStack, followOnAction))
					{
						localStack.pushAndCall(localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'localStack.actionScript.tasks'," + currentTask + " , 0, 0)", null, null,
															localStack.thisObject.callBackText + ".executeFollowOnActions(" + localStack.getStackCallBackText() + ", " + (currentTask+1) + ")", "controlGroup");
						return;
					}
				}
			}
		}
		localStack.popAndCall();
	},
	ifEvalProcessor: function(localStack, followOnAction)
	{
		var resultEval = false;
		var task = null;
		var resultTocompareTo = localStack.localVariables.result.returnCode;
		var valueTocompareFrom = followOnAction.condition;
		if(followOnAction.compareOn != "")
		{
			followOnAction.compareOnType = followOnAction.compareOnType != "" ? followOnAction.compareOnType : "RETURNOBJECT";
			task = {
				parameterType : followOnAction.compareOnType,
				value : followOnAction.compareOn,
				defalutValue : ""
			};
			resultTocompareTo = localStack.thisObject.retrieveParameter(task, localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults);
		}
		if(followOnAction.conditionType != "")
		{
			task = {
				parameterType : followOnAction.conditionType,
				value : followOnAction.condition,
				defalutValue : ""
			};
			valueTocompareFrom = localStack.thisObject.retrieveParameter(task, localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults);
		}
		var compareWith = followOnAction.conditionCompareType == "" ? "regex" : followOnAction.conditionCompareType.toLowerCase();
		switch(compareWith)
		{
			case "istr":
				valueTocompareFrom = valueTocompareFrom.toLowerCase();
				resultTocompareTo = resultTocompareTo.toLowerCase();
			case "str":
				try
				{
					if(valueTocompareFrom == resultTocompareTo)
					{
						resultEval = true;
					}
					else
					{
						resultEval = false;
					}
				}
				catch(e)
				{
					alert("An error has occured:" + e);
					localStack.exitAction();
				}
				break;
			case "regex":
			default:
				try
				{
					resultEval = String(resultTocompareTo).match(new RegExp(valueTocompareFrom, ""));
				}
				catch(e)
				{
					alert("An error has occured:" + e);
					localStack.exitAction();
				}
				resultEval = resultEval == null ? false : true;
				break;
		}
		return followOnAction.negCondition ? !resultEval : resultEval;
	},
	taskProcessor: function(localStack, taskListLocation, taskListActionPos, taskListPos, taskPos) {
		var taskListArray = eval(taskListLocation + "[" + taskListActionPos + "].taskList;");
		var runAction = null;
		if(!Object.isArray(taskListArrayLength))
		{
			taskListArrayLength = [taskListArrayLength];
		}
		var taskListArrayLength = taskListArray.length;
		for(0;taskListPos < taskListArrayLength; taskListPos++)
		{
			taskList = taskListArray[taskListPos];
			var taskArray = taskList.tasks;
			var taskArrayLength = taskArray.length;
			for(0;taskPos < taskArrayLength; taskPos++)
			{
				try
				{
					var task = taskArray[taskPos];
					switch(task.type.toLowerCase()) {
						case "if" :
							if(this.ifEvalProcessor(localStack, task))
							{
								localStack.pushAndCall(localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + taskListLocation + "[" + taskListActionPos + "].taskList[" + taskListPos + "].tasks'," + taskPos + " , 0, 0)", null, null,
																	localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + taskListLocation + "'," + taskListActionPos +"," + taskListPos + "," + (taskPos+1) + ")", "taskGroup");
								return;
							}
							break;
						case "action":
							try {
									localStack.push({}, task, localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + taskListLocation + "'," + taskListActionPos +"," + taskListPos + "," + (taskPos+1) + ")", "action");
									if(localStack.actionScript.lockScreen)
									{
										if(LOCK_SCREEN())
											localStack.push(null, null, "UNLOCK_SCREEN()" , "DoublePOP");
									}
									localStack.pushAndCall(localStack.thisObject.callBackText + ".processParameters(" + localStack.getStackCallBackText() + ", 0)", null, null, localStack.thisObject.callBackText + ".executeTEScript(" + localStack.getStackCallBackText() + ")", "actonHead" );
							}
							catch(e)
							{
								alert(e);
							}
							return;
							break;
						case "alert" :
							var message = encodeMessage(task.message, localStack.localVariables.parameters);
							alert(message);
							break;
						case "echo" :
							if(this.consoled != null)
								if($(this.consoled) != null)
									$(this.consoled).insert(encodeMessage(task.message, localStack.localVariables.parameters) + "\n");
							break;
						case "setglobal" :
						case "assignsharedconstant" :
							localStack.localVariables.parameters.set(task.name, localStack.thisObject.retrieveParameter(task, localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults));
							localStack.defaultParameterList.set(task.name, localStack.localVariables.parameters.get(task.name));
							if(task.check != null)
							{
								localStack.pushAndCall(localStack.thisObject.callBackText + ".parameterCheck(" + localStack.getStackCallBackText() + ", '" + taskListLocation + "[" + taskListActionPos + "].taskList[" + taskListPos + "].tasks'," + taskPos + ", 0)", null, null,
													localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + taskListLocation + "'," + taskListActionPos +"," + taskListPos + "," + (taskPos+1) + ")", "taskGroup");
								return;
							}
							break;
						case "setlocal" :
						case "assignlocalparameter" :
							localStack.localVariables.parameters.set(task.name, localStack.thisObject.retrieveParameter(task, localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults));
							if(task.check != null)
							{
								localStack.pushAndCall(localStack.thisObject.callBackText + ".parameterCheck(" + localStack.getStackCallBackText() + ", '" + taskListLocation + "[" + taskListActionPos + "].taskList[" + taskListPos + "].tasks'," + taskPos + ", 0)", null, null,
													localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + taskListLocation + "'," + taskListActionPos +"," + taskListPos + "," + (taskPos+1) + ")", "taskGroup");
								return;
							}
							break;
						case "loadpage" :
							var pageLayouts = cloneObject(task.pageLayouts);
							var links = cloneObject(task.links);
							loadDecodedPage(encodeObject(pageLayouts, localStack.localVariables.parameters), encodeObject(links, localStack.localVariables.parameters));
							break;
						case "gotoaction" :
						case "callaction" :
							runAction = localStack.thisObject.scriptActionMap.get(task.name);
							if(runAction != null)
							{
								try {
										localStack.push({}, runAction, localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + taskListLocation + "'," + taskListActionPos +"," + taskListPos + "," + (taskPos+1) + ")", "action");
										if(localStack.actionScript.lockScreen)
										{
											if(LOCK_SCREEN())
												localStack.push(null, null, "UNLOCK_SCREEN()" , "DoublePOP");
										}
										localStack.pushAndCall(localStack.thisObject.callBackText + ".processParameters(" + localStack.getStackCallBackText() + ", 0)", null, null, localStack.thisObject.callBackText + ".executeTEScript(" + localStack.getStackCallBackText() + ")", "actonHead" );
								}
								catch(e)
								{
									alert(e);
								}
								return;
							}
							break;
						case "callglobalaction" :
							runAction = GLOBAL_TE_SCRIPT_STORE.get(task.name);
							GetAllTEScripts(runAction, localStack.thisObject.scriptActionMap);
							if(runAction != null)
							{
								try {
										localStack.push({}, runAction, localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + taskListLocation + "'," + taskListActionPos +"," + taskListPos + "," + (taskPos+1) + ")", "action");
										if(runAction.lockScreen)
										{
											if(LOCK_SCREEN())
												localStack.push(null, null, "UNLOCK_SCREEN()" , "DoublePOP");
										}
										localStack.pushAndCall(localStack.thisObject.callBackText + ".processParameters(" + localStack.getStackCallBackText() + ", 0)", null, null, localStack.thisObject.callBackText + ".executeTEScript(" + localStack.getStackCallBackText() + ")", "actonHead" );
								}
								catch(e)
								{
									alert(e);
								}
								return;
							}
							break;
						case "panelreload" :
							var panel = getPanel(localStack.stageID,localStack.windowID,localStack.panelID);
							if(panel != null)
							{
								if(task.name == "")
								{
									localStack.exitAction();
									panel.reloadPage();
									return;
								}
								else
								{
									panel = getPanel(localStack.stageID,localStack.windowID,task.name);
									if(panel != null)
									{
										if(task.name == localStack.panelID)
											localStack.exitAction();
										panel.reloadPage();
										if(task.name == localStack.panelID)
											return;
										break;
									}
									else
									{
										alert("Panel '" + task.name + "' not found to refresh");
									}
								}
							}
							else
							{
								alert("Panel '" + localStack.panelID + "' not found to refresh");
							}
							break;
						case "windowreload" :
							var window = getWindow(localStack.stageID,localStack.windowID);
							if(window != null)
							{
								localStack.exitAction();
								window.reloadPage();
								return;
							}
							else
							{
								alert("Window '" + localStack.windowID + "' in stage '" + localStack.stageID + "' not found");
							}
							break;
						case "blockupdate" :
							var blockHash = $H(localStack.localVariables.result.returnValue);
							blockHash.each(function(blockValues) {
								if($(localStack.workingBlock + "_" + blockValues.key) != null)
								{
									try
									{
										$F(localStack.workingBlock + "_" + blockValues.key);
										$(localStack.workingBlock + "_" + blockValues.key).value = unescape(blockValues.value);
									}
									catch(err)
									{
										$(localStack.workingBlock + "_" + blockValues.key).update(unescape(blockValues.value));
									}
								}
							});
							break;
						case "setactionreturn" :
							localStack.actionReturnValue = localStack.thisObject.retrieveParameter(task, localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults);
							//localStack.actionReturnValue = encodeMessage(task.value, localStack.localVariables.parameters);
							break;
						case "break" :
							localStack.popAndCall();
							return;
							break;
						case "breakcheck" :
							localStack.popToAndCall("check");
							return;
							break;
						case "breakcontrolgroup" :
							localStack.popToAndCall("controlGroup");
							return;
							break;
						case "return" :
							localStack.popToAndCall("action");
							return;
							break;
						case "exit" :
							localStack.exitAction();
							return;
							break;
						case "unlockscreen" :
							UNLOCK_SCREEN();
							break;
						case "lockscreen" :
							LOCK_SCREEN();
							break;
						case "opencontextmenu":
							var menu = encodeMessage(task.baseDir, localStack.localVariables.parameters);
							//createContextMenuOnPanelObject("ActionMenu_" + getGUID(), menu, null, null);
							CORE_GENERAL_CONTEXT_MENU.callBackNode = menu;
							CORE_GENERAL_CONTEXT_MENU.getMenu(true);
							break;
						case "getconnection":
							var connectionName = localStack.thisObject.retrieveParameter(task, localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults);
							if(connectionName == "" || connectionName == null || connectionName == "null" || connectionName == "NULL")
							{
								localStack.localVariables.parameters.set(task.name, getActiveDatabaseConnectionObject());
							}
							else
							{
								localStack.localVariables.parameters.set(task.name, getConnectionObjectWithTag(connectionName));
							}
							break;
					}
				}
				catch(e)
				{
					alert("Error in actions:" + e);
				}
			}
			taskPos = 0;
		}
		taskListPos = 0;
		localStack.popAndCall();
	},
	raiseAction: function(localStack) {
		var parameters = localStack.localVariables.parameters;
		var returnObject = {
			returnCode: "ERROR",
			returnValue : ""
		};
		parameters.set("returntype", "JSON");
		
		if(parameters.get('USE_CONNECTION') == null)
		{
			if(parameters.get('useConnectWithTag') != null)
			{
				parameters.set('USE_CONNECTION', getConnectionWithTag(parameters.get('useConnectWithTag')));
			}
			if(parameters.get('USE_CONNECTION') == null)
			{
				parameters.set('USE_CONNECTION', getActiveDatabaseConnection());
			}
		}
		
		new Ajax.Request("./" + GLOBAL_CONSTANTS.get("ACTION_PROCESSOR"), {
			'parameters': parameters,
			'method': 'post',
			'onSuccess': function(transport) {
					localStack.localVariables.result = transport.responseJSON;
					if(localStack.localVariables.result == null)
					{
						alert("An invalid JavaScript object was returned, can not complete action execution. ");
						localStack.actionReturnValue = false;
						localStack.exitAction();
						return;
					}
					if(localStack.localVariables.result.flagGeneralError == true && localStack.localVariables.result.connectionError == true)
					{
						initiateConnectionRefresh();
					}
					if(localStack.localVariables.result.flagGeneralError == true)// && localStack.actionScript.suppressAutomaticErrors != true)
					{
						alert(unescape(localStack.localVariables.result.returnValue));
						localStack.actionReturnValue = false;
						localStack.exitAction();
						return;
					}
					localStack.localVariables.parameters.set("RETURN_CODE", localStack.localVariables.result.returnCode);
					localStack.localVariables.parameters.set("RETURN_VALUE", localStack.localVariables.result.returnValue);
					localStack.actionResults.set(localStack.actionScript.name,localStack.localVariables.result);
					localStack.thisObject.executeFollowOnActions(localStack, 0, 0, 0);
			},
			'onFailure': function(transport) {
						localStack.localVariables.result = {
															returnCode: "ERROR",
															returnValue : transport.status
														};
						localStack.actionResults.set(localStack.actionScript.name,localStack.localVariables.result);
						localStack.thisObject.executeFollowOnActions(localStack, 0, 0, 0);
			}
			});
	},
	raiseAlert: function(localStack) {
		var parameters = localStack.localVariables.parameters;
		var message = encodeMessage(localStack.actionScript.message, parameters);
		AllowAutoClosingOfFloatingObject = false;
		alert(message);
		localStack.localVariables.result = {
			returnCode: 'true',
			returnValue : ""
		};
		localStack.localVariables.parameters.set("RETURN_CODE", localStack.localVariables.result.returnCode);
		localStack.localVariables.parameters.set("RETURN_VALUE", localStack.localVariables.result.returnValue);
		localStack.actionResults.set(localStack.actionScript.name,localStack.localVariables.result);
		localStack.thisObject.executeFollowOnActions(localStack, 0, 0, 0);
	},
	raisePrompt: function(localStack) {
		var parameters = localStack.localVariables.parameters;
		var message = encodeMessage(localStack.actionScript.message, parameters);
		AllowAutoClosingOfFloatingObject = false;
		var promptReturn = prompt(message, parameters.get("PROMPT_DEFAULT"));
		var status = promptReturn == null ? 'false' : 'true';
		localStack.localVariables.result = {
			returnCode: status,
			returnValue : promptReturn
		};
		localStack.localVariables.parameters.set("RETURN_CODE", localStack.localVariables.result.returnCode);
		localStack.localVariables.parameters.set("RETURN_VALUE", localStack.localVariables.result.returnValue);
		localStack.actionResults.set(localStack.actionScript.name,localStack.localVariables.result);
		localStack.thisObject.executeFollowOnActions(localStack, 0, 0, 0);
	},
	raiseConfirmation: function(localStack) {
		var parameters = localStack.localVariables.parameters;
		var message = encodeMessage(localStack.actionScript.message, parameters);
		AllowAutoClosingOfFloatingObject = false;
		var result = confirm(message);
		var status = result ? 'true' : 'false';
		localStack.localVariables.result = {
			returnCode: status,
			returnValue : ""
		};
		localStack.localVariables.parameters.set("RETURN_CODE", localStack.localVariables.result.returnCode);
		localStack.localVariables.parameters.set("RETURN_VALUE", localStack.localVariables.result.returnValue);
		localStack.actionResults.set(localStack.actionScript.name,localStack.localVariables.result);
		localStack.thisObject.executeFollowOnActions(localStack, 0, 0, 0);
	},
	raiseDialog: function(localStack) {
		var parameters = localStack.localVariables.parameters;
		var parametersToSend = new Object();
		var type = "raw";
		var data = encodeMessage(localStack.actionScript.message, parameters);
		parameters.each(function(pair){
			parametersToSend[pair.key] = pair.value;
		});
		if(data == "")
		{
			type = "LINK";
			data = {
				type:'action',
				data: {
					parameters : parametersToSend
				}
			};
		}
		openModalDialog(data, type, localStack, parametersToSend);
	},
	raiseForm: function(localStack) {
		var parameters = localStack.localVariables.parameters;
		var parametersToSend = new Object();
		var type = "raw";
		var data = encodeMessage(localStack.actionScript.message, parameters);
		parameters.each(function(pair){
			parametersToSend[pair.key] = pair.value;
		});
		if(data == "")
		{
			type = "LINK";
			data = {
				type:'action',
				data: {
					parameters : parametersToSend
				}
			};
		}
		
		openModalForm(data, type, localStack, parametersToSend);
	},
	raiseFileDialog: function(localStack) {
		var parameters = localStack.localVariables.parameters;
		var parametersToSend = new Object();
		parameters.each(function(pair){
				parametersToSend[pair.key] = pair.value;
			});
		openModalFileDialog(localStack, parametersToSend);
	},
	processParameters: function(localStack, parameterPosition) {
		if(parameterPosition == 0 || parameterPosition == null)
		{
			localStack.localVariables.parameters = $H();
			localStack.defaultParameterList.each(function(pair) {
				localStack.localVariables.parameters.set(pair.key, pair.value);
			});
		}
		if(localStack.actionScript.parameterList == null || parameterPosition == null)
		{
			localStack.popAndCall();
			return;
		}
		var parameterListArrayLength = localStack.actionScript.parameterList.length;
		for(0; parameterPosition < parameterListArrayLength; parameterPosition++)
		{
			localStack.localVariables.parameters.set(localStack.actionScript.parameterList[parameterPosition].name, this.retrieveParameter(localStack.actionScript.parameterList[parameterPosition], localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults));
			if(localStack.actionScript.parameterList[parameterPosition].check != null)
			{
				localStack.pushAndCall(localStack.thisObject.callBackText + ".parameterCheck(" + localStack.getStackCallBackText() + ", 'localStack.actionScript.parameterList'," + parameterPosition + ", 0)", null, null,
									localStack.thisObject.callBackText + ".processParameters(" + localStack.getStackCallBackText() + ", " + (parameterPosition+1) + ")", "check");
				return;
			}
		}
		localStack.popAndCall();
		return;
	},
	parameterCheck: function(localStack, parameterArrayLocation,parameterPosition, checkPosition) {
		var parameterLocation = null;
		try {
			parameterLocation = eval(parameterArrayLocation + "[" + parameterPosition + "];");
		}
		catch(e){}
		if(parameterLocation == null)
		{
			localStack.popAndCall();
			return;
		}
		if(parameterLocation.check != null)
		{
			var checkParameterArray = parameterLocation.check;
			var checkParameterArrayLength = checkParameterArray.length;
			for(0; checkPosition < checkParameterArrayLength; checkPosition++)
			{
				var resultEval = false;
				var checkParameter = checkParameterArray[checkPosition];
				var resultTocompareTo = localStack.localVariables.parameters.get(parameterLocation.name);
				var valueTocompareFrom = checkParameter.condition;
				if(checkParameter.conditionType != "")
				{
					var task = {
						parameterType : checkParameter.conditionType,
						value : checkParameter.condition,
						defalutValue : ""
					};
					valueTocompareFrom = localStack.thisObject.retrieveParameter(task, localStack.workingBlock, localStack.localVariables.parameters, localStack.actionResults);
				}
				var compareWith = checkParameter.conditionCompareType == "" ? "regex" : checkParameter.conditionCompareType.toLowerCase();
				switch(compareWith)
				{
					case "regex":
						try
						{
							regex = new RegExp(valueTocompareFrom);
							resultEval = String(resultTocompareTo).match(regex);
						}
						catch(e)
						{
							alert("An error has occured:" + e);
							localStack.exitAction();
						}
						resultEval = resultEval == null ? false : true;
						break;
					case "istr":
						valueTocompareFrom = valueTocompareFrom.toLowerCase();
						resultTocompareTo = resultTocompareTo.toLowerCase();
					case "str":
						if(valueTocompareFrom == resultTocompareTo)
						{
							resultEval = true;
						}
						else
						{
							resultEval = false;
						}
						break;
				}
				resultEval = checkParameter.negCondition ? !resultEval : resultEval;
				if(resultEval)
				{
					localStack.pushAndCall(localStack.thisObject.callBackText + ".taskProcessor(" + localStack.getStackCallBackText() + ",'" + parameterArrayLocation + "[" + parameterPosition + "].check'," + checkPosition + " , 0, 0)", null, null,
														localStack.thisObject.callBackText + ".parameterCheck(" + localStack.getStackCallBackText() + ",'" + parameterLocation + "'," + parameterPosition + "," + (checkPosition+1) + ")", "controlGroup");
					return;
				}
			}
		}
		localStack.popAndCall();
	},
	retrieveParameter: function(aParameter, workingBlock, parameters, executedActions) {
		var value = "";
		switch(aParameter.parameterType.toUpperCase()) {
			case "RETURNOBJECT" :
				value = aParameter.defalutValue;
				var objectArray = aParameter.value.split(".");
				objectArray = objectArray.reverse();
				var actionName = objectArray.pop();
				var actionResultNode = executedActions.get(actionName);
				if(actionResultNode == null)
				{
						actionResultNode = this.sharedActionResults.get(this.parentPageID + "_" + actionName);
				}
				if(actionResultNode != null)
				{
					try
					{
						while(actionName = objectArray.pop())
						{
							actionResultNode = actionResultNode[actionName];
						}
						value = actionResultNode;
					}
					catch(e)
					{
					}
				}
				break;
			case "BLOCKVALUE" :
				value = aParameter.defalutValue;
				if(Object.isString(workingBlock))
				{
					try
					{
						value = $F(workingBlock + "_" + aParameter.value);
					}
					catch(err)
					{
						if($(workingBlock + "_" + aParameter.value) != null)
							value = $(workingBlock + "_" + aParameter.value).innerHTML;
					}
				}
				else if(workingBlock != null)
				{
					var blockValue = workingBlock.get(aParameter.value.toUpperCase());
					if(blockValue != null)
						value = blockValue;
				}
				break;
			case "PARAM" :
			case "PARAMETER" :
			case "CONSTANT" :
				value = GLOBAL_CONSTANTS.get(aParameter.value);
				if(value == null)
				{
					value = parameters.get(aParameter.value);
					if(value == null)
					{
						var objectArray = aParameter.value.split(".");
						objectArray = objectArray.reverse();
						var objectName = objectArray.pop();
						value = GLOBAL_CONSTANTS.get(objectName);
						if(value == null)
						{
							value = parameters.get(objectName);
							if(value == null)
							{
								value = aParameter.defalutValue;
								break;
							}
						}
						while(objectName = objectArray.pop())
						{
							value = value[objectName];
						}
					}
				}
				break;
			case "FIXED" :
				value = encodeMessage(aParameter.value, parameters);
				break;
			default :
				value = aParameter.value;
		}
		return value;
	}
});
