/*******************************************************************************
 * Author: Matthew Vandenbussche
 * 
 *Copyright IBM Corp. 2010 All rights reserved.
 *
 *Licensed under the Apache License, Version 2.0 (the "License");
 *you may not use this file except in compliance with the License.
 *You may obtain a copy of the License at
 *
 *	http://www.apache.org/licenses/LICENSE-2.0
 *
 *Unless required by applicable law or agreed to in writing, software
 *distributed under the License is distributed on an "AS IS" BASIS,
 *WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *See the License for the specific language governing permissions and
 *limitations under the License.
 *********************************************************************************/
var GLOBAL_OBJECT_HOLDER = {};

var GLOBAL_TYPE_LIBRARY = {};

var GET_GLOBAL_OBJECT = function(TYPE, ID) {
		if(!Object.isString(TYPE)) return null;
		if(GLOBAL_TYPE_LIBRARY[TYPE.toUpperCase()] == null) return null;
		return GLOBAL_OBJECT_HOLDER[GLOBAL_TYPE_LIBRARY[TYPE.toUpperCase()]].get(ID);
};
var GET_GLOBAL_OBJECT_CLASS = function(TYPE) {
		if(!Object.isString(TYPE)) return null;
		return GLOBAL_OBJECT_HOLDER[GLOBAL_TYPE_LIBRARY[TYPE.toUpperCase()]];
};

/*** added: Peter Prib - Copyright Frygma Pty Ltd (ABN 90 791 388 622 2009)  2010 All rights reserved.*/
var ALL_GLOBAL_OBJECT = function(aFunction, args , elementType) {
	var results =[];
	if (elementType==undefined) return results;
	if (elementType==null) return results;
	var objects = GET_GLOBAL_OBJECT_CLASS(elementType);
	if (objects == null) return results;
	for (var i in objects._object) {
		var aObject=objects._object[i];
		results.push(eval("aObject."+aFunction+".apply(aObject,args)")); 
	}
	return results;
};
/*** end added ***/

var basePageElement = Class.create({
	initialize: function(myID, myType, enableAccessByName) {
		//As the object is not always uniquely identified we create and internal Global unique identifier for the object 
		this.theObjectIsDead = false;
		this.GUID = getGUID();
		this.enableAccessByName = enableAccessByName != null ? enableAccessByName : false;
		
		this.elementParent = null;
		
		/*********************************************
		 * All object within the TE should have a Unique ID.
		 * The id is usually constructed in the following manner:
		 * <Stage Name>_<Window Name>_<Panel Name>_<Action Name>_<Component Description>
         * Note that the Component description may appear at the beginning or end of the ID
         * for legacy reasons all new code should have the component Description on the end a
         ********************************************/
		this.elementName = myID;
		this.elementType = this.elementType == null ? myType : this.elementType;
		this.elementType = this.elementType.toUpperCase();
		
		this.elementUniqueID = myID;
		
		this.parentStageID = "";
		this.parentWindowID = "";
		this.width = 0;
		this.height = 0;
		this.minWidth= this.minWidth == null ? 200 : this.minWidth;
		this.minHeight= this.minHeight == null ? 10 : this.minHeight;
		
		if(GLOBAL_TYPE_LIBRARY[this.elementType] == null) GLOBAL_TYPE_LIBRARY[this.elementType] = getGUID();

		this.elementTypeID = GLOBAL_TYPE_LIBRARY[this.elementType];

		if(GLOBAL_OBJECT_HOLDER[this.elementTypeID] == null) GLOBAL_OBJECT_HOLDER[this.elementTypeID] = $H();
		
		GLOBAL_OBJECT_HOLDER[this.elementTypeID].set(this.GUID, this);
		if(this.enableAccessByName)
		{
			if(GLOBAL_OBJECT_HOLDER[this.elementTypeID].get(this.elementUniqueID) != null)
			{
				alert(encodeMessage(CORE_MESSAGE_STORE.LANGUAGE_MESSAGES.OBJECT_EXISTS, {OBJECT_TYPE:this.elementTypeID, OBJECT_ID:this.elementUniqueID}));	
			}
			GLOBAL_OBJECT_HOLDER[this.elementTypeID].set(this.elementUniqueID, this);
		}
		
		this.callBackText = "GLOBAL_OBJECT_HOLDER[" + this.elementTypeID + "].get(" + this.GUID + ")";
	},
	
	getAllObjectsInGroup : function() {
		return GLOBAL_OBJECT_HOLDER[this.elementType];
	},
	
	autoReloadUpdate: function() {
		//Treat as abstract function
	},
	reloadPage: function() {
	//Treat as abstract function
	},
	resizeStart: function() {
		//Treat as abstract function
	},
	resizeEnd: function() {
		//Treat as abstract function
	},
	sizeWidth: function(Amount) {
		//Treat as abstract function
	},
	sizeHeight: function(Amount) {
		//Treat as abstract function
	},
	setSize: function(width, height) {
		this.setWidth(width == null ? this.width : width);
		this.setHeight(height == null ? this.height : height);
	},
	setWidth: function(Amount) {
		//Treat as abstract function
	},
	setHeight: function(Amount) {
		//Treat as abstract function
	},
	moveLeft: function(Amount) {
		//Treat as abstract function
	},
	moveTop: function(Amount) {
		//Treat as abstract function
	},
	destroy: function() {
		this.theObjectIsDead = true;
		if(this.enableAccessByName)
		{
			var object = GLOBAL_OBJECT_HOLDER[this.elementTypeID].get(this.elementUniqueID);
			if(object != null)
			{
				if(object.GUID == this.GUID)
					 GLOBAL_OBJECT_HOLDER[this.elementTypeID].unset(this.elementUniqueID);
			}
		}
		GLOBAL_OBJECT_HOLDER[this.elementTypeID].unset(this.GUID);
		this.myParent = null;
	},
	draw: function() {
		return "";
	},
	redraw: function() {
		this.draw();
	},
	sizeToChild: function(childsName) {
		return null;
	}
});