
CORE_MESSAGE_STORE.LANGUAGE_GRAPH_YUI_MESSAGES = {
	
	ERROR_PARSING_OBJECT : "Error: Graph YUI was unable to parse the graph object",
	
	ERROR_NO_DEFF: "Error: No table or graph definition was received." 

};
