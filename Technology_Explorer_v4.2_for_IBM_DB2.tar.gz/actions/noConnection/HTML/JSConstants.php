<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/

?>

var GLOBAL_CONSTANTS = $H();
var DB2MC_SERVER = location.href.substr(0, location.href.lastIndexOf('/')); 
GLOBAL_CONSTANTS.set("DB2MC_SERVER", DB2MC_SERVER.replace("http://", ""));
<?php
writeJSConstant(
		array(
			'DMC_IS_PUBLICLY_HOSTED',
			'FORCE_CONNECTION_WITH_DEFAULT',
			'HTML_BASE_DIRECTORY',
			'IMAGE_BASE_DIRECTORY',
			'ACTION_PROCESSOR',
			'MENU_PROCESSOR',
			'TUTORIAL_BASE_DIRECTORY',
			'CONNECTION_VERIFIER',
			'DEFAULT_FLOATING_WINDOW_HEIGHT',
			'DEFAULT_FLOATING_WINDOW_WIDTH',
			'CONNECTED',
			'DISCONNECTED',
			'IE_SPEED_EXTENSION',
			'SHOW_IE_PERFORMANCE_WARNING',
			'JAVA_SQL_ENABLED',
			'SSH2_ENABLED',
			'AD_HOC_DISPLAY_XML',
			'AD_HOC_DISPLAY_XML_AS_INLINE',
			'AD_HOC_DISPLAY_CLOB',
			'AD_HOC_DISPLAY_CLOB_AS_INLINE',
			'AD_HOC_DISPLAY_BLOB',
			'AD_HOC_DISPLAY_DBCLOB',
			'AD_HOC_TERMINATION_CHAR',
			'AD_HOC_USER_FORWARD_ONLY_CURSOR',
			'AD_HOC_COMMIT_PER_STMT',
			'AD_HOC_NUMBER_OF_ROWS_TO_RETURN',
			'AD_HOC_MAX_EXECUTION_TIME',
			'SHELL_COMMAND_MAX_RUN_TIME',
			'SHELL_COMMAND_TERM_CHAR',
			'AD_HOC_SCRIPT_MODE',
			'DEFAULT_ICON_WIDTH',
			'LONG_FIELD_MAX',
			'ENABLE_VIEW_QUERY',
			'ALLOW_DISPLAY_OF_XML',
			'ALLOW_DEVELOPER_VIEW',
			'ENABLE_VERBOSE',
			'MAJOR_VERSION',
			'MINOR_VERSION',
			'SUB_VERSION'
		)
	);
@define("INDEX_LOAD", true);
$TableDefinitionObjectsDirectory = dir(USER_PREFERENCES_DIRECTORY); 
$includeFile = "";
while(($includeFile = $TableDefinitionObjectsDirectory->read()) !== false) 
{ 
	 if (preg_match("/^config_.+\\.php$/", $includeFile))
	  	 include_once(USER_PREFERENCES_DIRECTORY . $includeFile);
} 
	
$TableDefinitionObjectsDirectory = dir("./"); 
$includeFile = "";
while(($includeFile = $TableDefinitionObjectsDirectory->read()) !== false) 
{
	if (preg_match('/^config_(.)+\.php$/', $includeFile) >= 1)
	  	 include_once("./" . $includeFile);
}
?>

var CONNECTED_DATABASE = null; 
GLOBAL_CONSTANTS.set("CONNECTED_DATABASE", null);
var CONNECTED_DATABASE_VERSION = null; 
GLOBAL_CONSTANTS.set("CONNECTED_DATABASE_VERSION", null);