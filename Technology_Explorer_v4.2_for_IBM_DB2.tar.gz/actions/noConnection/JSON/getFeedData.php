<?php

include_once(PHP_INCLUDE_BASE_DIRECTORY . "ArrayEncodeFeed.php");
include_once(PHP_INCLUDE_BASE_DIRECTORY . "ObjectFeedSourceManager.php");

$sourceList = feedSourceManager::retrieveAllSources();

ArrayEncodeFeed::$maxItemsToReturn = getParameter('returnCount', 10);

$FeedData = array();
$FeedData['returnCode'] = false;
$FeedData['returnValue'] = 'Could not retrieve data from sources.';

$FeedDataFromAllSources = array();
if($sourceList != null)
{
	foreach($sourceList as $source)
	{
		if($source != null)
		{
			$RawData = @file_get_contents($source['link']);
	
			if($RawData !== false)
			{
				$Feed = ArrayEncodeFeed::fromString($RawData);
				$Feed ['title'] = $source['title'];
				$FeedDataFromAllSources[] = $Feed;
			}
		}
	}

	if($FeedDataFromAllSources != null)
	{
		$FeedData['returnCode'] = true;
		$FeedData['returnValue'] = $FeedDataFromAllSources;
	}
}
		
echo json_encode($FeedData);