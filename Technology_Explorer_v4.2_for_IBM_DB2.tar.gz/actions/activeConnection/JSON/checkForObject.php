<?php
/*******************************************************************************
 *  Copyright IBM Corp. 2007 All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *********************************************************************************/

/**
 * Use case: How to use this as an exitAction on a page
 	<exitAction name="checkForPostaltxsTable" type="serverAction">
 		<parameterList>
  		<parameter name="action" type="fixed">
				<value>checkForObject</value>
			</parameter>
			<parameter name="objectType" type="fixed">
				<value>table</value>
			</parameter>
			<parameter name="object[schema]" type="raw">
				<value>CHEUNGK</value>
			</parameter>
			<parameter name="object[table]" type="raw">
				<value>EMPLOYEE</value>
			</parameter>
		</parameterList>
  </exitAction>
 *
 */
$objectType = getParameter('objectType');
$object = getParameter('object');

$returnObject = array();

$returnObject['returnCode'] = "false";
$returnObject['returnObject'] = 0;

$query = false;

if($objectType == null || !is_array($object))
{
	echo json_encode($returnObject);
exit;
}

$objectType = strtolower($objectType);

switch($objectType)
{
	case "schema":
		if(isset($object["schema"]))
		{
			$schema = strtoupper($object["schema"]);
			$query = "SELECT count(*) FROM SYSCAT.SCHEMATA  WHERE SCHEMANAME = '$schema'";
		}
		break;
	case "table":
		if(isset($object["schema"]) && isset($object["table"]))
		{
			$schema = strtoupper($object["schema"]);
			$table = strtoupper($object["table"]);
			$query = "SELECT count(*) FROM SYSCAT.TABLES WHERE TABSCHEMA = '$schema' AND TABNAME = '$table'";
		}
		break;
	case "column":
		if(isset($object["schema"]) && isset($object["table"]) && isset($object["column"]))
		{
			
			$schema = strtoupper($object["schema"]);
			$table = strtoupper($object["table"]);
			$column = strtoupper($object["column"]);
			$query = "SELECT count(*) FROM SYSCAT.COLUMNS WHERE TABSCHEMA = '$schema' AND TABNAME = '$table' AND COLNAME = '$column'";
			if (isset($object["datatype"]) && isset($object["length"])) 
			{
				$datatype = strtoupper($object["datatype"]);
				$length = strtoupper($object["length"]);
				$query = "SELECT count(*) FROM SYSCAT.COLUMNS WHERE TABSCHEMA = '$schema' AND TABNAME = '$table' AND COLNAME = '$column' AND TYPENAME = '$datatype' AND LENGTH = $length";
			}
		}
		break;
	case "storedprocedure":
		if(isset($object["schema"]) && isset($object["storedprocedure"]))
		{
			$schema = strtoupper($object["schema"]);
			$storedprocedure = strtoupper($object["storedprocedure"]);
			$query = "SELECT count(*) FROM SYSCAT.PROCEDURES WHERE  PROCNAME = '$storedprocedure' AND PROCSCHEMA = '$schema'";		}
		break;
		case "index":	
		if(isset($object["schema"]) && isset($object["index"]))
		{	
			$schema = strtoupper($object["schema"]);
			$index = strtoupper($object["index"]);
			$query = "SELECT count(*) FROM SYSCAT.INDEXES WHERE INDSCHEMA = '$schema' AND INDNAME = '$index'";
		}
		break;
		case "trigger":	
		if(isset($object["schema"]) && isset($object["trigger"]))
		{	
			$schema = strtoupper($object["schema"]);
			$trigger = strtoupper($object["trigger"]);
			$query = "SELECT count(*) FROM SYSCAT.TRIGGERS WHERE TRIGSCHEMA = '$schema' AND TRIGNAME = '$trigger'";
		}
		break;
		case "view":	
		if(isset($object["schema"]) && isset($object["view"]))
		{	
			$schema = strtoupper($object["schema"]);
			$view = strtoupper($object["view"]);
			$query = "SELECT count(*) FROM SYSCAT.VIEWS WHERE VIEWSCHEMA = '$schema' AND VIEWNAME = '$view'";
		}
		break;
		case "sequence":	
		if(isset($object["schema"]) && isset($object["sequence"]))
		{	
			$schema = strtoupper($object["schema"]);
			$sequence = strtoupper($object["sequence"]);
			$query = "SELECT count(*) FROM SYSCAT.SEQUENCES WHERE SEQSCHEMA = '$schema' AND SEQNAME = '$sequence'";
		}
		break;
		case "function":	
		if(isset($object["schema"]) && isset($object["function"]))
		{	
			$schema = strtoupper($object["schema"]);
			$function = strtoupper($object["function"]);
			$query = "SELECT count(*) FROM SYSCAT.FUNCTIONS WHERE FUNCSCHEMA = '$schema' AND FUNCNAME = '$function'";
		}
		break;	
		case "datatype":	
		if(isset($object["schema"]) && isset($object["datatype"]))
		{	
			$schema = strtoupper($object["schema"]);
			$datatype = strtoupper($object["datatype"]);
			$query = "SELECT count(*) FROM SYSCAT.DATATYPES WHERE TYPESCHEMA = '$schema' AND TYPENAME = '$datatype'";
		}
		break;
		case "transform":	
		if(isset($object["schema"]) && isset($object["datatype"]) && isset($object["function"]))
		{	
			$schema = strtoupper($object["schema"]);
			$datatype = strtoupper($object["datatype"]);
			$function = strtoupper($object["function"]);
			$query = "SELECT count(*) FROM SYSCAT.TRANSFORMS WHERE TYPESCHEMA = '$schema' AND TYPENAME = '$datatype'
			AND FUNCSCHEMA = '$schema' AND FUNCNAME = '$function'";
		}
		break;
		case "tablespace":	
		if(isset($object["tablespace"]))
		{	
			$tablespace = strtoupper($object["tablespace"]);
			$query = "SELECT count(*) FROM SYSCAT.TABLESPACES WHERE TBSPACE = '$tablespace' ";
		}
		break;
	default:
		echo <<<JSON
	{
		returnCode: "false",
		returnValue: 0
	}
JSON;
exit;
}

$statment = connectionManager::getNewStatement($query);

if($statment->errorMsg() == "")
{
	$resultRow = $statment->fetch();
	
	if($resultRow != false)
	{
		if($resultRow[0] > 0)
		{
			$returnObject['returnCode'] = "true";
			$returnObject['returnObject'] = 1;
		}
	}
	else 
	{
		$returnObject['returnObject'] = "No result returned";
	}
}
else 
{
	$returnObject['returnCode'] = $statment->sqlstate;
	$returnObject['returnObject'] = $statment->sqlerror;
}

echo json_encode($returnObject);